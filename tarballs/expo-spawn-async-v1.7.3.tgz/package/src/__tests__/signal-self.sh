#!/bin/sh

kill -KILL $$
