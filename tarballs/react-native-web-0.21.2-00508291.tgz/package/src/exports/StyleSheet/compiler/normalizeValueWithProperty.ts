/**
 * Copyright (c) Nicolas Gallagher.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

import unitlessNumbers from '../../../modules/unitlessNumbers';
import normalizeColor from './normalizeColor';
import type { Nullable } from '../../../types';

export type StyleValue =
  | number
  | string
  | Array<StyleValue>
  | { [key: string]: StyleValue | null | undefined };

const colorProps: Record<string, boolean> = {
  backgroundColor: true,
  borderColor: true,
  borderTopColor: true,
  borderRightColor: true,
  borderBottomColor: true,
  borderLeftColor: true,
  color: true,
  shadowColor: true,
  textDecorationColor: true,
  textShadowColor: true
};

export default function normalizeValueWithProperty<
  T extends StyleValue | null | undefined
>(value: T, property?: Nullable<string>): T | string | undefined {
  if (
    (property == null || !unitlessNumbers[property]) &&
    typeof value === 'number'
  ) {
    return `${value}px`;
  }
  if (property != null && colorProps[property]) {
    return typeof value === 'object' ? undefined : normalizeColor(value);
  }
  return value;
}
