/**
 * Copyright (c) Nicolas Gallagher.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

import type { Root } from 'react-dom/client';

export default function unmountComponentAtNode(rootTag: Root) {
  rootTag.unmount();
  return true;
}
