/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @noformat
 * @oncall react_native
 * @generated SignedSource<<0e019739f58fd639818330cd537c5975>>
 *
 * This file was translated from Flow by scripts/generateTypeScriptDefinitions.js
 * Original file: packages/metro/src/node-haste/DependencyGraph.js
 * To regenerate, run:
 *   js1 build metro-ts-defs (internal) OR
 *   yarn run build-ts-defs (OSS) 
 */

import type {
  BundlerResolution,
  TransformResultDependency,
} from '../DeltaBundler/types';
import type {ResolverInputOptions} from '../shared/types';
import type {ConfigT} from '../../metro-config';
import type {
  ChangeEvent,
  FileSystem,
  HasteMap,
  HealthCheckResult,
  WatcherStatus,
  default as MetroFileMap,
} from '../../metro-file-map';

import {ModuleResolver} from './DependencyGraph/ModuleResolution';
import EventEmitter from 'node:events';

declare class DependencyGraph extends EventEmitter {
  _config: ConfigT;
  _haste: MetroFileMap;
  _fileSystem: FileSystem;
  _hasteMap: HasteMap;
  _moduleResolver: ModuleResolver;
  _resolutionCache: Map<
    string | symbol,
    Map<
      string | symbol,
      Map<string | symbol, Map<string | symbol, BundlerResolution>>
    >
  >;
  _initializedPromise: Promise<void>;
  constructor(
    config: ConfigT,
    options?: {
      readonly hasReducedPerformance?: boolean;
      readonly watch?: boolean;
    },
  );
  _onWatcherHealthCheck(result: HealthCheckResult): void;
  _onWatcherStatus(status: WatcherStatus): void;
  ready(): Promise<void>;
  _onHasteChange($$PARAM_0$$: ChangeEvent): void;
  _createModuleResolver(): void;
  _getClosestPackage(
    absoluteModulePath: string,
  ): null | undefined | {packageJsonPath: string; packageRelativePath: string};
  getAllFiles(): Array<string>;
  /**
   * Used when watcher.unstable_lazySha1 is true
   */
  getOrComputeSha1(
    mixedPath: string,
  ): Promise<{content?: Buffer; sha1: string}>;
  getWatcher(): EventEmitter;
  end(): Promise<void>;
  /** Given a search context, return a list of file paths matching the query. */
  matchFilesWithContext(
    from: string,
    context: Readonly<{recursive: boolean; filter: RegExp}>,
  ): Iterable<string>;
  resolveDependency(
    originModulePath: string,
    dependency: TransformResultDependency,
    platform: string | null,
    resolverOptions: ResolverInputOptions,
    extraOptions?: {assumeFlatNodeModules: boolean},
  ): BundlerResolution;
  doesFileExist: (filePath: string) => boolean;
  getHasteName(filePath: string): string;
  getDependencies(filePath: string): Array<string>;
}
export default DependencyGraph;
