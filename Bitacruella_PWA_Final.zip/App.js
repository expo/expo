// Código completo de Bitacruella con pantallas, historial, gráficas y notificaciones PWA
