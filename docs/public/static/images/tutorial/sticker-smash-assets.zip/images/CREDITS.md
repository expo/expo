# Credits

## background-image.png

"Fawn and white Welsh Corgi puppy standing on rear legs and sticking out the tongue" by Huoadg5888, from Wikimedia Commons:
https://commons.wikimedia.org/wiki/File:Fawn_and_white_Welsh_Corgi_puppy_standing_on_rear_legs_and_sticking_out_the_tongue.jpg

License: CC0 1.0 Universal (public domain dedication). Cropped and resized to 960 x 1320 for this tutorial.

## emoji1.png to emoji6.png

Microsoft Fluent Emoji, 3D style, from https://github.com/microsoft/fluentui-emoji:

- emoji1.png: Melting face
- emoji2.png: Heart hands
- emoji3.png: Skull
- emoji4.png: Bubble tea
- emoji5.png: Pink heart
- emoji6.png: Frog

License:

```text
MIT License

Copyright (c) Microsoft Corporation.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE

```
