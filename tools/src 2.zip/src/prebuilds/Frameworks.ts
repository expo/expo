import fs from 'fs-extra';
import ora from 'ora';
import path from 'path';

import Logger from '../Logger';
import { Package } from '../Packages';
import { BuildFlavor } from './Prebuilder.types';
import { getBuildPlatformsFromProductPlatform, SPMBuild } from './SPMBuild';
import { BuiltFramework } from './SPMBuild.types';
import { BuildPlatform, SPMConfig, SPMProduct, getTargetByName } from './SPMConfig.types';
import { SPMGenerator } from './SPMGenerator';
import { spawnXcodeBuildWithSpinner } from './XCodeRunner';

export const Frameworks = {
  /**
   * Composes an XCFramework from the given built frameworks.
   * @param pkg Package
   * @param buildType Build flavor (Debug or Release)
   * @param options Options including platform and product name
   */
  composeXCFrameworkFromBuiltFrameworksAsync: async (
    pkg: Package,
    buildType: BuildFlavor,
    options?: {
      platform?: BuildPlatform;
      productName?: string;
    }
  ): Promise<void> => {
    const spmConfig = await pkg.getSwiftPMConfigurationAsync();
    if (!spmConfig) {
      throw new Error(`No SwiftPM configuration found for package: ${pkg.packageName}`);
    }

    for (const product of spmConfig.products) {
      if (options?.productName && product.name !== options.productName) {
        continue;
      }

      Logger.info(`🧩 Composing XCFramework for ${product.name}...`);

      // Get output path for the XCFramework
      const xcframeworkOutputPath = Frameworks.getFrameworkPath(pkg, product, buildType);

      // Resolve build platforms
      const allBuildPlatforms: BuildPlatform[] = [];
      for (const spmPlatform of spmConfig.platforms) {
        // Expand platforns: iOS(.v15) -> [iOS, iOS Simulator] and filter on the platforms requested
        const buildPlatforms = getBuildPlatformsFromProductPlatform(spmPlatform).filter(
          (platform) => !options?.platform || platform === options.platform
        );
        allBuildPlatforms.push(...buildPlatforms);
      }

      const frameworks: BuiltFramework[] = [];

      // Create output folder for the product
      for (const buildPlatform of allBuildPlatforms) {
        // Skip platform if a specific platform is requested
        if (options?.platform && buildPlatform !== options.platform) {
          continue;
        }

        frameworks.push({
          symbolsBundlePath: SPMBuild.getProductSymbolsBundleArtifactsPath(
            pkg,
            product,
            buildType,
            buildPlatform
          ),
          frameworkPath: SPMBuild.getProductFrameworkArtifactsPath(
            pkg,
            product,
            buildType,
            buildPlatform
          ),
          product,
          buildType,
        });
      }

      // Compose the XCFramework folder structure using XCode
      const slices = await composeFrameworkWithXCodeAsync(
        pkg,
        product,
        frameworks,
        xcframeworkOutputPath
      );

      // Collect and copy header files
      const collectedHeaderFiles = await collectAndCopyHeaderFilesFromBuiltFrameworksAsync(
        pkg,
        spmConfig,
        product,
        xcframeworkOutputPath
      );

      // Propagate headers down to each framework slice (slices)
      const sourceHeadersPath = path.join(xcframeworkOutputPath, 'Headers');

      for (const slice of slices) {
        const slicePath = path.join(xcframeworkOutputPath, slice, product.name + '.framework');

        const destHeadersPath = path.join(slicePath, 'Headers');
        await fs.mkdirp(destHeadersPath);
        await fs.copy(sourceHeadersPath, destHeadersPath);

        // Create module.modulemap and umbrella header file for each slice
        await createModuleMapWithUmbrellaHeaderFilesAsync(
          slicePath,
          product.name,
          collectedHeaderFiles
        );
      }

      // remove the toplevel Headers directory as it's no longer needed
      await fs.remove(sourceHeadersPath);
    }
  },

  /**
   * Gets the output path for frameworks for the given package.
   * @param pkg Package information
   * @param buildType Build flavor
   * @returns Output path for frameworks
   */
  getFrameworksOutputPath: (pkg: Package, buildType: BuildFlavor): string => {
    return path.join(pkg.path, '.xcframeworks', buildType.toLowerCase());
  },

  /**
   * Returns the full path to the built XCFramework for the given product.
   * @param pkg Package
   * @param product SPM product
   * @param buildType Build flavor
   * @returns Full path to the built XCFramework
   */
  getFrameworkPath: (pkg: Package, product: SPMProduct, buildType: BuildFlavor): string => {
    return path.join(
      Frameworks.getFrameworksOutputPath(pkg, buildType),
      `${product.name}.xcframework`
    );
  },
};

/**
 * Creates a module.modulemap file and umbrella header for the given framework slice.
 * @param frameworkSlicePath Path to the framework slice
 * @param productName Name of the product/framework
 * @param umbrellaHeaderFiles Collected umbrella header files (full paths)
 */
const createModuleMapWithUmbrellaHeaderFilesAsync = async (
  frameworkSlicePath: string,
  productName: string,
  umbrellaHeaderFiles: string[]
): Promise<void> => {
  const umbrellaName = `${productName}_umbrella.h`;
  const moduleMapContent = `framework module ${productName} {
    umbrella header "${umbrellaName}"

    export *
    module * { export * }
}
`;
  const moduleMapPath = path.join(frameworkSlicePath, 'Modules', 'module.modulemap');
  await fs.mkdirp(path.dirname(moduleMapPath));
  await fs.writeFile(moduleMapPath, moduleMapContent, 'utf8');

  // Create the umbrella header file
  // Use only the basename since headers are flattened into the Headers directory
  const umbrellaHeaderContent = umbrellaHeaderFiles
    .map((headerFile) => `#include "${path.basename(headerFile)}"`)
    .join('\n');

  const umbrellaHeaderPath = path.join(frameworkSlicePath, 'Headers', `${umbrellaName}`);
  await fs.writeFile(umbrellaHeaderPath, umbrellaHeaderContent, 'utf8');
};

/**
 * Composes the XCFramework using xcodebuild.
 * @param pkg Package information
 * @param product SPM product information
 * @param frameworks Built frameworks to include
 * @param outputFrameworkPath Output path for the composed XCFramework
 */
const composeFrameworkWithXCodeAsync = async (
  pkg: Package,
  product: SPMProduct,
  frameworks: BuiltFramework[],
  outputFrameworkPath: string
): Promise<string[]> => {
  // Clean output directory
  await fs.remove(outputFrameworkPath);
  await fs.mkdirp(path.dirname(outputFrameworkPath));

  // Run XCode build command with formatted output
  // Pair each framework with its debug symbols to avoid dSYM name collisions
  const args = [
    `-create-xcframework`,
    ...frameworks.flatMap((framework) => [
      '-framework',
      framework.frameworkPath,
      '-debug-symbols',
      framework.symbolsBundlePath,
    ]),
    `-output`,
    outputFrameworkPath,
  ];

  const { code, error: buildError } = await spawnXcodeBuildWithSpinner(
    args,
    pkg.path,
    pkg.path,
    `Building ${product.name}.xcframework`
  );

  if (code !== 0) {
    throw new Error(
      `xcodebuild failed with code ${code}:\n${buildError}\n\nxcodebuild ${args.join(' ')}`
    );
  }

  // Find slices in the composed XCFramework - they are the folders inside the .xcframework
  // remember to return only directories, not files - and return their names.
  return (await fs.readdir(outputFrameworkPath)).filter((name) => {
    const fullPath = path.join(outputFrameworkPath, name);
    return fs.statSync(fullPath).isDirectory();
  });
};

/**
 * Collects header files for the given product. The function uses the product definition's
 * include files to locate and copy the headers into the XCFramework's Headers directory.
 * @param pkg Package information
 * @param spmConfig SPM configuration
 * @param product SPM product information
 * @returns Collected header file paths
 */
const collectAndCopyHeaderFilesFromBuiltFrameworksAsync = async (
  pkg: Package,
  spmConfig: SPMConfig,
  product: SPMProduct,
  frameworkOutputPath: string
) => {
  const spinner = ora({
    text: `Collecting header files for ${product.name}`,
    prefixText: '  ',
  }).start();

  spinner.text = `Copying header files for ${product.name}`;

  // Create headers directory inside the XCFramework output path
  const frameworkHeadersPath = path.join(frameworkOutputPath, 'Headers');
  await fs.mkdirp(frameworkHeadersPath);

  // Get header files and copy them to the Headers directory
  const headerFilesCollected: string[] = [];
  for (const targetName of product.targets) {
    const target = getTargetByName(spmConfig, targetName);
    if (!target) {
      continue;
    }
    const targetHeaderFilesPath = SPMGenerator.getHeaderFilesPath(pkg, product, target);
    const headerFiles = await fs.readdir(targetHeaderFilesPath);
    headerFilesCollected.push(...headerFiles.map((f) => path.join(targetHeaderFilesPath, f)));
    for (const headerFile of headerFiles) {
      const sourceHeaderFilePath = path.join(targetHeaderFilesPath, headerFile);
      const destHeaderFilePath = path.join(frameworkHeadersPath, headerFile);
      await fs.copy(sourceHeaderFilePath, destHeaderFilePath);
    }
  }

  spinner.succeed(`Copied header files for ${product.name}`);

  return headerFilesCollected;
};
