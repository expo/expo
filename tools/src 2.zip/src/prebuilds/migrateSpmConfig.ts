#!/usr/bin/env ts-node
/**
 * Migration script to convert old SPM config format to the new format.
 *
 * Old format: targets are nested inside products, externalDependencies are per-product
 * New format: targets are at root level, products reference targets by name, externalDependencies at root level
 */

import fs from 'fs-extra';

interface OldSpmConfigTarget {
  type: 'objc' | 'swift' | 'cpp' | 'framework';
  name: string;
  path: string;
  pattern?: string;
  headerPattern?: string;
  dependencies?: string[];
  exclude?: string[];
  includeDirectories?: string[];
  useIncludesFrom?: string[];
  linkedFrameworks?: string[];
  plugins?: string[];
}

interface OldSpmConfigProduct {
  name: string;
  externalDependencies?: string[];
  targets: OldSpmConfigTarget[];
}

interface OldSpmConfig {
  $schema: string;
  platforms: string[];
  products: OldSpmConfigProduct[];
}

interface NewSpmConfigTarget {
  type: 'objc' | 'swift' | 'cpp' | 'framework';
  name: string;
  path: string;
  pattern?: string;
  headerPattern?: string;
  dependencies?: string[];
  exclude?: string[];
  includeDirectories?: string[];
  useIncludesFrom?: string[];
  linkedFrameworks?: string[];
  plugins?: string[];
}

interface NewSpmConfigProduct {
  name: string;
  targets: string[];
}

interface NewSpmConfig {
  $schema: string;
  platforms: string[];
  externalDependencies?: string[];
  targets: NewSpmConfigTarget[];
  products: NewSpmConfigProduct[];
}

function migrateConfig(oldConfig: OldSpmConfig): NewSpmConfig {
  // Collect all unique targets and external dependencies
  const targetMap = new Map<string, NewSpmConfigTarget>();
  const externalDependencies = new Set<string>();

  // Process each product
  for (const product of oldConfig.products) {
    // Collect external dependencies
    if (product.externalDependencies) {
      for (const dep of product.externalDependencies) {
        externalDependencies.add(dep);
      }
    }

    // Process targets
    for (const target of product.targets) {
      // Check for duplicate target names (same target used in multiple products)
      if (targetMap.has(target.name)) {
        const existing = targetMap.get(target.name)!;
        // Merge if they're the same (just keep the first one)
        if (JSON.stringify(existing) !== JSON.stringify(target)) {
          console.warn(
            `Warning: Duplicate target name '${target.name}' with different definitions. Using first definition.`
          );
        }
      } else {
        targetMap.set(target.name, { ...target });
      }
    }
  }

  // Build new products (just referencing targets by name)
  const newProducts: NewSpmConfigProduct[] = oldConfig.products.map((product) => ({
    name: product.name,
    targets: product.targets.map((t) => t.name),
  }));

  // Build new config
  const newConfig: NewSpmConfig = {
    $schema: oldConfig.$schema,
    platforms: oldConfig.platforms,
    targets: Array.from(targetMap.values()),
    products: newProducts,
  };

  // Only add externalDependencies if there are any
  if (externalDependencies.size > 0) {
    newConfig.externalDependencies = Array.from(externalDependencies);
  }

  return newConfig;
}

async function main() {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.log('Usage: ts-node migrateSpmConfig.ts <path-to-spm.config.json>');
    console.log('');
    console.log('Converts old SPM config format to new format:');
    console.log('  - Moves targets to root level');
    console.log('  - Products reference targets by name');
    console.log('  - External dependencies moved to root level');
    process.exit(1);
  }

  const inputPath = args[0];
  const outputPath = args[1] || inputPath;

  if (!fs.existsSync(inputPath)) {
    console.error(`Error: File not found: ${inputPath}`);
    process.exit(1);
  }

  console.log(`Reading: ${inputPath}`);
  const oldConfig: OldSpmConfig = await fs.readJson(inputPath);

  console.log('Migrating configuration...');
  const newConfig = migrateConfig(oldConfig);

  console.log(`  - Found ${oldConfig.products.length} products`);
  console.log(`  - Extracted ${newConfig.targets.length} unique targets`);
  console.log(`  - External dependencies: ${newConfig.externalDependencies?.join(', ') || 'none'}`);

  console.log(`Writing: ${outputPath}`);
  await fs.writeJson(outputPath, newConfig, { spaces: 4 });

  console.log('Migration complete!');
}

main().catch((error) => {
  console.error('Error:', error);
  process.exit(1);
});
