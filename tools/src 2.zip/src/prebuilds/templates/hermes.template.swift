FrameworkTarget(
    name: "Hermes",
    path: ".dependencies/Hermes/destroot/Library/Frameworks/universal/hermesvm.xcframework",
    includeDirectories: ["../../../../include"]
)
