import { VendoringConfig } from '../types';

const config: VendoringConfig = {
  'expo-go': require('./expoGoConfig').default,
};

export default config;
