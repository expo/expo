export type BuildFlavor = 'Debug' | 'Release';
