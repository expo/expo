import chalk from 'chalk';
import { execSync } from 'child_process';
import fs from 'fs-extra';
import path from 'path';

import type { ProductDefinition } from './SPMConfig.types';

// ============================================================================
// Types
// ============================================================================

/**
 * Represents a single source file with its dependencies
 */
export interface SourceFile {
  /** Absolute path to the file */
  filePath: string;
  /** Relative path from the source root */
  relativePath: string;
  /** File name without extension */
  name: string;
  /** File extension (.h, .m, .mm, .swift, .cpp) */
  extension: string;
  /** Language type */
  language: 'objc' | 'swift' | 'cpp' | 'header';
  /** Headers/modules this file imports */
  imports: ImportInfo[];
  /** Files that import this file (populated during analysis) */
  importedBy: string[];
  /** Name of the source root directory this file came from (e.g., "ios" or "common") */
  sourceRootName?: string;
}

/**
 * Information about an import statement
 */
export interface ImportInfo {
  /** The raw import string (e.g., "ExpoModulesCore/EXDefines.h" or "Foundation") */
  raw: string;
  /** Import type */
  type: 'angle-bracket' | 'quote' | 'module' | 'swift';
  /** Module/framework name if applicable */
  moduleName?: string;
  /** Header file name if applicable */
  headerName?: string;
  /** Whether this is a system/external import */
  isExternal: boolean;
}

/**
 * Represents a split target (single language)
 */
export interface SplitTarget {
  /** Target name (e.g., "Core_swift" or "Core_objc") */
  name: string;
  /** Original target name before splitting */
  originalName: string;
  /** Language of this target */
  language: 'objc' | 'swift' | 'cpp';
  /** Source files in this target */
  sourceFiles: string[];
  /** Header files associated with this target */
  headerFiles: string[];
  /** Other split targets this target depends on */
  dependencies: string[];
  /** External module dependencies (cross-product targets) */
  externalDependencies: string[];
  /** System frameworks to link (e.g., AVKit, Foundation) */
  linkedFrameworks: string[];
  /** Whether this target was split from a mixed-language target */
  wasSplit: boolean;
  /** Source root directory (basename) where these files came from */
  sourceRootName?: string;
}

/**
 * Result of dependency analysis
 */
export interface AnalysisResult {
  /** All source files found */
  files: Map<string, SourceFile>;
  /** All headers found (maps header name to file path) */
  headers: Map<string, string>;
  /** Dependency graph (file -> files it depends on) */
  dependencyGraph: Map<string, Set<string>>;
  /** Reverse dependency graph (file -> files that depend on it) */
  reverseDependencyGraph: Map<string, Set<string>>;
  /** Detected cycles */
  cycles: string[][];
  /** Split targets (single-language) */
  splitTargets: SplitTarget[];
  /** Source root path */
  sourceRoot: string;
}

/**
 * Options for the analyzer
 */
export interface AnalyzerOptions {
  /** Root directory to analyze */
  sourceRoot: string;
  /** Directories to exclude from analysis */
  excludeDirs?: string[];
  /** Additional include paths for clang analysis */
  includePaths?: string[];
  /** Known external modules (won't be flagged as missing) */
  externalModules?: string[];
  /** Verbose logging */
  verbose?: boolean;
  /** Use clang -MM for accurate dependency resolution (slower but more accurate) */
  useClang?: boolean;
}

function toGlobBraceList(filePaths: string[]): string | undefined {
  const unique = Array.from(
    new Set(
      filePaths
        .filter(Boolean)
        .map((p) => p.replace(/\\/g, '/'))
        .map((p) => p.replace(/^\.\//, ''))
    )
  ).sort((a, b) => a.localeCompare(b));

  if (unique.length === 0) return undefined;
  if (unique.length === 1) return unique[0];
  return `{${unique.join(',')}}`;
}

function sanitizeTargetNamePart(input: string): string {
  return input
    .replace(/\\/g, '_')
    .replace(/\//g, '_')
    .replace(/[^A-Za-z0-9_]+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '')
    .trim();
}

function mergeSingletonSccSplitTargets(
  splitTargets: SplitTarget[],
  productDefinitions?: ProductDefinition[]
): SplitTarget[] {
  // Merge singleton (single-file) targets by folder+language+product, but avoid creating cycles.
  // If merging creates a cycle, iteratively exclude cycle-involved singletons from merging.

  function getBucketFromRelativePath(relativePath: string): string {
    const dir = path.dirname(relativePath);
    if (dir === '.' || dir === path.sep) return 'Root';
    const parts = dir.split(path.sep).filter(Boolean);
    return parts[0] || 'Root';
  }

  // Helper to get product for a file path
  function getProductForPath(relativePath: string): string {
    if (!productDefinitions || productDefinitions.length === 0) {
      return 'default';
    }
    const product = getFileProduct(relativePath, productDefinitions);
    return product || 'default';
  }

  function tryMerge(
    allTargets: SplitTarget[],
    excludeFromMerge: Set<string>
  ): { result: SplitTarget[]; cycles: string[][] } {
    const existingNames = new Set(allTargets.map((t) => t.name));
    const singletonTargets = allTargets.filter(
      (t) => t.sourceFiles.length + t.headerFiles.length === 1 && !excludeFromMerge.has(t.name)
    );
    if (singletonTargets.length === 0) {
      return { result: allTargets, cycles: [] };
    }

    const mergeGroups = new Map<string, SplitTarget[]>();
    for (const t of singletonTargets) {
      const onlyPath = t.sourceFiles[0] ?? t.headerFiles[0];
      const bucket = getBucketFromRelativePath(onlyPath);
      const product = getProductForPath(onlyPath);
      // Include product in the key so files for different products don't get merged together
      const key = `${bucket}::${t.language}::${product}`;
      if (!mergeGroups.has(key)) mergeGroups.set(key, []);
      mergeGroups.get(key)!.push(t);
    }

    // Only keep groups where merging actually reduces count.
    const effectiveGroups = Array.from(mergeGroups.entries()).filter(([, list]) => list.length > 1);
    if (effectiveGroups.length === 0) {
      return { result: allTargets, cycles: [] };
    }

    const oldToNewName = new Map<string, string>();
    const mergedTargets: SplitTarget[] = [];

    for (const [key, group] of effectiveGroups) {
      const [bucket, language] = key.split('::') as [string, SplitTarget['language']];
      const baseName = `SCCM_${sanitizeTargetNamePart(bucket)}_${language}`;
      let name = baseName;
      let i = 2;
      while (existingNames.has(name)) {
        name = `${baseName}_${i++}`;
      }
      existingNames.add(name);

      for (const member of group) {
        oldToNewName.set(member.name, name);
      }

      const sourceFiles = Array.from(new Set(group.flatMap((t) => t.sourceFiles))).sort((a, b) =>
        a.localeCompare(b)
      );
      const headerFiles = Array.from(new Set(group.flatMap((t) => t.headerFiles))).sort((a, b) =>
        a.localeCompare(b)
      );
      const linkedFrameworks = Array.from(new Set(group.flatMap((t) => t.linkedFrameworks))).sort(
        (a, b) => a.localeCompare(b)
      );

      // Preserve sourceRootName from source targets if they all share the same one
      // (Merged targets should only combine targets from the same source directory)
      const sourceRootNames = new Set(group.map((t) => t.sourceRootName).filter(Boolean));
      const sourceRootName =
        sourceRootNames.size === 1 ? Array.from(sourceRootNames)[0] : undefined;

      mergedTargets.push({
        name,
        originalName: name,
        language,
        sourceFiles,
        headerFiles,
        dependencies: [],
        externalDependencies: [],
        linkedFrameworks,
        wasSplit: true,
        sourceRootName,
      });
    }

    // Start with non-merged targets + merged targets.
    const mergedAway = new Set(oldToNewName.keys());
    const kept = allTargets.filter((t) => !mergedAway.has(t.name));
    const combined = [...kept, ...mergedTargets];

    // Rebuild dependencies with name rewrites + de-dupe + remove self-deps.
    const combinedNames = new Set(combined.map((t) => t.name));
    const groupedNames = new Set(oldToNewName.values());

    // Helper: collect members for each merged name to compute their combined deps.
    const mergedNameToMembers = new Map<string, SplitTarget[]>();
    for (const member of singletonTargets) {
      const newName = oldToNewName.get(member.name);
      if (!newName) continue;
      if (!mergedNameToMembers.has(newName)) mergedNameToMembers.set(newName, []);
      mergedNameToMembers.get(newName)!.push(member);
    }

    const result = combined
      .map((t) => {
        const depsSourceTargets = groupedNames.has(t.name)
          ? (mergedNameToMembers.get(t.name) ?? [])
          : [t];
        const deps = new Set<string>();
        for (const src of depsSourceTargets) {
          for (const d of src.dependencies) {
            const rewritten = oldToNewName.get(d) ?? d;
            if (rewritten === t.name) continue;
            deps.add(rewritten);
          }
        }

        const depList = Array.from(deps).filter((d) => !mergedAway.has(d) || combinedNames.has(d));
        depList.sort((a, b) => a.localeCompare(b));
        return { ...t, dependencies: depList };
      })
      .sort((a, b) => a.name.localeCompare(b.name));

    // Detect cycles in the merged result.
    const cycles = detectSplitTargetCyclesInternal(result);
    return { result, cycles };
  }

  // Iteratively merge; if cycles appear, exclude singletons that ended up in cyclic merged targets.
  let excludeFromMerge = new Set<string>();
  let attempt = tryMerge(splitTargets, excludeFromMerge);
  let iterations = 0;
  const maxIterations = 20;

  while (attempt.cycles.length > 0 && iterations < maxIterations) {
    iterations++;
    // Find merged target names involved in cycles.
    const cyclicNames = new Set<string>();
    for (const cycle of attempt.cycles) {
      for (const name of cycle) {
        cyclicNames.add(name);
      }
    }

    // Map merged names back to original singleton names and exclude them.
    const newExclusions = new Set(excludeFromMerge);
    for (const t of splitTargets) {
      if (t.sourceFiles.length + t.headerFiles.length !== 1) continue;
      const bucket = getBucketFromRelativePath(t.sourceFiles[0] ?? t.headerFiles[0]);
      const mergedName = `SCCM_${sanitizeTargetNamePart(bucket)}_${t.language}`;
      // Check if this merged name (or variants) is cyclic.
      for (const cyclic of cyclicNames) {
        if (cyclic === mergedName || cyclic.startsWith(mergedName + '_')) {
          newExclusions.add(t.name);
        }
      }
    }

    if (newExclusions.size === excludeFromMerge.size) {
      // No progress, give up.
      break;
    }
    excludeFromMerge = newExclusions;
    attempt = tryMerge(splitTargets, excludeFromMerge);
  }

  return attempt.result;
}

/**
 * Internal cycle detection for split targets (returns cycles, doesn't throw).
 */
function detectSplitTargetCyclesInternal(splitTargets: SplitTarget[]): string[][] {
  const targetNames = new Set(splitTargets.map((t) => t.name));
  const graph = new Map<string, Set<string>>();
  for (const target of splitTargets) {
    const deps = new Set<string>();
    for (const dep of target.dependencies) {
      if (targetNames.has(dep)) {
        deps.add(dep);
      }
    }
    graph.set(target.name, deps);
  }

  const cycles: string[][] = [];
  const visited = new Set<string>();
  const recStack = new Set<string>();
  const pathStack: string[] = [];

  function dfs(node: string): void {
    visited.add(node);
    recStack.add(node);
    pathStack.push(node);

    const neighbors = graph.get(node) || new Set();
    for (const neighbor of neighbors) {
      if (!targetNames.has(neighbor)) continue;
      if (!visited.has(neighbor)) {
        dfs(neighbor);
      } else if (recStack.has(neighbor)) {
        const cycleStart = pathStack.indexOf(neighbor);
        if (cycleStart !== -1) {
          const cycle = pathStack.slice(cycleStart);
          const cycleKey = [...cycle].sort().join('->');
          if (!cycles.some((c) => [...c].sort().join('->') === cycleKey)) {
            cycles.push(cycle);
          }
        }
      }
    }

    pathStack.pop();
    recStack.delete(node);
  }

  for (const node of graph.keys()) {
    if (!visited.has(node)) {
      dfs(node);
    }
  }

  return cycles;
}

// ============================================================================
// Constants
// ============================================================================

const SOURCE_EXTENSIONS = ['.m', '.mm', '.swift', '.cpp', '.c'];
const HEADER_EXTENSIONS = ['.h', '.hpp'];

/**
 * Modules that are implicitly available in Swift and should NOT be added to linkedFrameworks.
 * These are not actual frameworks that can be linked - they're either built into the Swift runtime
 * or are pseudo-modules that the compiler handles automatically.
 */
const IMPLICIT_SWIFT_MODULES = new Set([
  'Dispatch', // libdispatch - automatically linked with Swift
  'os', // os module - part of the system, not a linkable framework
  'ObjectiveC', // ObjC runtime - automatically linked
  'Darwin', // Darwin module - system headers, not a framework
]);

const KNOWN_SYSTEM_MODULES = new Set([
  'Foundation',
  'UIKit',
  'CoreGraphics',
  'QuartzCore',
  'AVFoundation',
  'AVKit',
  'CoreMedia',
  'CoreVideo',
  'Photos',
  'PhotosUI',
  'CoreLocation',
  'MapKit',
  'WebKit',
  'SafariServices',
  'StoreKit',
  'MessageUI',
  'EventKit',
  'EventKitUI',
  'Contacts',
  'ContactsUI',
  'LocalAuthentication',
  'Security',
  'SystemConfiguration',
  'CoreBluetooth',
  'CoreMotion',
  'CoreTelephony',
  'UserNotifications',
  'BackgroundTasks',
  'Combine',
  'SwiftUI',
  'ObjectiveC',
  'Darwin',
  'Dispatch',
  'os',
  'Accelerate',
  'AudioToolbox',
  'CoreAudio',
  'CoreData',
  'CoreFoundation',
  'CoreImage',
  'CoreServices',
  'CoreText',
  'GameController',
  'GameKit',
  'GLKit',
  'ImageIO',
  'Metal',
  'MetalKit',
  'ModelIO',
  'Network',
  'NetworkExtension',
  'PushKit',
  'ReplayKit',
  'SceneKit',
  'SpriteKit',
  'VideoToolbox',
  'Vision',
  'WatchConnectivity',
  'WidgetKit',
]);

/**
 * Checks if a dependency name is a valid cross-product target dependency.
 * Filters out system frameworks and invalid module names.
 */
function isValidCrossProductDep(dep: string): boolean {
  // Skip system modules
  if (KNOWN_SYSTEM_MODULES.has(dep)) {
    return false;
  }
  // Skip common lowercase module names that are likely not valid targets
  // Only exclude the exact lowercase versions - uppercase like "JSI" are valid
  const invalidPatterns = [
    'objc',
    'react', // lowercase react is not a target, "React" is
    'jsi', // lowercase jsi is not a target, "JSI" is
    'c++',
    'std',
    'ReactCommon', // This is part of React, not a standalone target
  ];
  if (invalidPatterns.includes(dep)) {
    return false;
  }
  // Skip single-character or empty dependencies
  if (dep.length <= 1) {
    return false;
  }
  // Skip dependencies that start with lowercase (likely system or invalid)
  // Exception: allow all-caps like "JSI"
  if (dep[0] === dep[0].toLowerCase() && dep !== dep.toUpperCase()) {
    return false;
  }
  return true;
}

// ============================================================================
// File Discovery
// ============================================================================

/**
 * Recursively finds all source and header files in a directory
 */
async function findSourceFiles(
  rootDir: string,
  excludePatternsInput: string[] | string | undefined = []
): Promise<{ sources: string[]; headers: string[] }> {
  const sources: string[] = [];
  const headers: string[] = [];

  // Normalize excludePatterns to always be an array
  const excludePatterns: string[] = Array.isArray(excludePatternsInput)
    ? excludePatternsInput
    : excludePatternsInput
      ? [excludePatternsInput]
      : [];

  // Separate file patterns from directory patterns
  const excludeFiles = new Set(excludePatterns.filter((p) => p.includes('.')));
  const excludeDirs = excludePatterns.filter((p) => !p.includes('.'));

  async function walk(dir: string): Promise<void> {
    const entries = await fs.readdir(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const relativePath = path.relative(rootDir, fullPath);

      // Skip excluded directories
      if (entry.isDirectory()) {
        // Check for glob patterns like **/Tests (matches any dir named "Tests")
        const shouldExclude = excludeDirs.some((exclude) => {
          if (exclude.startsWith('**/')) {
            // Match any directory with this name at any level
            const dirName = exclude.slice(3);
            return entry.name === dirName;
          }
          // Exact path match
          return relativePath === exclude || relativePath.startsWith(exclude + path.sep);
        });
        if (!shouldExclude && !entry.name.startsWith('.')) {
          await walk(fullPath);
        }
        continue;
      }

      // Skip excluded files (check both filename and relative path)
      if (excludeFiles.has(entry.name) || excludeFiles.has(relativePath)) {
        continue;
      }

      const ext = path.extname(entry.name).toLowerCase();
      if (SOURCE_EXTENSIONS.includes(ext)) {
        sources.push(fullPath);
      } else if (HEADER_EXTENSIONS.includes(ext)) {
        headers.push(fullPath);
      }
    }
  }

  await walk(rootDir);
  return { sources, headers };
}

// ============================================================================
// Import Parsing
// ============================================================================

/**
 * Parses import statements from Objective-C/C++ source code
 */
function parseObjCImports(content: string): ImportInfo[] {
  const imports: ImportInfo[] = [];

  // Match #import <Module/Header.h> or #import <Header.h>
  const angleImportRegex = /#import\s*<([^>]+)>/g;
  let match;
  while ((match = angleImportRegex.exec(content)) !== null) {
    const raw = match[1];
    const parts = raw.split('/');
    imports.push({
      raw,
      type: 'angle-bracket',
      moduleName: parts.length > 1 ? parts[0] : undefined,
      headerName: parts.length > 1 ? parts.slice(1).join('/') : raw,
      isExternal: KNOWN_SYSTEM_MODULES.has(parts[0]),
    });
  }

  // Match #import "Header.h"
  const quoteImportRegex = /#import\s*"([^"]+)"/g;
  while ((match = quoteImportRegex.exec(content)) !== null) {
    const raw = match[1];
    imports.push({
      raw,
      type: 'quote',
      headerName: raw,
      isExternal: false,
    });
  }

  // Match #include <...> and #include "..."
  const includeAngleRegex = /#include\s*<([^>]+)>/g;
  while ((match = includeAngleRegex.exec(content)) !== null) {
    const raw = match[1];
    const parts = raw.split('/');
    imports.push({
      raw,
      type: 'angle-bracket',
      moduleName: parts.length > 1 ? parts[0] : undefined,
      headerName: parts.length > 1 ? parts.slice(1).join('/') : raw,
      isExternal: KNOWN_SYSTEM_MODULES.has(parts[0]) || raw.includes('std'),
    });
  }

  const includeQuoteRegex = /#include\s*"([^"]+)"/g;
  while ((match = includeQuoteRegex.exec(content)) !== null) {
    const raw = match[1];
    imports.push({
      raw,
      type: 'quote',
      headerName: raw,
      isExternal: false,
    });
  }

  // Match @import Module;
  const moduleImportRegex = /@import\s+(\w+)(?:\.(\w+))?;/g;
  while ((match = moduleImportRegex.exec(content)) !== null) {
    imports.push({
      raw: match[0],
      type: 'module',
      moduleName: match[1],
      isExternal: KNOWN_SYSTEM_MODULES.has(match[1]),
    });
  }

  return imports;
}

/**
 * Parses import statements from Swift source code
 */
function parseSwiftImports(content: string): ImportInfo[] {
  const imports: ImportInfo[] = [];

  // Match import Module
  const importRegex = /^import\s+(\w+)/gm;
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const moduleName = match[1];
    imports.push({
      raw: match[0],
      type: 'swift',
      moduleName,
      isExternal: KNOWN_SYSTEM_MODULES.has(moduleName),
    });
  }

  return imports;
}

// ============================================================================
// Clang-based Dependency Analysis
// ============================================================================

/**
 * Uses clang -MM to get accurate dependencies for a source file
 */
function getClangDependencies(
  filePath: string,
  includePaths: string[],
  verbose: boolean = false
): string[] {
  const ext = path.extname(filePath).toLowerCase();

  // Build include path flags
  const includeFlags = includePaths.map((p) => `-I${p}`).join(' ');

  // Determine language
  let langFlag = '-x objective-c++';
  if (ext === '.c') langFlag = '-x c';
  else if (ext === '.cpp') langFlag = '-x c++';

  try {
    const cmd = `clang -MM ${langFlag} ${includeFlags} "${filePath}" 2>/dev/null`;
    if (verbose) {
      console.log(chalk.gray(`  Running: ${cmd}`));
    }
    const output = execSync(cmd, { encoding: 'utf-8', maxBuffer: 10 * 1024 * 1024 });

    // Parse makefile-style output
    // Format: target.o: source.m header1.h header2.h \
    //                   header3.h
    const deps = output
      .replace(/\\\n/g, ' ') // Join continuation lines
      .split(':')[1] // Get dependencies part
      ?.split(/\s+/)
      .filter((d) => d.length > 0 && d !== filePath)
      .map((d) => d.trim());

    return deps || [];
  } catch {
    if (verbose) {
      console.log(chalk.yellow(`  Warning: clang failed for ${filePath}`));
    }
    return [];
  }
}

// ============================================================================
// Cycle Detection
// ============================================================================

/**
 * Detects cycles in the dependency graph using Tarjan's algorithm
 */
function detectCycles(graph: Map<string, Set<string>>): string[][] {
  const cycles: string[][] = [];
  const visited = new Set<string>();
  const recStack = new Set<string>();
  const path: string[] = [];

  function dfs(node: string): void {
    visited.add(node);
    recStack.add(node);
    path.push(node);

    const neighbors = graph.get(node) || new Set();
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        dfs(neighbor);
      } else if (recStack.has(neighbor)) {
        // Found a cycle
        const cycleStart = path.indexOf(neighbor);
        if (cycleStart !== -1) {
          cycles.push(path.slice(cycleStart));
        }
      }
    }

    path.pop();
    recStack.delete(node);
  }

  for (const node of graph.keys()) {
    if (!visited.has(node)) {
      dfs(node);
    }
  }

  return cycles;
}

/**
 * Finds strongly connected components (potential target groups)
 */
function findStronglyConnectedComponents(graph: Map<string, Set<string>>): string[][] {
  const index = new Map<string, number>();
  const lowlink = new Map<string, number>();
  const onStack = new Set<string>();
  const stack: string[] = [];
  const sccs: string[][] = [];
  let currentIndex = 0;

  function strongConnect(v: string): void {
    index.set(v, currentIndex);
    lowlink.set(v, currentIndex);
    currentIndex++;
    stack.push(v);
    onStack.add(v);

    const neighbors = graph.get(v) || new Set();
    for (const w of neighbors) {
      if (!index.has(w)) {
        strongConnect(w);
        lowlink.set(v, Math.min(lowlink.get(v)!, lowlink.get(w)!));
      } else if (onStack.has(w)) {
        lowlink.set(v, Math.min(lowlink.get(v)!, index.get(w)!));
      }
    }

    if (lowlink.get(v) === index.get(v)) {
      const scc: string[] = [];
      let w: string;
      do {
        w = stack.pop()!;
        onStack.delete(w);
        scc.push(w);
      } while (w !== v);
      sccs.push(scc);
    }
  }

  for (const v of graph.keys()) {
    if (!index.has(v)) {
      strongConnect(v);
    }
  }

  return sccs;
}

// ============================================================================
// SCC-based Target Computation
// ============================================================================

/**
 * Determines which product a file belongs to based on its path and product definitions.
 * Returns the product name, or undefined if no specific product matches (catch-all will be used).
 */
function getFileProduct(
  filePath: string,
  productDefinitions: ProductDefinition[] | undefined
): string | undefined {
  if (!productDefinitions || productDefinitions.length === 0) {
    return undefined;
  }

  // Find specific products (non-catch-all)
  for (const prodDef of productDefinitions) {
    if (prodDef.pathPatterns.includes('*')) {
      continue; // Skip catch-all
    }

    const matches = prodDef.pathPatterns.some((pattern) => {
      // Check if the file path contains the pattern as a path component
      // e.g., pattern "JSI" should match "cpp/JSI/TypedArray.cpp" or "ios/JSI/EXStringUtils.cpp"
      const patternWithSlashes = '/' + pattern + '/';
      const patternAtStart = pattern + '/';
      const patternAtEnd = '/' + pattern;

      return (
        filePath.includes(patternWithSlashes) || // /JSI/ anywhere in path
        filePath.startsWith(patternAtStart) || // JSI/ at start
        filePath.endsWith(patternAtEnd) || // ends with /JSI (directory)
        filePath === pattern || // exact match
        // Also check for pattern as a directory component
        filePath.split('/').includes(pattern)
      );
    });

    if (matches) {
      return prodDef.name;
    }
  }

  // Return catch-all product name if exists, otherwise undefined
  const catchAll = productDefinitions.find((p) => p.pathPatterns.includes('*'));
  return catchAll?.name;
}

/**
 * Determine which product a target belongs to based on its source files.
 * Returns the product name, or undefined if no product matches.
 */
function getTargetProduct(
  target: SplitTarget,
  productDefinitions: ProductDefinition[] | undefined
): string | undefined {
  if (!productDefinitions || productDefinitions.length === 0) {
    return undefined;
  }

  // Check each file in the target to determine product
  // A target belongs to a specific product if ANY of its files match that product
  for (const file of target.sourceFiles) {
    const product = getFileProduct(file, productDefinitions);
    // If any file matches a specific (non-catch-all) product, the target belongs there
    const isSpecificProduct = productDefinitions.some(
      (p) => p.name === product && !p.pathPatterns.includes('*')
    );
    if (isSpecificProduct) {
      return product;
    }
  }

  // Also check header files
  for (const file of target.headerFiles) {
    const product = getFileProduct(file, productDefinitions);
    const isSpecificProduct = productDefinitions.some(
      (p) => p.name === product && !p.pathPatterns.includes('*')
    );
    if (isSpecificProduct) {
      return product;
    }
  }

  // Fall back to catch-all
  const catchAll = productDefinitions.find((p) => p.pathPatterns.includes('*'));
  return catchAll?.name;
}

function computeSplitTargetsBySccVirtualTargets(
  files: Map<string, SourceFile>,
  dependencyGraph: Map<string, Set<string>>,
  productDefinitions?: ProductDefinition[]
): SplitTarget[] {
  // First, determine which product each file belongs to
  const fileToProduct = new Map<string, string | undefined>();
  for (const [filePath, file] of files.entries()) {
    const product = getFileProduct(file.relativePath, productDefinitions);
    fileToProduct.set(filePath, product);
  }

  // Build file-level graph restricted to known files AND same product.
  // Files in different products should not be grouped together in the same SCC.
  const fileGraph = new Map<string, Set<string>>();
  for (const filePath of files.keys()) {
    const fileProduct = fileToProduct.get(filePath);
    const deps = new Set<string>();
    const rawDeps = dependencyGraph.get(filePath);
    if (rawDeps) {
      for (const dep of rawDeps) {
        if (files.has(dep)) {
          // Only include dependency if it's in the same product (or both have no product)
          const depProduct = fileToProduct.get(dep);
          if (fileProduct === depProduct) {
            deps.add(dep);
          }
        }
      }
    }
    fileGraph.set(filePath, deps);
  }

  const sccs = findStronglyConnectedComponents(fileGraph);

  const fileToTarget = new Map<string, string>();
  const targetNameToFiles = new Map<string, SourceFile[]>();
  const targetNameToLanguage = new Map<string, SplitTarget['language']>();

  function isObjcLike(f: SourceFile): boolean {
    return f.language === 'objc' || f.language === 'cpp' || f.language === 'header';
  }

  function swiftDependsOnObjcWithinScc(swiftFilePath: string, sccSet: Set<string>): boolean {
    const deps = dependencyGraph.get(swiftFilePath);
    if (!deps) return false;
    for (const dep of deps) {
      if (!sccSet.has(dep)) continue;
      const depFile = files.get(dep);
      if (depFile && isObjcLike(depFile)) return true;
    }
    return false;
  }

  function objcDependsOnSwiftWithinScc(objcFilePath: string, sccSet: Set<string>): boolean {
    const deps = dependencyGraph.get(objcFilePath);
    if (!deps) return false;
    for (const dep of deps) {
      if (!sccSet.has(dep)) continue;
      const depFile = files.get(dep);
      if (depFile && depFile.language === 'swift') return true;
    }
    return false;
  }

  function addTarget(name: string, language: SplitTarget['language']): void {
    if (!targetNameToFiles.has(name)) {
      targetNameToFiles.set(name, []);
      targetNameToLanguage.set(name, language);
    }
  }

  // Step 1: assign files to SCC-derived targets.
  sccs.forEach((component, sccIndex) => {
    const sccSet = new Set(component);
    const componentFiles = component.map((p) => files.get(p)).filter(Boolean) as SourceFile[];

    const swiftFiles = componentFiles.filter((f) => f.language === 'swift');
    const objcLikeFiles = componentFiles.filter((f) => isObjcLike(f));

    if (swiftFiles.length > 0 && objcLikeFiles.length === 0) {
      const tName = `SCC${sccIndex}_swift`;
      addTarget(tName, 'swift');
      for (const f of swiftFiles) {
        fileToTarget.set(f.filePath, tName);
        targetNameToFiles.get(tName)!.push(f);
      }
      return;
    }

    if (objcLikeFiles.length > 0 && swiftFiles.length === 0) {
      // If this SCC is purely C/C++ (no ObjC), mark as cpp, otherwise objc.
      const hasObjc = objcLikeFiles.some((f) => f.language === 'objc');
      const tName = `SCC${sccIndex}_objc`;
      addTarget(tName, hasObjc ? 'objc' : 'cpp');
      for (const f of objcLikeFiles) {
        fileToTarget.set(f.filePath, tName);
        targetNameToFiles.get(tName)!.push(f);
      }
      return;
    }

    // Mixed SCC: attempt Swift_base extraction.
    const swiftBase: SourceFile[] = [];
    const swiftMain: SourceFile[] = [];

    const objcThatDependsOnSwift = objcLikeFiles.filter((f) =>
      objcDependsOnSwiftWithinScc(f.filePath, sccSet)
    );
    const swiftUsedByObjc = new Set<string>();
    for (const objcFile of objcThatDependsOnSwift) {
      const deps = dependencyGraph.get(objcFile.filePath);
      if (!deps) continue;
      for (const dep of deps) {
        if (!sccSet.has(dep)) continue;
        const depFile = files.get(dep);
        if (depFile?.language === 'swift') swiftUsedByObjc.add(dep);
      }
    }

    for (const swiftFile of swiftFiles) {
      const usedByObjc = swiftUsedByObjc.has(swiftFile.filePath);
      const dependsOnObjc = swiftDependsOnObjcWithinScc(swiftFile.filePath, sccSet);
      if (usedByObjc && !dependsOnObjc) {
        swiftBase.push(swiftFile);
      } else {
        swiftMain.push(swiftFile);
      }
    }

    // ObjC-like target for this SCC.
    const hasObjc = objcLikeFiles.some((f) => f.language === 'objc');
    const objcTargetName = `SCC${sccIndex}_objc`;
    addTarget(objcTargetName, hasObjc ? 'objc' : 'cpp');
    for (const f of objcLikeFiles) {
      fileToTarget.set(f.filePath, objcTargetName);
      targetNameToFiles.get(objcTargetName)!.push(f);
    }

    if (swiftBase.length > 0) {
      const baseName = `SCC${sccIndex}_swift_base`;
      addTarget(baseName, 'swift');
      for (const f of swiftBase) {
        fileToTarget.set(f.filePath, baseName);
        targetNameToFiles.get(baseName)!.push(f);
      }
    }

    if (swiftMain.length > 0) {
      const mainName = `SCC${sccIndex}_swift_main`;
      addTarget(mainName, 'swift');
      for (const f of swiftMain) {
        fileToTarget.set(f.filePath, mainName);
        targetNameToFiles.get(mainName)!.push(f);
      }
    }
  });

  // Step 2: compute dependencies and linked frameworks.
  const splitTargets: SplitTarget[] = [];
  const targetNames = Array.from(targetNameToFiles.keys());
  const validTargetNames = new Set(targetNames);

  for (const targetName of targetNames.sort((a, b) => a.localeCompare(b))) {
    const tFiles = targetNameToFiles.get(targetName) ?? [];
    const language = targetNameToLanguage.get(targetName) ?? 'objc';

    const depTargets = new Set<string>();
    const linkedFrameworks = new Set<string>();

    const sourceFiles: string[] = [];
    const headerFiles: string[] = [];

    for (const file of tFiles) {
      if (file.language === 'header') {
        headerFiles.push(file.relativePath);
      } else {
        sourceFiles.push(file.relativePath);
      }

      const deps = dependencyGraph.get(file.filePath);
      if (deps) {
        for (const dep of deps) {
          const depTarget = fileToTarget.get(dep);
          if (depTarget && depTarget !== targetName && validTargetNames.has(depTarget)) {
            depTargets.add(depTarget);
          }
        }
      }

      for (const imp of file.imports) {
        if (imp.moduleName && imp.isExternal && KNOWN_SYSTEM_MODULES.has(imp.moduleName)) {
          linkedFrameworks.add(imp.moduleName);
        }
      }
    }

    // Determine sourceRootName from files - if all files in this target share the same sourceRootName, use it
    const sourceRootNames = new Set(
      tFiles.map((f) => f.sourceRootName).filter((n): n is string => Boolean(n))
    );
    const sourceRootName = sourceRootNames.size === 1 ? Array.from(sourceRootNames)[0] : undefined;

    splitTargets.push({
      name: targetName,
      originalName: targetName,
      language,
      sourceFiles: sourceFiles.sort((a, b) => a.localeCompare(b)),
      headerFiles: headerFiles.sort((a, b) => a.localeCompare(b)),
      dependencies: Array.from(depTargets).sort((a, b) => a.localeCompare(b)),
      externalDependencies: [],
      // Filter out implicit modules that aren't actual linkable frameworks
      linkedFrameworks: Array.from(linkedFrameworks)
        .filter((fw) => !IMPLICIT_SWIFT_MODULES.has(fw))
        .sort((a, b) => a.localeCompare(b)),
      wasSplit: true,
      sourceRootName,
    });
  }

  return splitTargets;
}

// ============================================================================
// Main Analysis Functions
// ============================================================================

/** Default directories to exclude from analysis */
const DEFAULT_EXCLUDE_DIRS = ['**/Tests'];

/**
 * Analyzes a source directory and returns dependency information
 */
export async function analyzeSourceDirectory(options: AnalyzerOptions): Promise<AnalysisResult> {
  const {
    sourceRoot,
    excludeDirs = [],
    includePaths = [],
    verbose = false,
    useClang = false,
  } = options;

  // Combine user excludes with defaults
  const allExcludeDirs = [...new Set([...DEFAULT_EXCLUDE_DIRS, ...excludeDirs])];

  console.log(chalk.blue('\n📂 Analyzing source directory:'), chalk.gray(sourceRoot));

  // Step 1: Find all source files
  console.log(chalk.blue('\n🔍 Step 1: Finding source files...'));
  const { sources, headers } = await findSourceFiles(sourceRoot, allExcludeDirs);
  console.log(`   Found ${chalk.green(sources.length)} source files`);
  console.log(`   Found ${chalk.green(headers.length)} header files`);

  // Step 2: Build header map
  console.log(chalk.blue('\n📑 Step 2: Building header map...'));
  const headerMap = new Map<string, string>();
  for (const headerPath of headers) {
    const headerName = path.basename(headerPath);
    headerMap.set(headerName, headerPath);
    // Also map relative paths
    const relPath = path.relative(sourceRoot, headerPath);
    headerMap.set(relPath, headerPath);
  }
  console.log(`   Mapped ${chalk.green(headerMap.size)} headers`);

  // Step 3: Parse all files
  console.log(chalk.blue('\n📖 Step 3: Parsing imports...'));
  const files = new Map<string, SourceFile>();

  // Parse source files
  for (const filePath of sources) {
    const content = await fs.readFile(filePath, 'utf-8');
    const ext = path.extname(filePath).toLowerCase();
    const isSwift = ext === '.swift';

    const imports = isSwift ? parseSwiftImports(content) : parseObjCImports(content);

    const sourceFile: SourceFile = {
      filePath,
      relativePath: path.relative(sourceRoot, filePath),
      name: path.basename(filePath, ext),
      extension: ext,
      language: isSwift ? 'swift' : ext === '.cpp' ? 'cpp' : 'objc',
      imports,
      importedBy: [],
    };

    files.set(filePath, sourceFile);
  }

  // Parse header files too
  for (const filePath of headers) {
    const content = await fs.readFile(filePath, 'utf-8');
    const ext = path.extname(filePath).toLowerCase();
    const imports = parseObjCImports(content);

    const sourceFile: SourceFile = {
      filePath,
      relativePath: path.relative(sourceRoot, filePath),
      name: path.basename(filePath, ext),
      extension: ext,
      language: 'header',
      imports,
      importedBy: [],
    };

    files.set(filePath, sourceFile);
  }

  console.log(`   Parsed ${chalk.green(files.size)} files`);

  // Step 4: Build dependency graph
  // Note: process.platform is 'win32' on Windows, 'darwin' on macOS, 'linux' on Linux
  const useClangAnalysis = useClang && process.platform !== 'win32';
  if (useClangAnalysis) {
    console.log(chalk.blue('\n🔗 Step 4: Building dependency graph (using clang -MM)...'));
  } else {
    console.log(chalk.blue('\n🔗 Step 4: Building dependency graph (regex-based)...'));
  }

  const dependencyGraph = new Map<string, Set<string>>();
  const reverseDependencyGraph = new Map<string, Set<string>>();

  // Initialize graphs
  for (const filePath of files.keys()) {
    dependencyGraph.set(filePath, new Set());
    reverseDependencyGraph.set(filePath, new Set());
  }

  // Build default include paths from the source directory structure
  const defaultIncludePaths = [sourceRoot];
  // Add all directories containing headers
  for (const headerPath of headers) {
    const headerDir = path.dirname(headerPath);
    if (!defaultIncludePaths.includes(headerDir)) {
      defaultIncludePaths.push(headerDir);
    }
  }
  const allIncludePaths = [...defaultIncludePaths, ...includePaths];

  if (useClangAnalysis) {
    // Use clang -MM for accurate dependency resolution
    console.log(chalk.gray(`   Using ${allIncludePaths.length} include paths`));
    if (verbose) {
      for (const p of allIncludePaths.slice(0, 5)) {
        console.log(chalk.gray(`     -I ${p}`));
      }
      if (allIncludePaths.length > 5) {
        console.log(chalk.gray(`     ... and ${allIncludePaths.length - 5} more`));
      }
    }

    let processedCount = 0;
    const objcSources = Array.from(files.values()).filter(
      (f) => f.language === 'objc' || f.language === 'cpp'
    );

    for (const file of objcSources) {
      const clangDeps = getClangDependencies(file.filePath, allIncludePaths, verbose);
      processedCount++;

      for (const depPath of clangDeps) {
        // Normalize the path
        const normalizedDepPath = path.resolve(depPath);

        // Check if this dependency is in our file set
        if (files.has(normalizedDepPath)) {
          dependencyGraph.get(file.filePath)!.add(normalizedDepPath);
          reverseDependencyGraph.get(normalizedDepPath)!.add(file.filePath);
          files.get(normalizedDepPath)!.importedBy.push(file.filePath);
        } else if (headerMap.has(path.basename(depPath))) {
          // Try to find by basename
          const headerPath = headerMap.get(path.basename(depPath))!;
          dependencyGraph.get(file.filePath)!.add(headerPath);
          reverseDependencyGraph.get(headerPath)!.add(file.filePath);
          files.get(headerPath)!.importedBy.push(file.filePath);
        }
      }

      if (verbose && processedCount % 20 === 0) {
        console.log(chalk.gray(`   Processed ${processedCount}/${objcSources.length} files...`));
      }
    }

    console.log(chalk.gray(`   Analyzed ${processedCount} ObjC/C++ files with clang`));
  }

  // Always use regex-based resolution for Swift files and as fallback
  for (const [filePath, file] of files) {
    // Skip ObjC files if we already processed them with clang
    if (useClangAnalysis && (file.language === 'objc' || file.language === 'cpp')) {
      continue;
    }

    for (const imp of file.imports) {
      if (imp.isExternal) continue;

      // Try to resolve the import to a file
      let resolvedPath: string | undefined;

      if (imp.headerName) {
        // Try direct header name
        resolvedPath = headerMap.get(imp.headerName);

        // Try with module prefix path
        if (!resolvedPath && imp.moduleName) {
          const withModule = `${imp.moduleName}/${imp.headerName}`;
          resolvedPath = headerMap.get(withModule);
        }

        // Try finding by basename
        if (!resolvedPath) {
          const basename = path.basename(imp.headerName);
          resolvedPath = headerMap.get(basename);
        }
      }

      if (resolvedPath && files.has(resolvedPath)) {
        dependencyGraph.get(filePath)!.add(resolvedPath);
        reverseDependencyGraph.get(resolvedPath)!.add(filePath);
        files.get(resolvedPath)!.importedBy.push(filePath);
      }
    }
  }

  // Count edges
  let edgeCount = 0;
  for (const deps of dependencyGraph.values()) {
    edgeCount += deps.size;
  }
  console.log(`   Built graph with ${chalk.green(edgeCount)} edges`);

  // Step 5: Detect cycles
  console.log(chalk.blue('\n🔄 Step 5: Detecting cycles...'));
  const cycles = detectCycles(dependencyGraph);
  if (cycles.length > 0) {
    console.log(chalk.yellow(`   Found ${cycles.length} potential cycles`));
  } else {
    console.log(chalk.green('   No cycles detected'));
  }

  return {
    files,
    headers: headerMap,
    dependencyGraph,
    reverseDependencyGraph,
    cycles,
    splitTargets: [], // Will be populated by runAnalysis if --virtual-targets-scc is used
    sourceRoot,
  };
}

// ============================================================================
// Reporting Functions
// ============================================================================

/**
 * Prints a summary of the analysis results
 */
export function printAnalysisSummary(result: AnalysisResult): void {
  console.log(chalk.blue('\n' + '='.repeat(60)));
  console.log(chalk.blue.bold('📊 Analysis Summary'));
  console.log(chalk.blue('='.repeat(60)));

  // File statistics
  let swiftCount = 0;
  let objcCount = 0;
  let cppCount = 0;
  let headerCount = 0;

  for (const file of result.files.values()) {
    switch (file.language) {
      case 'swift':
        swiftCount++;
        break;
      case 'objc':
        objcCount++;
        break;
      case 'cpp':
        cppCount++;
        break;
      case 'header':
        headerCount++;
        break;
    }
  }

  console.log(chalk.white('\n📁 File Breakdown:'));
  console.log(`   Swift files:       ${chalk.cyan(swiftCount)}`);
  console.log(`   Objective-C files: ${chalk.cyan(objcCount)}`);
  console.log(`   C++ files:         ${chalk.cyan(cppCount)}`);
  console.log(`   Header files:      ${chalk.cyan(headerCount)}`);

  // Split targets (SPM-compatible)
  if (result.splitTargets.length > 0) {
    console.log(chalk.white('\n🔀 Split Targets (SPM-compatible):'));
    for (const target of result.splitTargets) {
      const splitIndicator = target.wasSplit ? chalk.magenta(' [split]') : '';
      const langColor = target.language === 'swift' ? chalk.cyan : chalk.yellow;
      console.log(`\n   ${langColor(target.name)}${splitIndicator}`);
      console.log(`      Language: ${target.language}`);
      console.log(`      Source files: ${target.sourceFiles.length}`);
      if (target.headerFiles.length > 0) {
        console.log(`      Header files: ${target.headerFiles.length}`);
      }
      if (target.dependencies.length > 0) {
        console.log(`      ${chalk.white('Dependencies:')} ${target.dependencies.join(', ')}`);
      }
      if (target.externalDependencies.length > 0) {
        console.log(
          `      ${chalk.gray('External deps:')} ${target.externalDependencies.join(', ')}`
        );
      }
      if (target.linkedFrameworks.length > 0) {
        console.log(
          `      ${chalk.blue('Linked frameworks:')} ${target.linkedFrameworks.join(', ')}`
        );
      }
    }

    // Check for potential circular dependencies between split targets
    const circularDeps: string[] = [];
    for (const target of result.splitTargets) {
      for (const dep of target.dependencies) {
        const depTarget = result.splitTargets.find((t) => t.name === dep);
        if (depTarget && depTarget.dependencies.includes(target.name)) {
          const pair = [target.name, dep].sort().join(' <-> ');
          if (!circularDeps.includes(pair)) {
            circularDeps.push(pair);
          }
        }
      }
    }

    if (circularDeps.length > 0) {
      console.log(chalk.red('\n⚠️  Circular Dependencies Between Split Targets:'));
      for (const pair of circularDeps) {
        console.log(`   ${chalk.red('•')} ${pair}`);
      }
    }
  }

  // Cycles
  if (result.cycles.length > 0) {
    console.log(chalk.red('\n⚠️  Detected Cycles:'));
    for (const cycle of result.cycles.slice(0, 10)) {
      // Show first 10
      const shortCycle = cycle.map((f) => path.basename(f)).join(' → ');
      console.log(`   ${chalk.red('•')} ${shortCycle}`);
    }
    if (result.cycles.length > 10) {
      console.log(chalk.gray(`   ... and ${result.cycles.length - 10} more`));
    }
  }

  console.log(chalk.blue('\n' + '='.repeat(60) + '\n'));
}

/**
 * Prints detailed dependency information for a specific file
 */
export function printFileDependencies(result: AnalysisResult, filePath: string): void {
  const file = result.files.get(filePath);
  if (!file) {
    console.log(chalk.red(`File not found: ${filePath}`));
    return;
  }

  console.log(chalk.blue(`\n📄 ${file.relativePath}`));
  console.log(`   Language: ${file.language}`);

  console.log(chalk.white('\n   Imports:'));
  for (const imp of file.imports) {
    const prefix = imp.isExternal ? chalk.gray('(external)') : '';
    console.log(`      ${imp.type}: ${imp.raw} ${prefix}`);
  }

  const deps = result.dependencyGraph.get(filePath);
  if (deps && deps.size > 0) {
    console.log(chalk.white('\n   Depends on:'));
    for (const dep of deps) {
      const relPath = path.relative(path.dirname(filePath), dep);
      console.log(`      → ${relPath}`);
    }
  }

  const reverseDeps = result.reverseDependencyGraph.get(filePath);
  if (reverseDeps && reverseDeps.size > 0) {
    console.log(chalk.white('\n   Used by:'));
    for (const dep of reverseDeps) {
      const relPath = path.relative(path.dirname(filePath), dep);
      console.log(`      ← ${relPath}`);
    }
  }
}

/**
 * Exports the dependency graph in DOT format for visualization
 */
export function exportDotGraph(result: AnalysisResult, outputPath: string): void {
  const lines: string[] = ['digraph dependencies {', '  rankdir=LR;', '  node [shape=box];'];

  // Create node IDs
  const nodeIds = new Map<string, string>();
  let nodeCounter = 0;
  for (const filePath of result.files.keys()) {
    const id = `n${nodeCounter++}`;
    nodeIds.set(filePath, id);
    const label = path.basename(filePath);
    lines.push(`  ${id} [label="${label}"];`);
  }

  // Add edges
  for (const [from, deps] of result.dependencyGraph) {
    const fromId = nodeIds.get(from);
    for (const to of deps) {
      const toId = nodeIds.get(to);
      if (fromId && toId) {
        lines.push(`  ${fromId} -> ${toId};`);
      }
    }
  }

  lines.push('}');

  fs.writeFileSync(outputPath, lines.join('\n'));
  console.log(chalk.green(`\n✅ DOT graph exported to: ${outputPath}`));
}

/**
 * Exports analysis results to JSON
 */
export async function exportAnalysisJson(
  result: AnalysisResult,
  outputPath: string
): Promise<void> {
  const exportData = {
    files: Array.from(result.files.values()).map((f) => ({
      path: f.relativePath,
      name: f.name,
      language: f.language,
      imports: f.imports,
      importedByCount: f.importedBy.length,
    })),
    cycles: result.cycles.map((c) =>
      c.map((f) => {
        const file = result.files.get(f);
        return file?.relativePath || f;
      })
    ),
    splitTargets: result.splitTargets.map((t) => ({
      name: t.name,
      originalName: t.originalName,
      language: t.language,
      wasSplit: t.wasSplit,
      sourceFiles: t.sourceFiles,
      headerFiles: t.headerFiles,
      dependencies: t.dependencies,
      externalDependencies: t.externalDependencies,
    })),
    statistics: {
      totalFiles: result.files.size,
      totalHeaders: result.headers.size,
      totalCycles: result.cycles.length,
      splitTargetCount: result.splitTargets.length,
      mixedTargetsCount: result.splitTargets.filter((t) => t.wasSplit).length / 2,
    },
  };

  await fs.writeJson(outputPath, exportData, { spaces: 2 });
  console.log(chalk.green(`\n✅ Analysis exported to: ${outputPath}`));
}

/**
 * SPM Config Types (matching spm.config.schema.json)
 * Note: Targets are now at root level, products reference targets by name
 */
interface SpmConfigTarget {
  type: 'objc' | 'swift' | 'cpp' | 'framework';
  name: string;
  path: string;
  pattern?: string;
  headerPattern?: string;
  dependencies?: string[];
  exclude?: string[];
  includeDirectories?: string[];
  useIncludesFrom?: string[];
  linkedFrameworks?: string[];
  plugins?: string[];
}

interface SpmConfigProduct {
  name: string;
  /** List of target names (references targets by name from the root targets array) */
  targets: string[];
}

interface SpmConfig {
  $schema: string;
  platforms: string[];
  /** List of external Swift Package dependencies (moved from product level) */
  externalDependencies?: string[];
  /** Flat list of all targets with their dependencies */
  targets: SpmConfigTarget[];
  /** Products reference targets by name */
  products: SpmConfigProduct[];
}

/**
 * Exports analysis results as spm.config.json compatible format
 * If autoBridge is true, automatically creates bridging targets to break cycles
 * Otherwise throws an error if cyclic dependencies are detected
 */
export async function exportSpmConfig(
  result: AnalysisResult,
  outputPath: string,
  sourceRoot: string,
  externalDeps?: string[],
  autoBridge: boolean = false,
  consolidateSwift: boolean = false,
  splitTargetsOverride?: SplitTarget[],
  productDefinitions?: ProductDefinition[],
  mergeSwift: boolean = false,
  excludeFromPrebuild?: string[],
  mergeHeaderTargets: boolean = false,
  mergeObjc: boolean = false
): Promise<void> {
  // Use provided split targets or from result
  const initialSplitTargets = splitTargetsOverride ?? result.splitTargets;

  // Simple cycle detection using findStronglyConnectedComponents
  function detectCyclesInTargets(targets: SplitTarget[]): string[][] {
    const graph = new Map<string, Set<string>>();
    for (const t of targets) {
      graph.set(t.name, new Set(t.dependencies.filter((d) => targets.some((t2) => t2.name === d))));
    }
    const sccs = findStronglyConnectedComponents(graph);
    return sccs.filter(
      (scc) => scc.length > 1 || (scc.length === 1 && scc[0] && graph.get(scc[0])?.has(scc[0]))
    );
  }

  const cycles = detectCyclesInTargets(initialSplitTargets);

  // Determine the path prefix (the directory name being analyzed, e.g., "ios")
  const pathPrefix = path.basename(sourceRoot);

  // Use provided external deps, or empty array
  const productExternalDeps = externalDeps && externalDeps.length > 0 ? externalDeps : [];

  // If we have cycles, report them as an error (autoBridge is no longer supported)
  let splitTargetsToUse = initialSplitTargets;

  if (cycles.length > 0) {
    console.log(chalk.red('\n❌ ERROR: Cyclic dependencies detected in targets!\n'));
    console.log(chalk.red('The following cycles were found:'));
    for (const cycle of cycles) {
      const cycleStr = [...cycle, cycle[0]].join(' → ');
      console.log(chalk.red(`   • ${cycleStr}`));
    }
    console.log(chalk.yellow('\nFix by:'));
    console.log(chalk.yellow('   1. Refactoring the code to remove cyclic imports'));
    console.log(chalk.yellow('   2. Using --virtual-targets-scc for SCC-based target grouping'));
    console.log();
    throw new Error(`Cyclic dependencies detected: ${cycles.map((c) => c.join(' → ')).join('; ')}`);
  }

  // Handle Swift consolidation - merge all non-base Swift into a single target
  // This creates a layered architecture:
  //   Swift_base (pure Swift, no ObjC deps) <- ObjC targets <- Swift_main (can use ObjC)
  if (consolidateSwift) {
    console.log(chalk.yellow('\n🔄 Consolidating Swift targets into layered architecture...\n'));

    // Identify Swift base targets (since autoBridge is no longer supported, this will be empty)
    const swiftBaseTargetNames = new Set<string>();

    // Collect all Swift files from non-base Swift targets
    const swiftMainFiles: string[] = [];
    const swiftTargetsToRemove: string[] = [];

    for (const target of splitTargetsToUse) {
      if (target.language === 'swift' && !swiftBaseTargetNames.has(target.name)) {
        swiftMainFiles.push(...target.sourceFiles);
        swiftTargetsToRemove.push(target.name);
        console.log(chalk.gray(`   Merging ${target.name}: ${target.sourceFiles.length} file(s)`));
      }
    }

    if (swiftMainFiles.length > 0) {
      // Get all ObjC target names (for Swift_main to depend on)
      const objcTargetNames = splitTargetsToUse
        .filter((t) => t.language === 'objc' || t.language === 'cpp')
        .map((t) => t.name);

      // Create the consolidated Swift_main target
      const swiftMainTarget: SplitTarget = {
        name: 'Swift_main',
        originalName: 'Swift_main',
        language: 'swift',
        sourceFiles: swiftMainFiles,
        headerFiles: [],
        dependencies: [...objcTargetNames, ...productExternalDeps],
        externalDependencies: [],
        linkedFrameworks: [],
        wasSplit: false,
      };

      // Remove individual Swift targets and add Swift_main
      splitTargetsToUse = splitTargetsToUse.filter((t) => !swiftTargetsToRemove.includes(t.name));
      splitTargetsToUse.push(swiftMainTarget);

      console.log(
        chalk.green(
          `\n   Created Swift_main with ${swiftMainFiles.length} file(s), depending on ${objcTargetNames.length} ObjC target(s)\n`
        )
      );

      // Update ObjC targets to depend on Swift_base targets (if any)
      if (swiftBaseTargetNames.size > 0) {
        splitTargetsToUse = splitTargetsToUse.map((target) => {
          if (target.language === 'objc' || target.language === 'cpp') {
            const newDeps = [...target.dependencies];
            for (const baseName of swiftBaseTargetNames) {
              if (!newDeps.includes(baseName)) {
                newDeps.push(baseName);
              }
            }
            return { ...target, dependencies: newDeps };
          }
          return target;
        });
      }
    }
  }

  // Handle simple Swift merging - merge Swift files into targets PER PRODUCT
  // This is simpler than consolidateSwift and useful for modules with heavy ObjC interop
  // where Swift files use ObjC types through bridging
  if (mergeSwift && !consolidateSwift) {
    console.log(chalk.yellow('\n🔄 Merging Swift targets per product...\n'));

    // Group Swift targets by product
    const swiftTargetsByProduct = new Map<string, SplitTarget[]>();
    const swiftTargetsToRemove: string[] = [];

    for (const target of splitTargetsToUse) {
      if (target.language === 'swift') {
        const productName = getTargetProduct(target, productDefinitions) || '_default';
        if (!swiftTargetsByProduct.has(productName)) {
          swiftTargetsByProduct.set(productName, []);
        }
        swiftTargetsByProduct.get(productName)!.push(target);
        swiftTargetsToRemove.push(target.name);
      }
    }

    // Create merged Swift target for each product
    const newSwiftTargets: SplitTarget[] = [];
    const swiftTargetNameMap = new Map<string, string>(); // old name -> new name

    for (const [productName, targets] of swiftTargetsByProduct) {
      if (targets.length === 0) continue;

      const allSwiftFiles: string[] = [];
      const allLinkedFrameworks = new Set<string>();
      const allDependencies = new Set<string>(productExternalDeps);

      for (const target of targets) {
        allSwiftFiles.push(...target.sourceFiles);
        for (const fw of target.linkedFrameworks) {
          allLinkedFrameworks.add(fw);
        }
        for (const dep of target.dependencies) {
          allDependencies.add(dep);
        }
        console.log(
          chalk.gray(
            `   [${productName}] Merging ${target.name}: ${target.sourceFiles.length} file(s)`
          )
        );
      }

      // Remove Swift target names from dependencies (they're being merged within this product)
      for (const target of targets) {
        allDependencies.delete(target.name);
      }

      // Determine target name based on product
      // Use SCCM_swift for catch-all product, SCCM_{product}_swift for specific products
      const catchAllProduct = productDefinitions?.find((p) => p.pathPatterns.includes('*'));
      const mergedTargetName =
        productName === '_default' || productName === catchAllProduct?.name
          ? 'SCCM_swift'
          : `SCCM_${productName}_swift`;

      // Map old target names to new merged name
      for (const target of targets) {
        swiftTargetNameMap.set(target.name, mergedTargetName);
      }

      const mergedSwiftTarget: SplitTarget = {
        name: mergedTargetName,
        originalName: mergedTargetName,
        language: 'swift',
        sourceFiles: allSwiftFiles,
        headerFiles: [],
        dependencies: Array.from(allDependencies),
        externalDependencies: [],
        linkedFrameworks: Array.from(allLinkedFrameworks).filter(
          (fw) => !IMPLICIT_SWIFT_MODULES.has(fw)
        ),
        wasSplit: false,
      };

      newSwiftTargets.push(mergedSwiftTarget);

      console.log(
        chalk.green(
          `   Created ${mergedTargetName} with ${allSwiftFiles.length} file(s), ${allLinkedFrameworks.size} framework(s)`
        )
      );
    }

    // Remove individual Swift targets and add merged targets
    splitTargetsToUse = splitTargetsToUse.filter((t) => !swiftTargetsToRemove.includes(t.name));
    splitTargetsToUse.push(...newSwiftTargets);

    // Update dependencies to point to merged targets
    splitTargetsToUse = splitTargetsToUse.map((target) => {
      if (newSwiftTargets.some((t) => t.name === target.name)) return target;
      const newDeps = target.dependencies.map((dep) => swiftTargetNameMap.get(dep) || dep);
      return { ...target, dependencies: [...new Set(newDeps)] };
    });

    // Now add SCCM_* ObjC/C++ targets as dependencies to Swift targets
    const objcTargetNames = splitTargetsToUse
      .filter((t) => (t.language === 'objc' || t.language === 'cpp') && /^SCCM_/.test(t.name))
      .map((t) => t.name);

    splitTargetsToUse = splitTargetsToUse.map((target) => {
      if (target.language !== 'swift') return target;
      const newDeps = new Set(target.dependencies);
      for (const objcTarget of objcTargetNames) {
        newDeps.add(objcTarget);
      }
      return { ...target, dependencies: Array.from(newDeps) };
    });

    console.log(chalk.green(`\n   Created ${newSwiftTargets.length} merged Swift target(s)\n`));
  }

  // Handle ObjC merging - merge ObjC files into targets PER PRODUCT
  // This helps avoid cross-module header issues where headers use #import <ProductName/Header.h> syntax
  if (mergeObjc) {
    console.log(chalk.yellow('\n🔄 Merging ObjC targets per product...\n'));

    // Group ObjC targets by product
    const objcTargetsByProduct = new Map<string, SplitTarget[]>();
    const objcTargetsToRemove: string[] = [];

    for (const target of splitTargetsToUse) {
      // Include ObjC targets and also header-only "cpp" targets that have .h files
      // (header-only targets get language='cpp' because they have no source files)
      const isObjcTarget = target.language === 'objc';
      const isHeaderOnlyObjcTarget =
        target.language === 'cpp' &&
        target.sourceFiles.length === 0 &&
        target.headerFiles.length > 0 &&
        target.headerFiles.every((h) => h.endsWith('.h'));

      if (isObjcTarget || isHeaderOnlyObjcTarget) {
        const productName = getTargetProduct(target, productDefinitions) || '_default';
        if (!objcTargetsByProduct.has(productName)) {
          objcTargetsByProduct.set(productName, []);
        }
        objcTargetsByProduct.get(productName)!.push(target);
        objcTargetsToRemove.push(target.name);
      }
    }

    // Create merged ObjC target for each product
    const newObjcTargets: SplitTarget[] = [];
    const objcTargetNameMap = new Map<string, string>(); // old name -> new name

    for (const [productName, targets] of objcTargetsByProduct) {
      if (targets.length === 0) continue;

      const allObjcSourceFiles: string[] = [];
      const allObjcHeaderFiles: string[] = [];
      const allObjcLinkedFrameworks = new Set<string>();
      const allObjcDependencies = new Set<string>(productExternalDeps);

      for (const target of targets) {
        allObjcSourceFiles.push(...target.sourceFiles);
        allObjcHeaderFiles.push(...target.headerFiles);
        for (const fw of target.linkedFrameworks) {
          allObjcLinkedFrameworks.add(fw);
        }
        for (const dep of target.dependencies) {
          allObjcDependencies.add(dep);
        }
        console.log(
          chalk.gray(
            `   [${productName}] Merging ${target.name}: ${target.sourceFiles.length} file(s), ${target.headerFiles.length} header(s)`
          )
        );
      }

      // Remove ObjC target names from dependencies (they're being merged within this product)
      for (const target of targets) {
        allObjcDependencies.delete(target.name);
      }

      // Determine target name based on product
      // Use SCCM_objc for catch-all product, SCCM_{product}_objc for specific products
      const catchAllProduct = productDefinitions?.find((p) => p.pathPatterns.includes('*'));
      const mergedTargetName =
        productName === '_default' || productName === catchAllProduct?.name
          ? 'SCCM_objc'
          : `SCCM_${productName}_objc`;

      // Map old target names to new merged name
      for (const target of targets) {
        objcTargetNameMap.set(target.name, mergedTargetName);
      }

      if (allObjcSourceFiles.length > 0 || allObjcHeaderFiles.length > 0) {
        const mergedObjcTarget: SplitTarget = {
          name: mergedTargetName,
          originalName: mergedTargetName,
          language: 'objc',
          sourceFiles: allObjcSourceFiles,
          headerFiles: allObjcHeaderFiles,
          dependencies: Array.from(allObjcDependencies),
          externalDependencies: [],
          linkedFrameworks: Array.from(allObjcLinkedFrameworks).filter(
            (fw) => !IMPLICIT_SWIFT_MODULES.has(fw)
          ),
          wasSplit: false,
        };

        newObjcTargets.push(mergedObjcTarget);

        console.log(
          chalk.green(
            `   Created ${mergedTargetName} with ${allObjcSourceFiles.length} source file(s), ${allObjcHeaderFiles.length} header(s)`
          )
        );
      }
    }

    // Remove individual ObjC targets and add merged targets
    splitTargetsToUse = splitTargetsToUse.filter((t) => !objcTargetsToRemove.includes(t.name));
    splitTargetsToUse.push(...newObjcTargets);

    // Update dependencies to point to merged targets
    splitTargetsToUse = splitTargetsToUse.map((target) => {
      if (newObjcTargets.some((t) => t.name === target.name)) return target;
      const newDeps = target.dependencies.map((dep) => objcTargetNameMap.get(dep) || dep);
      return { ...target, dependencies: [...new Set(newDeps)] };
    });

    // Add C++ targets as dependencies to ObjC targets (they're separate)
    const cppTargetNames = splitTargetsToUse
      .filter((t) => t.language === 'cpp' && !objcTargetsToRemove.includes(t.name))
      .map((t) => t.name);

    splitTargetsToUse = splitTargetsToUse.map((target) => {
      if (target.language !== 'objc') return target;
      const newDeps = new Set(target.dependencies);
      for (const cppTarget of cppTargetNames) {
        newDeps.add(cppTarget);
      }
      return { ...target, dependencies: Array.from(newDeps) };
    });

    console.log(chalk.green(`\n   Created ${newObjcTargets.length} merged ObjC target(s)\n`));
  }

  // Handle header-only target merging - fold headers from header-only SCC{N}_objc targets
  // INTO their dependent SCCM_* targets. This keeps headers with targets that have the correct
  // dependencies, avoiding cross-module include issues.
  // This significantly reduces the number of targets SPM has to process.
  if (mergeHeaderTargets) {
    console.log(
      chalk.yellow('\n🔄 Folding header-only targets into their dependent SCCM targets...\n')
    );

    // Find all header-only targets (SCC{N}_objc targets with only headers, no source files)
    const headerOnlyTargets: SplitTarget[] = [];
    const headerOnlyTargetNames = new Set<string>();

    for (const target of splitTargetsToUse) {
      // Match SCC{N}_objc targets that only have headers
      if (
        /^SCC\d+_objc$/.test(target.name) &&
        target.sourceFiles.length === 0 &&
        target.headerFiles.length > 0
      ) {
        headerOnlyTargets.push(target);
        headerOnlyTargetNames.add(target.name);
      }
    }

    if (headerOnlyTargets.length > 0) {
      // For each SCCM_* target that depends on header-only targets,
      // fold those headers into the SCCM target and remove the dependency
      let foldedCount = 0;

      splitTargetsToUse = splitTargetsToUse.map((target) => {
        // Skip header-only targets (they'll be removed)
        if (headerOnlyTargetNames.has(target.name)) return target;

        // Find header-only dependencies
        const headerOnlyDeps = target.dependencies.filter((dep) => headerOnlyTargetNames.has(dep));
        if (headerOnlyDeps.length === 0) return target;

        // Collect headers from all header-only dependencies
        const additionalHeaders: string[] = [];
        const additionalDeps = new Set<string>();

        for (const depName of headerOnlyDeps) {
          const headerOnlyTarget = headerOnlyTargets.find((t) => t.name === depName);
          if (headerOnlyTarget) {
            additionalHeaders.push(...headerOnlyTarget.headerFiles);
            // Also add the header-only target's dependencies (except other header-only targets)
            for (const transitiveDep of headerOnlyTarget.dependencies) {
              if (!headerOnlyTargetNames.has(transitiveDep)) {
                additionalDeps.add(transitiveDep);
              }
            }
          }
        }

        // Remove header-only deps and add transitive deps
        const newDeps = target.dependencies.filter((dep) => !headerOnlyTargetNames.has(dep));
        for (const dep of additionalDeps) {
          if (!newDeps.includes(dep)) {
            newDeps.push(dep);
          }
        }

        console.log(
          chalk.gray(
            `   Folding ${additionalHeaders.length} header(s) from ${headerOnlyDeps.length} target(s) into ${target.name}`
          )
        );
        foldedCount += headerOnlyDeps.length;

        return {
          ...target,
          headerFiles: [...target.headerFiles, ...additionalHeaders],
          dependencies: newDeps,
          foldedCount,
        };
      });

      // Remove the header-only targets
      splitTargetsToUse = splitTargetsToUse.filter((t) => !headerOnlyTargetNames.has(t.name));

      console.log(
        chalk.green(
          `\n   Removed ${headerOnlyTargets.length} header-only targets by folding into SCCM targets\n`
        )
      );
    }
  }

  // Build the targets array, filtering out invalid targets
  const targets: SpmConfigTarget[] = splitTargetsToUse
    .filter((splitTarget) => {
      // Skip targets with invalid names (like "." or empty)
      if (!splitTarget.name || splitTarget.name === '.' || splitTarget.name.trim() === '') {
        return false;
      }
      // Skip targets with no files at all
      if (splitTarget.sourceFiles.length === 0 && splitTarget.headerFiles.length === 0) {
        return false;
      }
      return true;
    })
    .map((splitTarget) => {
      // Determine the target type
      const type =
        splitTarget.language === 'swift'
          ? 'swift'
          : splitTarget.language === 'cpp'
            ? 'cpp'
            : 'objc';

      // For consolidated Swift_main target, include files from multiple directories
      const isSwiftMainTarget = splitTarget.name === 'Swift_main' && consolidateSwift;
      if (isSwiftMainTarget && splitTarget.sourceFiles.length > 0) {
        // Filter dependencies
        const validTargetNames = new Set(
          splitTargetsToUse
            .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
            .map((t) => t.name)
        );
        const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
        // Include cross-product dependencies (e.g., JSI from ExpoModulesJSI)
        // Filter out system modules and invalid dependency names
        const crossProductDeps = splitTarget.externalDependencies.filter(
          (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
        );
        const allDeps = [...internalDeps, ...crossProductDeps, ...productExternalDeps];

        // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
        const effectivePathPrefix = splitTarget.sourceRootName || pathPrefix;

        // Swift_main can span multiple directories; use an explicit glob pattern from the file list.
        const target: SpmConfigTarget = {
          type: 'swift',
          name: splitTarget.name,
          path: effectivePathPrefix, // e.g. "ios"
        };

        const pattern = toGlobBraceList(splitTarget.sourceFiles);
        if (pattern) {
          target.pattern = pattern;
        }

        if (allDeps.length > 0) {
          target.dependencies = allDeps;
        }

        if (splitTarget.linkedFrameworks.length > 0) {
          target.linkedFrameworks = splitTarget.linkedFrameworks;
        }

        return target;
      }

      // Regular target handling
      const allFiles = [...splitTarget.sourceFiles, ...splitTarget.headerFiles];
      const commonPath = findCommonPath(allFiles);

      // SCC-derived targets commonly span multiple directories.
      // Emit an explicit glob pattern from the file list (relative to sourceRoot)
      // to keep the generated config actionable.
      const looksLikeSccDerivedTarget =
        /^SCC\d+_/.test(splitTarget.name) || /^SCCM_/.test(splitTarget.name);
      if (looksLikeSccDerivedTarget) {
        // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
        const targetPath = splitTarget.sourceRootName || pathPrefix;

        const allDeps = (() => {
          const validTargetNames = new Set(
            splitTargetsToUse
              .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
              .map((t) => t.name)
          );
          const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
          const crossProductDeps = splitTarget.externalDependencies.filter(
            (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
          );
          return [...internalDeps, ...crossProductDeps, ...productExternalDeps];
        })();

        const target: SpmConfigTarget = {
          type,
          name: splitTarget.name,
          path: targetPath,
        };

        // Filter out excluded files BEFORE creating the pattern
        let sourceFilesForPattern = splitTarget.sourceFiles;
        if (excludeFromPrebuild && excludeFromPrebuild.length > 0) {
          const filesToExclude = splitTarget.sourceFiles.filter((file) =>
            excludeFromPrebuild.some((pattern) => {
              // Strip leading **/ from glob patterns for simple matching
              const cleanPattern = pattern.replace(/^\*\*\//, '');
              return file.includes(cleanPattern) || file.endsWith(cleanPattern);
            })
          );
          if (filesToExclude.length > 0) {
            sourceFilesForPattern = splitTarget.sourceFiles.filter(
              (file) => !filesToExclude.includes(file)
            );
            target.exclude = filesToExclude;
          }
        }

        const pattern = toGlobBraceList(sourceFilesForPattern);
        if (pattern) {
          target.pattern = pattern;
        } else if ((type === 'objc' || type === 'cpp') && splitTarget.headerFiles.length > 0) {
          // Prevent default source globbing from pulling in unrelated sources for header-only targets.
          // This matches the existing convention used for bridging/header-only targets.
          target.pattern = '!*.m';
        } else if (sourceFilesForPattern.length === 0 && splitTarget.sourceFiles.length > 0) {
          // All source files were excluded from prebuild - set empty pattern to prevent default globbing
          target.pattern = '!*';
        }

        const headerPattern = toGlobBraceList(splitTarget.headerFiles);
        console.log(
          `DEBUG ${splitTarget.name}: type=${type} headerFiles=${splitTarget.headerFiles.length} sourceFilesForPattern=${sourceFilesForPattern.length} headerPattern=${!!headerPattern}`
        );
        if (headerPattern) {
          target.headerPattern = headerPattern;
        } else if (
          (type === 'objc' || type === 'cpp') &&
          sourceFilesForPattern.length > 0 &&
          splitTarget.headerFiles.length === 0
        ) {
          // If no explicit headers but we have source files, derive header pattern from source directories.
          // This ensures ObjC/C++ targets can find headers in their source folders.
          const sourceDirs = new Set<string>();
          for (const file of sourceFilesForPattern) {
            const dir = path.dirname(file);
            sourceDirs.add(dir === '.' ? '' : dir);
          }
          // Create a glob pattern for headers in those directories
          const headerGlobs = Array.from(sourceDirs)
            .map((dir) => (dir ? `${dir}/*.h` : '*.h'))
            .sort();
          console.log(
            `DEBUG: ${splitTarget.name} sourceDirs=${Array.from(sourceDirs).join(',')} headerGlobs=${headerGlobs.join(',')}`
          );
          if (headerGlobs.length === 1) {
            target.headerPattern = headerGlobs[0];
          } else if (headerGlobs.length > 1) {
            target.headerPattern = `{${headerGlobs.join(',')}}`;
          }
        }

        if (allDeps.length > 0) {
          target.dependencies = allDeps;
        }

        if (splitTarget.linkedFrameworks.length > 0) {
          target.linkedFrameworks = splitTarget.linkedFrameworks;
        }

        if (type === 'objc' || type === 'cpp') {
          target.includeDirectories = ['.'];
        }

        return target;
      }

      // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
      const effectivePathPrefix = splitTarget.sourceRootName || pathPrefix;

      // Add the path prefix (e.g., "ios/") to the path
      const targetPath = path.join(
        effectivePathPrefix,
        commonPath || splitTarget.name.replace(/_swift$|_objc$|_Base$/, '')
      );

      // Filter dependencies to only include other valid targets
      const validTargetNames = new Set(
        splitTargetsToUse
          .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
          .map((t) => t.name)
      );
      const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
      // Include cross-product dependencies (e.g., JSI from ExpoModulesJSI)
      // Filter out system modules and invalid dependency names
      const crossProductDeps = splitTarget.externalDependencies.filter(
        (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
      );

      // Combine internal dependencies with cross-product and external dependencies
      const allDeps = [...internalDeps, ...crossProductDeps, ...productExternalDeps];

      const target: SpmConfigTarget = {
        type,
        name: splitTarget.name,
        path: targetPath,
      };

      // Only add dependencies if there are any
      if (allDeps.length > 0) {
        target.dependencies = allDeps;
      }

      // Only add linkedFrameworks if there are any
      if (splitTarget.linkedFrameworks.length > 0) {
        target.linkedFrameworks = splitTarget.linkedFrameworks;
      }

      // For ObjC targets, add include directories
      if (type === 'objc' || type === 'cpp') {
        target.includeDirectories = ['.'];
      }

      return target;
    });

  // Determine a meaningful product name
  // Try to get the package name from the parent directory of ios/
  const parentDir = path.dirname(sourceRoot);
  const packageJsonPath = path.join(parentDir, 'package.json');
  let defaultProductName = path.basename(parentDir);

  try {
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = fs.readJsonSync(packageJsonPath);
      if (packageJson.name) {
        // Convert package name to PascalCase product name
        defaultProductName = packageJson.name
          .replace(/^@[^/]+\//, '') // Remove scope
          .split(/[-_]/)
          .map((part: string) => part.charAt(0).toUpperCase() + part.slice(1))
          .join('');
      }
    }
  } catch {
    // Ignore errors, use default name
  }

  // Group targets into products based on path patterns
  const products = assignTargetsToProducts(
    targets,
    splitTargetsToUse,
    productDefinitions,
    defaultProductName,
    pathPrefix
  );

  // Resolve cross-product header dependencies
  // After products are assigned, we can now resolve angle-bracket imports like <ProductName/Header.h>
  // to the correct target and add missing dependencies
  resolveCrossProductDependencies(targets, splitTargetsToUse, products, result.files);

  // Create the SPM config with targets at root level
  // Products now reference targets by name
  const spmConfig: SpmConfig = {
    $schema: '../../tools/src/prebuilds/schemas/spm.config.schema.json',
    platforms: ['iOS(.v15)'],
    externalDependencies: productExternalDeps.length > 0 ? productExternalDeps : undefined,
    targets,
    products,
  };

  await fs.writeJson(outputPath, spmConfig, { spaces: 4 });
  console.log(chalk.green(`\n✅ SPM config exported to: ${outputPath}`));
}

/**
 * Resolves cross-product header dependencies by analyzing angle-bracket imports.
 *
 * When a file imports `<ProductName/Header.h>`, we need to find which target provides
 * that header (based on product assignment) and add it as a dependency.
 *
 * @param targets - The generated SPM config targets (will be mutated to add dependencies)
 * @param splitTargets - The original split targets with source file information
 * @param products - The product assignments (which targets belong to which product)
 * @param files - The analyzed source files with their imports
 */
function resolveCrossProductDependencies(
  targets: SpmConfigTarget[],
  splitTargets: SplitTarget[],
  products: { name: string; targets: string[] }[],
  files: Map<string, SourceFile>
): void {
  // Build a map of ProductName/HeaderName -> target name
  // For each product, collect all headers from its targets
  const productHeaderToTarget = new Map<string, string>();

  for (const product of products) {
    for (const targetName of product.targets) {
      const splitTarget = splitTargets.find((t) => t.name === targetName);
      if (!splitTarget) continue;

      for (const headerFile of splitTarget.headerFiles) {
        // The header will be available as <ProductName/HeaderBaseName.h>
        const headerBaseName = path.basename(headerFile);
        const key = `${product.name}/${headerBaseName}`;
        productHeaderToTarget.set(key, targetName);
      }
    }
  }

  // Build a map of target name -> SpmConfigTarget for easy lookup
  const targetMap = new Map<string, SpmConfigTarget>();
  for (const target of targets) {
    targetMap.set(target.name, target);
  }

  // Build a map of target name -> product name
  const targetToProduct = new Map<string, string>();
  for (const product of products) {
    for (const targetName of product.targets) {
      targetToProduct.set(targetName, product.name);
    }
  }

  // Build a map from file path to target name
  const fileToTarget = new Map<string, string>();
  for (const splitTarget of splitTargets) {
    for (const sourceFile of splitTarget.sourceFiles) {
      // We need to match by file name since we may not have the full path
      fileToTarget.set(sourceFile, splitTarget.name);
    }
  }

  // For each source file, check its imports and resolve cross-product dependencies
  for (const [filePath, sourceFile] of files.entries()) {
    // Find which target this file belongs to
    let owningTargetName: string | undefined;
    for (const splitTarget of splitTargets) {
      if (
        splitTarget.sourceFiles.some(
          (sf) => filePath.endsWith(sf) || sf.endsWith(path.basename(filePath))
        )
      ) {
        owningTargetName = splitTarget.name;
        break;
      }
    }

    if (!owningTargetName) continue;

    const owningTarget = targetMap.get(owningTargetName);
    if (!owningTarget) continue;

    // Check each angle-bracket import
    for (const imp of sourceFile.imports) {
      if (imp.type !== 'angle-bracket' || !imp.moduleName || !imp.headerName) {
        continue;
      }

      // Try to resolve <ModuleName/HeaderName.h> to a target
      const importKey = `${imp.moduleName}/${imp.headerName}`;
      const providingTarget = productHeaderToTarget.get(importKey);

      if (providingTarget && providingTarget !== owningTargetName) {
        // Add dependency if not already present
        if (!owningTarget.dependencies) {
          owningTarget.dependencies = [];
        }

        if (!owningTarget.dependencies.includes(providingTarget)) {
          owningTarget.dependencies.push(providingTarget);
        }
      }
    }
  }

  // Sort dependencies for consistent output
  for (const target of targets) {
    if (target.dependencies) {
      target.dependencies.sort((a, b) => a.localeCompare(b));
    }
  }
}

/**
 * Assigns targets to products based on path patterns.
 *
 * @param targets - The generated SPM config targets
 * @param splitTargets - The original split targets (contains source file paths)
 * @param productDefinitions - Optional product definitions with path patterns
 * @param defaultProductName - Default product name if no definitions provided
 * @param pathPrefix - The path prefix (e.g., "ios") used in target paths
 * @returns Array of product definitions with their target names
 */
function assignTargetsToProducts(
  targets: SpmConfigTarget[],
  splitTargets: SplitTarget[],
  productDefinitions: ProductDefinition[] | undefined,
  defaultProductName: string,
  pathPrefix: string
): { name: string; targets: string[] }[] {
  // If no product definitions provided, create a single product with all targets
  if (!productDefinitions || productDefinitions.length === 0) {
    return [
      {
        name: defaultProductName,
        targets: targets.map((t) => t.name),
      },
    ];
  }

  // Build a map from target name to its source file paths
  const targetToFilePaths = new Map<string, string[]>();
  for (const splitTarget of splitTargets) {
    const allFiles = [...splitTarget.sourceFiles, ...splitTarget.headerFiles];
    targetToFilePaths.set(splitTarget.name, allFiles);
  }

  // Also add target paths from the generated config (for targets that might have been created differently)
  for (const target of targets) {
    if (!targetToFilePaths.has(target.name) && target.path) {
      // Use the target's path as a hint
      targetToFilePaths.set(target.name, [target.path]);
    }
  }

  // Find catch-all product (one with "*" pattern) and specific products
  let catchAllProduct: ProductDefinition | undefined;
  const specificProducts: ProductDefinition[] = [];

  for (const prodDef of productDefinitions) {
    if (prodDef.pathPatterns.includes('*')) {
      catchAllProduct = prodDef;
    } else {
      specificProducts.push(prodDef);
    }
  }

  // Initialize product target lists
  const productTargets = new Map<string, Set<string>>();
  for (const prodDef of productDefinitions) {
    productTargets.set(prodDef.name, new Set());
  }

  // Assign each target to a product based on path matching
  const assignedTargets = new Set<string>();

  for (const target of targets) {
    const targetFilePaths = targetToFilePaths.get(target.name) || [target.path || ''];

    // Check each specific product to see if this target matches
    for (const prodDef of specificProducts) {
      const matches = targetFilePaths.some((filePath) => {
        // Use the same matching logic as getFileProduct for consistency
        return prodDef.pathPatterns.some((pattern) => {
          // Check if the file path contains the pattern as a path component
          const patternWithSlashes = '/' + pattern + '/';
          const patternAtStart = pattern + '/';
          const patternAtEnd = '/' + pattern;

          return (
            filePath.includes(patternWithSlashes) || // /JSI/ anywhere in path
            filePath.startsWith(patternAtStart) || // JSI/ at start
            filePath.endsWith(patternAtEnd) || // ends with /JSI (directory)
            filePath === pattern || // exact match
            // Also check for pattern as a directory component
            filePath.split('/').includes(pattern) ||
            // Also check the target's path property directly
            (target.path && target.path.split('/').includes(pattern))
          );
        });
      });

      if (matches) {
        productTargets.get(prodDef.name)?.add(target.name);
        assignedTargets.add(target.name);
        break; // First matching product wins
      }
    }
  }

  // Assign remaining targets to catch-all product
  const unassignedTargets = targets.filter((t) => !assignedTargets.has(t.name)).map((t) => t.name);

  if (unassignedTargets.length > 0) {
    if (catchAllProduct) {
      const catchAllSet = productTargets.get(catchAllProduct.name)!;
      for (const targetName of unassignedTargets) {
        catchAllSet.add(targetName);
      }
    } else {
      // Create default product for unassigned targets
      productTargets.set(defaultProductName, new Set(unassignedTargets));
    }
  }

  // Build the result, preserving the order from productDefinitions
  const result: { name: string; targets: string[] }[] = [];

  // First add specific products (in order defined)
  for (const prodDef of specificProducts) {
    const targetSet = productTargets.get(prodDef.name);
    if (targetSet && targetSet.size > 0) {
      result.push({
        name: prodDef.name,
        targets: Array.from(targetSet),
      });
    }
  }

  // Then add catch-all product
  if (catchAllProduct) {
    const targetSet = productTargets.get(catchAllProduct.name);
    if (targetSet && targetSet.size > 0) {
      result.push({
        name: catchAllProduct.name,
        targets: Array.from(targetSet),
      });
    }
  }

  // Finally add any default product if it was created
  if (!catchAllProduct && productTargets.has(defaultProductName)) {
    const targetSet = productTargets.get(defaultProductName);
    if (targetSet && targetSet.size > 0) {
      result.push({
        name: defaultProductName,
        targets: Array.from(targetSet),
      });
    }
  }

  // Log product assignment summary
  console.log(chalk.cyan('\n📦 Product assignment:'));
  for (const prod of result) {
    console.log(chalk.white(`   ${prod.name}: ${prod.targets.length} target(s)`));
  }

  return result;
}

/**
 * Finds the common base path for a list of file paths
 */
function findCommonPath(filePaths: string[]): string {
  if (filePaths.length === 0) return '.';
  if (filePaths.length === 1) return path.dirname(filePaths[0]);

  const dirs = filePaths.map((f) => path.dirname(f).split(path.sep));
  const commonParts: string[] = [];

  for (let i = 0; i < dirs[0].length; i++) {
    const part = dirs[0][i];
    if (dirs.every((d) => d[i] === part)) {
      commonParts.push(part);
    } else {
      break;
    }
  }

  return commonParts.length > 0 ? commonParts.join(path.sep) : '.';
}

// ============================================================================
// CLI Entry Point
// ============================================================================

/**
 * Main analysis function that can be called from the command line
 */
export async function runAnalysis(
  sourceRoot: string,
  options: {
    excludeDirs?: string[];
    includePaths?: string[];
    additionalSourceDirs?: string[];
    outputJson?: string;
    outputDot?: string;
    outputSpmConfig?: string;
    externalDeps?: string[];
    productDefinitions?: ProductDefinition[];
    virtualTargetsScc?: boolean;
    virtualTargetsSccMergeSingletons?: boolean;
    consolidateSwift?: boolean;
    mergeSwift?: boolean;
    mergeObjc?: boolean;
    mergeHeaderTargets?: boolean;
    excludeFromPrebuild?: string[];
    verbose?: boolean;
    useClang?: boolean;
  } = {}
): Promise<AnalysisResult> {
  // Analyze the primary source directory
  const result = await analyzeSourceDirectory({
    sourceRoot,
    excludeDirs: options.excludeDirs,
    includePaths: options.includePaths,
    verbose: options.verbose,
    useClang: options.useClang,
  });

  // Analyze additional source directories and merge results
  if (options.additionalSourceDirs && options.additionalSourceDirs.length > 0) {
    for (const additionalDir of options.additionalSourceDirs) {
      console.log(chalk.cyan(`\n📂 Analyzing additional source directory: ${additionalDir}`));

      const additionalResult = await analyzeSourceDirectory({
        sourceRoot: additionalDir,
        excludeDirs: options.excludeDirs,
        includePaths: options.includePaths,
        verbose: options.verbose,
        useClang: options.useClang,
      });

      // Tag split targets from additional sources with their source root name
      const additionalSourceRootName = path.basename(additionalDir);
      for (const splitTarget of additionalResult.splitTargets) {
        splitTarget.sourceRootName = additionalSourceRootName;
      }

      // Merge files (Map) - tag with sourceRootName for SCC analysis
      for (const [filePath, sourceFile] of additionalResult.files.entries()) {
        sourceFile.sourceRootName = additionalSourceRootName;
        result.files.set(filePath, sourceFile);
      }

      // Merge headers (Map)
      for (const [headerName, headerPath] of additionalResult.headers.entries()) {
        result.headers.set(headerName, headerPath);
      }

      // Merge dependency graph
      for (const [file, deps] of additionalResult.dependencyGraph.entries()) {
        result.dependencyGraph.set(file, deps);
      }

      // Merge reverse dependency graph
      for (const [file, deps] of additionalResult.reverseDependencyGraph.entries()) {
        const existing = result.reverseDependencyGraph.get(file);
        if (existing) {
          for (const dep of deps) {
            existing.add(dep);
          }
        } else {
          result.reverseDependencyGraph.set(file, deps);
        }
      }

      // Merge split targets
      result.splitTargets.push(...additionalResult.splitTargets);
    }

    console.log(
      chalk.green(
        `\n✅ Merged analysis from ${options.additionalSourceDirs.length + 1} source directories`
      )
    );
    console.log(chalk.gray(`   Total files: ${result.files.size}`));
    console.log(chalk.gray(`   Total targets: ${result.splitTargets.length}`));
  }

  printAnalysisSummary(result);

  if (options.outputJson) {
    await exportAnalysisJson(result, options.outputJson);
  }

  if (options.outputDot) {
    exportDotGraph(result, options.outputDot);
  }

  if (options.outputSpmConfig) {
    const mergeSingletons = options.virtualTargetsSccMergeSingletons !== false;
    let splitTargetsOverride: SplitTarget[] | undefined;
    if (options.virtualTargetsScc) {
      const raw = computeSplitTargetsBySccVirtualTargets(
        result.files,
        result.dependencyGraph,
        options.productDefinitions
      );
      splitTargetsOverride = mergeSingletons
        ? mergeSingletonSccSplitTargets(raw, options.productDefinitions)
        : raw;
    }

    await exportSpmConfig(
      result,
      options.outputSpmConfig,
      sourceRoot,
      options.externalDeps,
      false, // autoBridge - no longer supported
      options.consolidateSwift,
      splitTargetsOverride,
      options.productDefinitions,
      options.mergeSwift,
      options.excludeFromPrebuild,
      options.mergeHeaderTargets,
      options.mergeObjc
    );
  }

  return result;
}

// Export for use in other modules
export default {
  analyzeSourceDirectory,
  printAnalysisSummary,
  printFileDependencies,
  exportDotGraph,
  exportAnalysisJson,
  exportSpmConfig,
  runAnalysis,
};
