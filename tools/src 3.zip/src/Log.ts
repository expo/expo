export function collapsed(message: string): void {
  console.log(message);
}

export function open(message: string): void {
  console.log(message);
}

export function reopenGroup(message: string): void {
  console.log(message);
}
