import { Command } from '@expo/commander';
import chalk from 'chalk';
import path from 'path';

import logger from '../Logger';
import { runAnalysis } from '../prebuilds/SPMAnalyzer';
import type { ProductDefinition } from '../prebuilds/SPMConfig.types';

type ActionOptions = {
  exclude?: string;
  excludeFromPrebuild?: string;
  includePath?: string;
  sourceDir?: string[];
  outputJson?: string;
  outputDot?: string;
  outputSpmConfig?: string;
  externalDeps?: string;
  product?: string[];
  folderTargets?: boolean;
  virtualTargets?: boolean;
  virtualTargetsScc?: boolean;
  virtualTargetsSccMergeSingletons?: boolean;
  virtualTargetsMaxDepth?: string;
  autoBridge?: boolean;
  consolidateSwift?: boolean;
  mergeSwift?: boolean;
  verbose?: boolean;
  useClang?: boolean;
};

/**
 * Parses a product definition string in format "ProductName:path1,path2,..."
 * Returns null if the format is invalid.
 */
function parseProductDefinition(productStr: string): ProductDefinition | null {
  const colonIndex = productStr.indexOf(':');
  if (colonIndex === -1) {
    return null;
  }

  const name = productStr.slice(0, colonIndex).trim();
  const pathsStr = productStr.slice(colonIndex + 1).trim();

  if (!name || !pathsStr) {
    return null;
  }

  const pathPatterns = pathsStr
    .split(',')
    .map((p) => p.trim())
    .filter(Boolean);
  if (pathPatterns.length === 0) {
    return null;
  }

  return { name, pathPatterns };
}

async function main(sourceDir: string, options: ActionOptions) {
  try {
    if (!sourceDir) {
      throw new Error('Source directory is required.');
    }

    // Resolve the source directory to an absolute path
    const absoluteSourceDir = path.resolve(sourceDir);

    // Parse comma-separated exclude dirs
    const excludeDirs = options.exclude ? options.exclude.split(',').map((d) => d.trim()) : [];

    // Parse comma-separated files to exclude from prebuild (ObjC files that depend on Swift)
    const excludeFromPrebuild = options.excludeFromPrebuild
      ? options.excludeFromPrebuild.split(',').map((d) => d.trim())
      : [];

    // Parse comma-separated include paths
    const includePaths = options.includePath
      ? options.includePath.split(',').map((d) => path.resolve(d.trim()))
      : [];

    // Parse additional source directories
    const additionalSourceDirs = options.sourceDir
      ? options.sourceDir.map((d) => path.resolve(d.trim()))
      : [];

    // Parse comma-separated external dependencies
    const externalDeps = options.externalDeps
      ? options.externalDeps.split(',').map((d) => d.trim())
      : [];

    // Parse product definitions
    const productDefinitions: ProductDefinition[] = [];
    if (options.product && options.product.length > 0) {
      for (const productStr of options.product) {
        const parsed = parseProductDefinition(productStr);
        if (parsed) {
          productDefinitions.push(parsed);
        } else {
          logger.warn(
            chalk.yellow(`⚠️  Invalid product definition format: "${productStr}". `) +
              chalk.gray('Expected format: "ProductName:path1,path2,..."')
          );
        }
      }
    }

    logger.info(`🔍 Analyzing dependencies in: ${chalk.green(absoluteSourceDir)}`);
    if (additionalSourceDirs.length > 0) {
      logger.info(`   Additional source directories: ${additionalSourceDirs.join(', ')}`);
    }

    await runAnalysis(absoluteSourceDir, {
      excludeDirs,
      excludeFromPrebuild: excludeFromPrebuild.length > 0 ? excludeFromPrebuild : undefined,
      includePaths,
      additionalSourceDirs: additionalSourceDirs.length > 0 ? additionalSourceDirs : undefined,
      outputJson: options.outputJson,
      outputDot: options.outputDot,
      outputSpmConfig: options.outputSpmConfig,
      externalDeps,
      productDefinitions: productDefinitions.length > 0 ? productDefinitions : undefined,
      folderTargets: options.folderTargets,
      virtualTargets: options.virtualTargets,
      virtualTargetsScc: options.virtualTargetsScc,
      virtualTargetsSccMergeSingletons: options.virtualTargetsSccMergeSingletons,
      virtualTargetsMaxDepth: options.virtualTargetsMaxDepth
        ? Number.parseInt(options.virtualTargetsMaxDepth, 10)
        : undefined,
      autoBridge: options.autoBridge,
      consolidateSwift: options.consolidateSwift,
      mergeSwift: options.mergeSwift,
      mergeObjc: options.mergeObjc,
      mergeHeaderTargets: options.mergeHeaderTargets,
      verbose: options.verbose,
      useClang: options.useClang,
    });

    logger.info(chalk.green('\n✅ Analysis complete!'));
  } catch (error) {
    logger.error(
      error instanceof Error ? `❌ ${error.message}` : `❌ An unexpected error occurred: ${error}`
    );
    process.exit(1);
  }
}

export default (program: Command) => {
  program
    .command('analyze-deps <sourceDir>')
    .description(
      'Analyzes Objective-C/Swift dependencies in a source directory to help plan SPM target structure.'
    )
    .alias('analyze')
    .option(
      '-e, --exclude <patterns>',
      'Comma-separated list of directories or files to exclude from analysis (relative to source dir).'
    )
    .option(
      '--exclude-from-prebuild <patterns>',
      'Comma-separated list of source files to exclude from prebuild (e.g., ObjC files that depend on Swift). These will be added to the exclude array in the target config.'
    )
    .option(
      '-I, --include-path <paths>',
      'Comma-separated list of additional include paths for clang analysis.'
    )
    .option(
      '-S, --source-dir <path>',
      'Additional source directory to analyze. Can be specified multiple times.',
      (value: string, previous: string[]) => previous.concat([value]),
      [] as string[]
    )
    .option('--output-json <path>', 'Export analysis results to a JSON file.')
    .option(
      '--output-dot <path>',
      'Export dependency graph in DOT format for visualization with Graphviz.'
    )
    .option('--output-spm-config <path>', 'Export analysis as spm.config.json compatible format.')
    .option(
      '--external-deps <deps>',
      'Comma-separated list of external SPM dependencies (e.g., ReactNativeDependencies,React,Hermes).'
    )
    .option(
      '--folder-targets',
      'Print a folder-based target list (Root + top-level folders) with dependencies and cycle highlighting, then exit.',
      false
    )
    .option(
      '--virtual-targets',
      'Print virtual Swift/ObjC targets derived from folder structure and iteratively split cycle-involved targets, then exit.',
      false
    )
    .option(
      '--virtual-targets-scc',
      'Use a graph-first SCC heuristic for --virtual-targets (groups files by strongly-connected components before splitting by language).',
      false
    )
    .option(
      '--no-virtual-targets-scc-merge-singletons',
      'Disable safe merging of singleton SCC targets when exporting spm.config.json in --virtual-targets-scc mode.',
      true
    )
    .option(
      '--virtual-targets-max-depth <n>',
      'Maximum folder depth for iterative splitting in --virtual-targets mode (default: 4).'
    )
    .option(
      '--product <definition>',
      'Define a product with paths: "ProductName:path1,path2,...". Use "*" as path for catch-all. Can be specified multiple times.',
      (value: string, previous: string[]) => previous.concat([value]),
      [] as string[]
    )
    .option(
      '--auto-bridge',
      'Automatically create bridging targets to break cyclic dependencies.',
      false
    )
    .option(
      '--consolidate-swift',
      'Consolidate Swift into layered targets: Swift_base (for ObjC interop) and Swift_main (depends on ObjC).',
      false
    )
    .option(
      '--merge-swift',
      'Merge all Swift files into a single SCCM_swift target. Simpler than --consolidate-swift for modules with heavy ObjC interop.',
      false
    )
    .option(
      '--merge-objc',
      'Merge all ObjC files into a single SCCM_objc target. Helps avoid cross-module header issues with <ProductName/Header.h> imports.',
      false
    )
    .option(
      '--merge-header-targets',
      'Fold headers from header-only SCC{N}_objc targets into their dependent SCCM targets to reduce SPM target count.',
      false
    )
    .option('-v, --verbose', 'Enable verbose logging.', false)
    .option(
      '--use-clang',
      'Use clang -MM for accurate dependency resolution (slower but more accurate).',
      false
    )
    .asyncAction(main);
};
