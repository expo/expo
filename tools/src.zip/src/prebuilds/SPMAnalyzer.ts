import chalk from 'chalk';
import { execSync } from 'child_process';
import fs from 'fs-extra';
import path from 'path';

import type { ProductDefinition } from './SPMConfig.types';

// ============================================================================
// Types
// ============================================================================

/**
 * Represents a single source file with its dependencies
 */
export interface SourceFile {
  /** Absolute path to the file */
  filePath: string;
  /** Relative path from the source root */
  relativePath: string;
  /** File name without extension */
  name: string;
  /** File extension (.h, .m, .mm, .swift, .cpp) */
  extension: string;
  /** Language type */
  language: 'objc' | 'swift' | 'cpp' | 'header';
  /** Headers/modules this file imports */
  imports: ImportInfo[];
  /** Files that import this file (populated during analysis) */
  importedBy: string[];
  /** Name of the source root directory this file came from (e.g., "ios" or "common") */
  sourceRootName?: string;
}

/**
 * Information about an import statement
 */
export interface ImportInfo {
  /** The raw import string (e.g., "ExpoModulesCore/EXDefines.h" or "Foundation") */
  raw: string;
  /** Import type */
  type: 'angle-bracket' | 'quote' | 'module' | 'swift';
  /** Module/framework name if applicable */
  moduleName?: string;
  /** Header file name if applicable */
  headerName?: string;
  /** Whether this is a system/external import */
  isExternal: boolean;
}

/**
 * Represents a potential target grouping
 */
export interface TargetGroup {
  /** Target name */
  name: string;
  /** Source files in this target */
  files: SourceFile[];
  /** Other targets this target depends on */
  dependencies: string[];
  /** Language(s) used in this target */
  languages: Set<'objc' | 'swift' | 'cpp'>;
}

/**
 * Represents a split target (single language)
 */
export interface SplitTarget {
  /** Target name (e.g., "Core_swift" or "Core_objc") */
  name: string;
  /** Original target name before splitting */
  originalName: string;
  /** Language of this target */
  language: 'objc' | 'swift' | 'cpp';
  /** Source files in this target */
  sourceFiles: string[];
  /** Header files associated with this target */
  headerFiles: string[];
  /** Other split targets this target depends on */
  dependencies: string[];
  /** External module dependencies (cross-product targets) */
  externalDependencies: string[];
  /** System frameworks to link (e.g., AVKit, Foundation) */
  linkedFrameworks: string[];
  /** Whether this target was split from a mixed-language target */
  wasSplit: boolean;
  /** Source root directory (basename) where these files came from */
  sourceRootName?: string;
}

/**
 * Suggestion for a bridging target to break cyclic dependencies
 */
export interface BridgingSuggestion {
  /** Name for the suggested bridging target */
  name: string;
  /** The cycle this would break */
  cycle: string[];
  /** Headers to extract into the bridging target */
  headers: string[];
  /** Explanation of why these headers were selected */
  reason: string;
}

/**
 * Suggestion for a Swift base target to break Swift/ObjC cyclic dependencies
 */
export interface SwiftBridgingSuggestion {
  /** Name for the suggested Swift base target (e.g., "Core_swift_base") */
  name: string;
  /** The Swift target this would be extracted from */
  sourceTarget: string;
  /** ObjC targets that would depend on this base target */
  objcTargets: string[];
  /** Swift files to extract into the base target */
  swiftFiles: string[];
  /** Swift types defined in these files that are used by ObjC */
  exposedTypes: string[];
  /** Explanation of why these files were selected */
  reason: string;
}

/**
 * Information about Swift type usage in ObjC files
 */
export interface SwiftTypeUsage {
  /** Swift type name (e.g., "EXAppContext") */
  typeName: string;
  /** How it's used: alloc/init, property access, method call, etc. */
  usageType: 'instantiation' | 'property' | 'method-call' | 'type-reference' | 'cast';
  /** Line numbers where it appears */
  lineNumbers: number[];
  /** Specific methods called on this type (if any) */
  methodsCalled: string[];
}

/**
 * Information about ObjC file that imports Swift.h
 */
export interface SwiftUsageInfo {
  /** File path */
  filePath: string;
  /** Relative path */
  relativePath: string;
  /** Whether file imports Swift.h */
  importsSwiftHeader: boolean;
  /** Swift types used in this file */
  swiftTypes: SwiftTypeUsage[];
  /** Total count of Swift type usages */
  totalUsages: number;
}

/**
 * Complete analysis of Swift usage across all ObjC files
 */
export interface SwiftUsageAnalysis {
  /** Files that import Swift.h */
  filesImportingSwiftHeader: SwiftUsageInfo[];
  /** All Swift types referenced from ObjC */
  allSwiftTypes: Set<string>;
  /** Total files importing Swift.h */
  totalFilesImportingSwift: number;
  /** Recommendation on which approach to take */
  recommendation: {
    approach: 'layered-architecture' | 'runtime-lookups' | 'convert-to-swift' | 'unified-target';
    reason: string;
    effort: 'low' | 'medium' | 'high';
    risk: 'low' | 'medium' | 'high';
  };
}

/**
 * Result of dependency analysis
 */
export interface AnalysisResult {
  /** All source files found */
  files: Map<string, SourceFile>;
  /** All headers found (maps header name to file path) */
  headers: Map<string, string>;
  /** Dependency graph (file -> files it depends on) */
  dependencyGraph: Map<string, Set<string>>;
  /** Reverse dependency graph (file -> files that depend on it) */
  reverseDependencyGraph: Map<string, Set<string>>;
  /** Detected cycles */
  cycles: string[][];
  /** Suggested target groupings */
  suggestedTargets: TargetGroup[];
  /** Split targets (single-language) */
  splitTargets: SplitTarget[];
  /** Suggested bridging targets to break cycles */
  bridgingSuggestions: BridgingSuggestion[];
  /** Suggested Swift base targets to break Swift/ObjC cycles */
  swiftBridgingSuggestions: SwiftBridgingSuggestion[];
  /** Analysis of Swift usage in ObjC files */
  swiftUsageAnalysis: SwiftUsageAnalysis;
  /** Source root path */
  sourceRoot: string;
}

/**
 * Options for the analyzer
 */
export interface AnalyzerOptions {
  /** Root directory to analyze */
  sourceRoot: string;
  /** Directories to exclude from analysis */
  excludeDirs?: string[];
  /** Additional include paths for clang analysis */
  includePaths?: string[];
  /** Known external modules (won't be flagged as missing) */
  externalModules?: string[];
  /** Verbose logging */
  verbose?: boolean;
  /** Use clang -MM for accurate dependency resolution (slower but more accurate) */
  useClang?: boolean;
}

type FolderTargetType = 'swift' | 'objc' | 'cpp' | 'mixed' | 'empty';

type FolderTargetSummary = {
  name: string;
  type: FolderTargetType;
  linkedFrameworks: string[];
  dependencies: string[];
};

type VirtualTargetLanguage = 'swift' | 'objc' | 'cpp';

type VirtualTargetSummary = {
  name: string;
  folderKey: string;
  depth: number;
  language: VirtualTargetLanguage;
  linkedFrameworks: string[];
  dependencies: string[];
};

type VirtualTargetsMode = 'folder-split' | 'scc';

function toGlobBraceList(filePaths: string[]): string | undefined {
  const unique = Array.from(
    new Set(
      filePaths
        .filter(Boolean)
        .map((p) => p.replace(/\\/g, '/'))
        .map((p) => p.replace(/^\.\//, ''))
    )
  ).sort((a, b) => a.localeCompare(b));

  if (unique.length === 0) return undefined;
  if (unique.length === 1) return unique[0];
  return `{${unique.join(',')}}`;
}

function sanitizeTargetNamePart(input: string): string {
  return input
    .replace(/\\/g, '_')
    .replace(/\//g, '_')
    .replace(/[^A-Za-z0-9_]+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '')
    .trim();
}

function mergeSingletonSccSplitTargets(
  splitTargets: SplitTarget[],
  productDefinitions?: ProductDefinition[]
): SplitTarget[] {
  // Merge singleton (single-file) targets by folder+language+product, but avoid creating cycles.
  // If merging creates a cycle, iteratively exclude cycle-involved singletons from merging.

  function getBucketFromRelativePath(relativePath: string): string {
    const dir = path.dirname(relativePath);
    if (dir === '.' || dir === path.sep) return 'Root';
    const parts = dir.split(path.sep).filter(Boolean);
    return parts[0] || 'Root';
  }

  // Helper to get product for a file path
  function getProductForPath(relativePath: string): string {
    if (!productDefinitions || productDefinitions.length === 0) {
      return 'default';
    }
    const product = getFileProduct(relativePath, productDefinitions);
    return product || 'default';
  }

  function tryMerge(
    allTargets: SplitTarget[],
    excludeFromMerge: Set<string>
  ): { result: SplitTarget[]; cycles: string[][] } {
    const existingNames = new Set(allTargets.map((t) => t.name));
    const singletonTargets = allTargets.filter(
      (t) => t.sourceFiles.length + t.headerFiles.length === 1 && !excludeFromMerge.has(t.name)
    );
    if (singletonTargets.length === 0) {
      return { result: allTargets, cycles: [] };
    }

    const mergeGroups = new Map<string, SplitTarget[]>();
    for (const t of singletonTargets) {
      const onlyPath = t.sourceFiles[0] ?? t.headerFiles[0];
      const bucket = getBucketFromRelativePath(onlyPath);
      const product = getProductForPath(onlyPath);
      // Include product in the key so files for different products don't get merged together
      const key = `${bucket}::${t.language}::${product}`;
      if (!mergeGroups.has(key)) mergeGroups.set(key, []);
      mergeGroups.get(key)!.push(t);
    }

    // Only keep groups where merging actually reduces count.
    const effectiveGroups = Array.from(mergeGroups.entries()).filter(([, list]) => list.length > 1);
    if (effectiveGroups.length === 0) {
      return { result: allTargets, cycles: [] };
    }

    const oldToNewName = new Map<string, string>();
    const mergedTargets: SplitTarget[] = [];

    for (const [key, group] of effectiveGroups) {
      const [bucket, language] = key.split('::') as [string, SplitTarget['language']];
      const baseName = `SCCM_${sanitizeTargetNamePart(bucket)}_${language}`;
      let name = baseName;
      let i = 2;
      while (existingNames.has(name)) {
        name = `${baseName}_${i++}`;
      }
      existingNames.add(name);

      for (const member of group) {
        oldToNewName.set(member.name, name);
      }

      const sourceFiles = Array.from(new Set(group.flatMap((t) => t.sourceFiles))).sort((a, b) =>
        a.localeCompare(b)
      );
      const headerFiles = Array.from(new Set(group.flatMap((t) => t.headerFiles))).sort((a, b) =>
        a.localeCompare(b)
      );
      const linkedFrameworks = Array.from(new Set(group.flatMap((t) => t.linkedFrameworks))).sort(
        (a, b) => a.localeCompare(b)
      );

      // Preserve sourceRootName from source targets if they all share the same one
      // (Merged targets should only combine targets from the same source directory)
      const sourceRootNames = new Set(group.map((t) => t.sourceRootName).filter(Boolean));
      const sourceRootName =
        sourceRootNames.size === 1 ? Array.from(sourceRootNames)[0] : undefined;

      mergedTargets.push({
        name,
        originalName: name,
        language,
        sourceFiles,
        headerFiles,
        dependencies: [],
        externalDependencies: [],
        linkedFrameworks,
        wasSplit: true,
        sourceRootName,
      });
    }

    // Start with non-merged targets + merged targets.
    const mergedAway = new Set(oldToNewName.keys());
    const kept = allTargets.filter((t) => !mergedAway.has(t.name));
    const combined = [...kept, ...mergedTargets];

    // Rebuild dependencies with name rewrites + de-dupe + remove self-deps.
    const combinedNames = new Set(combined.map((t) => t.name));
    const groupedNames = new Set(oldToNewName.values());

    // Helper: collect members for each merged name to compute their combined deps.
    const mergedNameToMembers = new Map<string, SplitTarget[]>();
    for (const member of singletonTargets) {
      const newName = oldToNewName.get(member.name);
      if (!newName) continue;
      if (!mergedNameToMembers.has(newName)) mergedNameToMembers.set(newName, []);
      mergedNameToMembers.get(newName)!.push(member);
    }

    const result = combined
      .map((t) => {
        const depsSourceTargets = groupedNames.has(t.name)
          ? (mergedNameToMembers.get(t.name) ?? [])
          : [t];
        const deps = new Set<string>();
        for (const src of depsSourceTargets) {
          for (const d of src.dependencies) {
            const rewritten = oldToNewName.get(d) ?? d;
            if (rewritten === t.name) continue;
            deps.add(rewritten);
          }
        }

        const depList = Array.from(deps).filter((d) => !mergedAway.has(d) || combinedNames.has(d));
        depList.sort((a, b) => a.localeCompare(b));
        return { ...t, dependencies: depList };
      })
      .sort((a, b) => a.name.localeCompare(b.name));

    // Detect cycles in the merged result.
    const cycles = detectSplitTargetCyclesInternal(result);
    return { result, cycles };
  }

  // Iteratively merge; if cycles appear, exclude singletons that ended up in cyclic merged targets.
  let excludeFromMerge = new Set<string>();
  let attempt = tryMerge(splitTargets, excludeFromMerge);
  let iterations = 0;
  const maxIterations = 20;

  while (attempt.cycles.length > 0 && iterations < maxIterations) {
    iterations++;
    // Find merged target names involved in cycles.
    const cyclicNames = new Set<string>();
    for (const cycle of attempt.cycles) {
      for (const name of cycle) {
        cyclicNames.add(name);
      }
    }

    // Map merged names back to original singleton names and exclude them.
    const newExclusions = new Set(excludeFromMerge);
    for (const t of splitTargets) {
      if (t.sourceFiles.length + t.headerFiles.length !== 1) continue;
      const bucket = getBucketFromRelativePath(t.sourceFiles[0] ?? t.headerFiles[0]);
      const mergedName = `SCCM_${sanitizeTargetNamePart(bucket)}_${t.language}`;
      // Check if this merged name (or variants) is cyclic.
      for (const cyclic of cyclicNames) {
        if (cyclic === mergedName || cyclic.startsWith(mergedName + '_')) {
          newExclusions.add(t.name);
        }
      }
    }

    if (newExclusions.size === excludeFromMerge.size) {
      // No progress, give up.
      break;
    }
    excludeFromMerge = newExclusions;
    attempt = tryMerge(splitTargets, excludeFromMerge);
  }

  return attempt.result;
}

/**
 * Internal cycle detection for split targets (returns cycles, doesn't throw).
 */
function detectSplitTargetCyclesInternal(splitTargets: SplitTarget[]): string[][] {
  const targetNames = new Set(splitTargets.map((t) => t.name));
  const graph = new Map<string, Set<string>>();
  for (const target of splitTargets) {
    const deps = new Set<string>();
    for (const dep of target.dependencies) {
      if (targetNames.has(dep)) {
        deps.add(dep);
      }
    }
    graph.set(target.name, deps);
  }

  const cycles: string[][] = [];
  const visited = new Set<string>();
  const recStack = new Set<string>();
  const pathStack: string[] = [];

  function dfs(node: string): void {
    visited.add(node);
    recStack.add(node);
    pathStack.push(node);

    const neighbors = graph.get(node) || new Set();
    for (const neighbor of neighbors) {
      if (!targetNames.has(neighbor)) continue;
      if (!visited.has(neighbor)) {
        dfs(neighbor);
      } else if (recStack.has(neighbor)) {
        const cycleStart = pathStack.indexOf(neighbor);
        if (cycleStart !== -1) {
          const cycle = pathStack.slice(cycleStart);
          const cycleKey = [...cycle].sort().join('->');
          if (!cycles.some((c) => [...c].sort().join('->') === cycleKey)) {
            cycles.push(cycle);
          }
        }
      }
    }

    pathStack.pop();
    recStack.delete(node);
  }

  for (const node of graph.keys()) {
    if (!visited.has(node)) {
      dfs(node);
    }
  }

  return cycles;
}

// ============================================================================
// Constants
// ============================================================================

const SOURCE_EXTENSIONS = ['.m', '.mm', '.swift', '.cpp', '.c'];
const HEADER_EXTENSIONS = ['.h', '.hpp'];

const KNOWN_SYSTEM_MODULES = new Set([
  'Foundation',
  'UIKit',
  'CoreGraphics',
  'QuartzCore',
  'AVFoundation',
  'AVKit',
  'CoreMedia',
  'CoreVideo',
  'Photos',
  'PhotosUI',
  'CoreLocation',
  'MapKit',
  'WebKit',
  'SafariServices',
  'StoreKit',
  'MessageUI',
  'EventKit',
  'EventKitUI',
  'Contacts',
  'ContactsUI',
  'LocalAuthentication',
  'Security',
  'SystemConfiguration',
  'CoreBluetooth',
  'CoreMotion',
  'CoreTelephony',
  'UserNotifications',
  'BackgroundTasks',
  'Combine',
  'SwiftUI',
  'ObjectiveC',
  'Darwin',
  'Dispatch',
  'os',
  'Accelerate',
  'AudioToolbox',
  'CoreAudio',
  'CoreData',
  'CoreFoundation',
  'CoreImage',
  'CoreServices',
  'CoreText',
  'GameController',
  'GameKit',
  'GLKit',
  'ImageIO',
  'Metal',
  'MetalKit',
  'ModelIO',
  'Network',
  'NetworkExtension',
  'PushKit',
  'ReplayKit',
  'SceneKit',
  'SpriteKit',
  'VideoToolbox',
  'Vision',
  'WatchConnectivity',
  'WidgetKit',
]);

/**
 * Checks if a dependency name is a valid cross-product target dependency.
 * Filters out system frameworks and invalid module names.
 */
function isValidCrossProductDep(dep: string): boolean {
  // Skip system modules
  if (KNOWN_SYSTEM_MODULES.has(dep)) {
    return false;
  }
  // Skip common lowercase module names that are likely not valid targets
  // Only exclude the exact lowercase versions - uppercase like "JSI" are valid
  const invalidPatterns = [
    'objc',
    'react', // lowercase react is not a target, "React" is
    'jsi', // lowercase jsi is not a target, "JSI" is
    'c++',
    'std',
    'ReactCommon', // This is part of React, not a standalone target
  ];
  if (invalidPatterns.includes(dep)) {
    return false;
  }
  // Skip single-character or empty dependencies
  if (dep.length <= 1) {
    return false;
  }
  // Skip dependencies that start with lowercase (likely system or invalid)
  // Exception: allow all-caps like "JSI"
  if (dep[0] === dep[0].toLowerCase() && dep !== dep.toUpperCase()) {
    return false;
  }
  return true;
}

// ============================================================================
// File Discovery
// ============================================================================

/**
 * Recursively finds all source and header files in a directory
 */
async function findSourceFiles(
  rootDir: string,
  excludePatternsInput: string[] | string | undefined = []
): Promise<{ sources: string[]; headers: string[] }> {
  const sources: string[] = [];
  const headers: string[] = [];

  // Normalize excludePatterns to always be an array
  const excludePatterns: string[] = Array.isArray(excludePatternsInput)
    ? excludePatternsInput
    : excludePatternsInput
      ? [excludePatternsInput]
      : [];

  // Separate file patterns from directory patterns
  const excludeFiles = new Set(excludePatterns.filter((p) => p.includes('.')));
  const excludeDirs = excludePatterns.filter((p) => !p.includes('.'));

  async function walk(dir: string): Promise<void> {
    const entries = await fs.readdir(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const relativePath = path.relative(rootDir, fullPath);

      // Skip excluded directories
      if (entry.isDirectory()) {
        // Check for glob patterns like **/Tests (matches any dir named "Tests")
        const shouldExclude = excludeDirs.some((exclude) => {
          if (exclude.startsWith('**/')) {
            // Match any directory with this name at any level
            const dirName = exclude.slice(3);
            return entry.name === dirName;
          }
          // Exact path match
          return relativePath === exclude || relativePath.startsWith(exclude + path.sep);
        });
        if (!shouldExclude && !entry.name.startsWith('.')) {
          await walk(fullPath);
        }
        continue;
      }

      // Skip excluded files (check both filename and relative path)
      if (excludeFiles.has(entry.name) || excludeFiles.has(relativePath)) {
        continue;
      }

      const ext = path.extname(entry.name).toLowerCase();
      if (SOURCE_EXTENSIONS.includes(ext)) {
        sources.push(fullPath);
      } else if (HEADER_EXTENSIONS.includes(ext)) {
        headers.push(fullPath);
      }
    }
  }

  await walk(rootDir);
  return { sources, headers };
}

// ============================================================================
// Import Parsing
// ============================================================================

/**
 * Parses import statements from Objective-C/C++ source code
 */
function parseObjCImports(content: string): ImportInfo[] {
  const imports: ImportInfo[] = [];

  // Match #import <Module/Header.h> or #import <Header.h>
  const angleImportRegex = /#import\s*<([^>]+)>/g;
  let match;
  while ((match = angleImportRegex.exec(content)) !== null) {
    const raw = match[1];
    const parts = raw.split('/');
    imports.push({
      raw,
      type: 'angle-bracket',
      moduleName: parts.length > 1 ? parts[0] : undefined,
      headerName: parts.length > 1 ? parts.slice(1).join('/') : raw,
      isExternal: KNOWN_SYSTEM_MODULES.has(parts[0]),
    });
  }

  // Match #import "Header.h"
  const quoteImportRegex = /#import\s*"([^"]+)"/g;
  while ((match = quoteImportRegex.exec(content)) !== null) {
    const raw = match[1];
    imports.push({
      raw,
      type: 'quote',
      headerName: raw,
      isExternal: false,
    });
  }

  // Match #include <...> and #include "..."
  const includeAngleRegex = /#include\s*<([^>]+)>/g;
  while ((match = includeAngleRegex.exec(content)) !== null) {
    const raw = match[1];
    const parts = raw.split('/');
    imports.push({
      raw,
      type: 'angle-bracket',
      moduleName: parts.length > 1 ? parts[0] : undefined,
      headerName: parts.length > 1 ? parts.slice(1).join('/') : raw,
      isExternal: KNOWN_SYSTEM_MODULES.has(parts[0]) || raw.includes('std'),
    });
  }

  const includeQuoteRegex = /#include\s*"([^"]+)"/g;
  while ((match = includeQuoteRegex.exec(content)) !== null) {
    const raw = match[1];
    imports.push({
      raw,
      type: 'quote',
      headerName: raw,
      isExternal: false,
    });
  }

  // Match @import Module;
  const moduleImportRegex = /@import\s+(\w+)(?:\.(\w+))?;/g;
  while ((match = moduleImportRegex.exec(content)) !== null) {
    imports.push({
      raw: match[0],
      type: 'module',
      moduleName: match[1],
      isExternal: KNOWN_SYSTEM_MODULES.has(match[1]),
    });
  }

  return imports;
}

/**
 * Parses import statements from Swift source code
 */
function parseSwiftImports(content: string): ImportInfo[] {
  const imports: ImportInfo[] = [];

  // Match import Module
  const importRegex = /^import\s+(\w+)/gm;
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const moduleName = match[1];
    imports.push({
      raw: match[0],
      type: 'swift',
      moduleName,
      isExternal: KNOWN_SYSTEM_MODULES.has(moduleName),
    });
  }

  return imports;
}

// ============================================================================
// Clang-based Dependency Analysis
// ============================================================================

/**
 * Uses clang -MM to get accurate dependencies for a source file
 */
function getClangDependencies(
  filePath: string,
  includePaths: string[],
  verbose: boolean = false
): string[] {
  const ext = path.extname(filePath).toLowerCase();

  // Build include path flags
  const includeFlags = includePaths.map((p) => `-I${p}`).join(' ');

  // Determine language
  let langFlag = '-x objective-c++';
  if (ext === '.c') langFlag = '-x c';
  else if (ext === '.cpp') langFlag = '-x c++';

  try {
    const cmd = `clang -MM ${langFlag} ${includeFlags} "${filePath}" 2>/dev/null`;
    if (verbose) {
      console.log(chalk.gray(`  Running: ${cmd}`));
    }
    const output = execSync(cmd, { encoding: 'utf-8', maxBuffer: 10 * 1024 * 1024 });

    // Parse makefile-style output
    // Format: target.o: source.m header1.h header2.h \
    //                   header3.h
    const deps = output
      .replace(/\\\n/g, ' ') // Join continuation lines
      .split(':')[1] // Get dependencies part
      ?.split(/\s+/)
      .filter((d) => d.length > 0 && d !== filePath)
      .map((d) => d.trim());

    return deps || [];
  } catch {
    if (verbose) {
      console.log(chalk.yellow(`  Warning: clang failed for ${filePath}`));
    }
    return [];
  }
}

// ============================================================================
// Cycle Detection
// ============================================================================

/**
 * Detects cycles in the dependency graph using Tarjan's algorithm
 */
function detectCycles(graph: Map<string, Set<string>>): string[][] {
  const cycles: string[][] = [];
  const visited = new Set<string>();
  const recStack = new Set<string>();
  const path: string[] = [];

  function dfs(node: string): void {
    visited.add(node);
    recStack.add(node);
    path.push(node);

    const neighbors = graph.get(node) || new Set();
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        dfs(neighbor);
      } else if (recStack.has(neighbor)) {
        // Found a cycle
        const cycleStart = path.indexOf(neighbor);
        if (cycleStart !== -1) {
          cycles.push(path.slice(cycleStart));
        }
      }
    }

    path.pop();
    recStack.delete(node);
  }

  for (const node of graph.keys()) {
    if (!visited.has(node)) {
      dfs(node);
    }
  }

  return cycles;
}

/**
 * Finds strongly connected components (potential target groups)
 */
function findStronglyConnectedComponents(graph: Map<string, Set<string>>): string[][] {
  const index = new Map<string, number>();
  const lowlink = new Map<string, number>();
  const onStack = new Set<string>();
  const stack: string[] = [];
  const sccs: string[][] = [];
  let currentIndex = 0;

  function strongConnect(v: string): void {
    index.set(v, currentIndex);
    lowlink.set(v, currentIndex);
    currentIndex++;
    stack.push(v);
    onStack.add(v);

    const neighbors = graph.get(v) || new Set();
    for (const w of neighbors) {
      if (!index.has(w)) {
        strongConnect(w);
        lowlink.set(v, Math.min(lowlink.get(v)!, lowlink.get(w)!));
      } else if (onStack.has(w)) {
        lowlink.set(v, Math.min(lowlink.get(v)!, index.get(w)!));
      }
    }

    if (lowlink.get(v) === index.get(v)) {
      const scc: string[] = [];
      let w: string;
      do {
        w = stack.pop()!;
        onStack.delete(w);
        scc.push(w);
      } while (w !== v);
      sccs.push(scc);
    }
  }

  for (const v of graph.keys()) {
    if (!index.has(v)) {
      strongConnect(v);
    }
  }

  return sccs;
}

// ============================================================================
// Target Suggestion
// ============================================================================

/**
 * Suggests target groupings based on directory structure and dependencies
 */
function suggestTargets(files: Map<string, SourceFile>, sourceRoot: string): TargetGroup[] {
  const dirGroups = new Map<string, SourceFile[]>();

  // Group files by their immediate parent directory
  for (const file of files.values()) {
    if (file.language === 'header') continue; // Skip headers for grouping

    const relDir = path.dirname(file.relativePath);
    const topDir = relDir.split(path.sep)[0] || 'Root';

    if (!dirGroups.has(topDir)) {
      dirGroups.set(topDir, []);
    }
    dirGroups.get(topDir)!.push(file);
  }

  const targets: TargetGroup[] = [];

  for (const [dirName, groupFiles] of dirGroups) {
    const languages = new Set<'objc' | 'swift' | 'cpp'>();
    for (const f of groupFiles) {
      if (f.language !== 'header') {
        languages.add(f.language);
      }
    }

    // Determine dependencies based on imports
    const deps = new Set<string>();
    for (const f of groupFiles) {
      for (const imp of f.imports) {
        if (imp.moduleName && !imp.isExternal) {
          deps.add(imp.moduleName);
        }
      }
    }

    targets.push({
      name: dirName,
      files: groupFiles,
      dependencies: Array.from(deps),
      languages,
    });
  }

  return targets;
}

/**
 * Splits mixed-language targets into separate single-language targets
 * and analyzes cross-language dependencies
 */
function splitTargetsAndAnalyzeDependencies(
  suggestedTargets: TargetGroup[],
  files: Map<string, SourceFile>,
  headers: Map<string, string>,
  dependencyGraph: Map<string, Set<string>>,
  sourceRoot: string
): SplitTarget[] {
  const splitTargets: SplitTarget[] = [];

  // Map from file path to its target
  const fileToTarget = new Map<string, string>();

  // First pass: create split targets and map files to targets
  for (const target of suggestedTargets) {
    const hasSwift = target.languages.has('swift');
    const hasObjC = target.languages.has('objc') || target.languages.has('cpp');
    const isMixed = hasSwift && hasObjC;

    if (isMixed) {
      // Split into separate targets
      const swiftFiles = target.files.filter((f) => f.language === 'swift');
      const objcFiles = target.files.filter((f) => f.language === 'objc' || f.language === 'cpp');

      // Find associated headers for objc files
      const objcHeaders: string[] = [];
      for (const file of objcFiles) {
        // Look for .h file with same name
        const baseName = file.name;
        const headerPath = headers.get(baseName + '.h');
        if (headerPath) {
          objcHeaders.push(path.relative(sourceRoot, headerPath));
        }
      }

      if (swiftFiles.length > 0) {
        const swiftTargetName = `${target.name}_swift`;
        splitTargets.push({
          name: swiftTargetName,
          originalName: target.name,
          language: 'swift',
          sourceFiles: swiftFiles.map((f) => f.relativePath),
          headerFiles: [],
          dependencies: [],
          externalDependencies: [],
          linkedFrameworks: [],
          wasSplit: true,
        });
        swiftFiles.forEach((f) => fileToTarget.set(f.filePath, swiftTargetName));
      }

      if (objcFiles.length > 0) {
        const objcTargetName = `${target.name}_objc`;
        splitTargets.push({
          name: objcTargetName,
          originalName: target.name,
          language: 'objc',
          sourceFiles: objcFiles.map((f) => f.relativePath),
          headerFiles: objcHeaders,
          dependencies: [],
          externalDependencies: [],
          linkedFrameworks: [],
          wasSplit: true,
        });
        objcFiles.forEach((f) => fileToTarget.set(f.filePath, objcTargetName));
      }
    } else {
      // Single language target - no split needed
      const language = hasSwift ? 'swift' : 'objc';
      const targetName = target.name;

      // Find associated headers
      const targetHeaders: string[] = [];
      for (const file of target.files) {
        const baseName = file.name;
        const headerPath = headers.get(baseName + '.h');
        if (headerPath) {
          targetHeaders.push(path.relative(sourceRoot, headerPath));
        }
      }

      splitTargets.push({
        name: targetName,
        originalName: target.name,
        language,
        sourceFiles: target.files.map((f) => f.relativePath),
        headerFiles: language === 'objc' ? targetHeaders : [],
        dependencies: [],
        externalDependencies: target.dependencies,
        linkedFrameworks: [],
        wasSplit: false,
      });
      target.files.forEach((f) => fileToTarget.set(f.filePath, targetName));
    }
  }

  // Also map headers to targets based on directory
  for (const [, headerPath] of headers) {
    const relPath = path.relative(sourceRoot, headerPath);
    const topDir = relPath.split(path.sep)[0] || 'Root';

    // Find the matching target - prefer objc target, but fall back to swift target
    // This handles cases like Platform.h which is in a swift-only directory
    let matchingTarget = splitTargets.find(
      (t) => (t.originalName === topDir || t.name === topDir) && t.language === 'objc'
    );

    // If no objc target, try to find a swift target in the same directory
    if (!matchingTarget) {
      matchingTarget = splitTargets.find((t) => t.originalName === topDir || t.name === topDir);
    }

    if (matchingTarget) {
      fileToTarget.set(headerPath, matchingTarget.name);
      // Also add header to the target's headerFiles if it's an objc target
      if (matchingTarget.language === 'objc' && !matchingTarget.headerFiles.includes(relPath)) {
        matchingTarget.headerFiles.push(relPath);
      }
    }
  }

  // Second pass: analyze dependencies between split targets
  for (const splitTarget of splitTargets) {
    const targetDeps = new Set<string>();
    const externalDeps = new Set<string>();
    const linkedFrameworks = new Set<string>();

    // Get all files in this target (including headers for objc targets)
    const targetFiles =
      splitTarget.language === 'swift'
        ? Array.from(files.values()).filter(
            (f) => f.language === 'swift' && fileToTarget.get(f.filePath) === splitTarget.name
          )
        : Array.from(files.values()).filter(
            (f) =>
              (f.language === 'objc' || f.language === 'cpp' || f.language === 'header') &&
              fileToTarget.get(f.filePath) === splitTarget.name
          );

    for (const file of targetFiles) {
      // Check file-level dependencies
      const fileDeps = dependencyGraph.get(file.filePath) || new Set();
      for (const depPath of fileDeps) {
        const depTarget = fileToTarget.get(depPath);
        if (depTarget && depTarget !== splitTarget.name) {
          targetDeps.add(depTarget);
        }
      }

      // Check import-level dependencies
      for (const imp of file.imports) {
        if (imp.isExternal) {
          if (imp.moduleName) {
            // System modules go to linkedFrameworks, others go to externalDeps
            if (KNOWN_SYSTEM_MODULES.has(imp.moduleName)) {
              linkedFrameworks.add(imp.moduleName);
            } else {
              externalDeps.add(imp.moduleName);
            }
          }
          continue;
        }

        // Try to resolve import to a target
        if (imp.headerName) {
          // First try exact match
          let headerPath = headers.get(imp.headerName);

          // If not found, try just the basename
          if (!headerPath) {
            headerPath = headers.get(path.basename(imp.headerName));
          }

          // For angle-bracket imports like <ExpoModulesCore/Platform.h>,
          // the headerName might be "Platform.h" - try to find it
          if (!headerPath && imp.type === 'angle-bracket') {
            // Search for a header that matches the name in any target
            for (const [hName, hPath] of headers) {
              if (hName === imp.headerName || path.basename(hPath) === imp.headerName) {
                headerPath = hPath;
                break;
              }
            }
          }

          if (headerPath) {
            const depTarget = fileToTarget.get(headerPath);
            if (depTarget && depTarget !== splitTarget.name) {
              targetDeps.add(depTarget);
            }
          } else if (imp.moduleName && imp.type === 'angle-bracket') {
            // Header not found locally, but we have a module name from angle-bracket import
            // like <ExpoModulesJSI/EXJSIConversions.h> - check if module matches a known target
            const matchingTarget = splitTargets.find(
              (t) =>
                t.originalName === imp.moduleName ||
                t.name === imp.moduleName ||
                // Also check if the module name matches a target's product (e.g., "JSI" target in "ExpoModulesJSI" product)
                t.name.toLowerCase() === imp.moduleName!.toLowerCase() ||
                // Check if any target's header files contain this header
                t.headerFiles.some((h) => path.basename(h) === imp.headerName)
            );
            if (matchingTarget && matchingTarget.name !== splitTarget.name) {
              targetDeps.add(matchingTarget.name);
            } else {
              // Could be a cross-product dependency - try to extract target name from module name
              // e.g., "ExpoModulesJSI" -> "JSI", "ExpoModulesCore" -> "Core"
              const moduleNameLower = imp.moduleName.toLowerCase();

              // Common patterns: ExpoModulesXXX -> XXX, ExpoXXX -> XXX
              let derivedTargetName: string | undefined;
              if (moduleNameLower.startsWith('expomodules')) {
                derivedTargetName = imp.moduleName.substring('ExpoModules'.length);
              } else if (moduleNameLower.startsWith('expo')) {
                derivedTargetName = imp.moduleName.substring('Expo'.length);
              }

              if (derivedTargetName) {
                // Check if there's a target with this derived name
                const derivedTarget = splitTargets.find(
                  (t) =>
                    t.name === derivedTargetName ||
                    t.name.toLowerCase() === derivedTargetName!.toLowerCase() ||
                    t.originalName === derivedTargetName ||
                    t.originalName.toLowerCase() === derivedTargetName!.toLowerCase()
                );
                if (derivedTarget && derivedTarget.name !== splitTarget.name) {
                  targetDeps.add(derivedTarget.name);
                } else {
                  // Add as external dependency - it's a cross-product target
                  externalDeps.add(derivedTargetName);
                }
              } else {
                // Add the full module name as external
                externalDeps.add(imp.moduleName);
              }
            }
          }
        }

        // Module-style imports (@import Module)
        if (imp.moduleName && !imp.isExternal && imp.type === 'module') {
          // Check if this matches any of our targets
          const matchingTarget = splitTargets.find(
            (t) => t.originalName === imp.moduleName || t.name === imp.moduleName
          );
          if (matchingTarget && matchingTarget.name !== splitTarget.name) {
            targetDeps.add(matchingTarget.name);
          } else {
            // It's an external module dependency
            externalDeps.add(imp.moduleName);
          }
        }
      }
    }

    splitTarget.dependencies = Array.from(targetDeps);
    splitTarget.externalDependencies = Array.from(externalDeps);
    splitTarget.linkedFrameworks = Array.from(linkedFrameworks);
  }

  return splitTargets;
}

/**
 * Detects cycles in the split target dependency graph
 * Returns an array of cycles, where each cycle is an array of target names
 */
function detectSplitTargetCycles(splitTargets: SplitTarget[]): string[][] {
  // Build a graph from split targets
  const graph = new Map<string, Set<string>>();
  for (const target of splitTargets) {
    graph.set(target.name, new Set(target.dependencies));
  }

  const cycles: string[][] = [];
  const visited = new Set<string>();
  const recStack = new Set<string>();
  const path: string[] = [];

  function dfs(node: string): void {
    visited.add(node);
    recStack.add(node);
    path.push(node);

    const neighbors = graph.get(node) || new Set();
    for (const neighbor of neighbors) {
      // Only consider internal targets (not external deps)
      if (!graph.has(neighbor)) continue;

      if (!visited.has(neighbor)) {
        dfs(neighbor);
      } else if (recStack.has(neighbor)) {
        // Found a cycle
        const cycleStart = path.indexOf(neighbor);
        if (cycleStart !== -1) {
          const cycle = [...path.slice(cycleStart), neighbor];
          // Avoid duplicate cycles
          const cycleKey = cycle.sort().join('->');
          if (!cycles.some((c) => c.sort().join('->') === cycleKey)) {
            cycles.push(path.slice(cycleStart));
          }
        }
      }
    }

    path.pop();
    recStack.delete(node);
  }

  for (const node of graph.keys()) {
    if (!visited.has(node)) {
      dfs(node);
    }
  }

  return cycles;
}

// ============================================================================
// Folder-based Target Listing (Root + top-level folders)
// ============================================================================

function getTopLevelTargetName(relativePath: string): string {
  const relDir = path.dirname(relativePath);
  const topDir = relDir.split(path.sep)[0] || 'Root';
  return topDir === '.' ? 'Root' : topDir;
}

function computeFolderTargets(
  files: Map<string, SourceFile>,
  dependencyGraph: Map<string, Set<string>>,
  sourceRoot: string
): FolderTargetSummary[] {
  const targetNames = new Set<string>(['Root']);
  for (const file of files.values()) {
    targetNames.add(getTopLevelTargetName(file.relativePath));
  }

  const nameToFiles = new Map<string, SourceFile[]>();
  for (const name of targetNames) {
    nameToFiles.set(name, []);
  }

  for (const file of files.values()) {
    const targetName = getTopLevelTargetName(file.relativePath);
    nameToFiles.get(targetName)!.push(file);
  }

  const summaries: FolderTargetSummary[] = [];

  for (const [name, targetFiles] of nameToFiles) {
    const hasSwift = targetFiles.some((f) => f.language === 'swift');
    const hasObjC = targetFiles.some((f) => f.language === 'objc' || f.language === 'header');
    const hasCpp = targetFiles.some((f) => f.language === 'cpp');

    const type: FolderTargetType =
      targetFiles.length === 0
        ? 'empty'
        : hasSwift && (hasObjC || hasCpp)
          ? 'mixed'
          : hasSwift
            ? 'swift'
            : hasCpp && !hasObjC
              ? 'cpp'
              : 'objc';

    const internalDeps = new Set<string>();
    const otherDeps = new Set<string>();
    const linkedFrameworks = new Set<string>();

    for (const file of targetFiles) {
      const fileDeps = dependencyGraph.get(file.filePath);
      if (fileDeps) {
        for (const depPath of fileDeps) {
          const depFile = files.get(depPath);
          if (!depFile) continue;
          const depTargetName = getTopLevelTargetName(depFile.relativePath);
          if (depTargetName !== name) {
            internalDeps.add(depTargetName);
          }
        }
      }

      for (const imp of file.imports) {
        if (imp.moduleName && imp.isExternal && KNOWN_SYSTEM_MODULES.has(imp.moduleName)) {
          linkedFrameworks.add(imp.moduleName);
        }
        if (imp.moduleName && !imp.isExternal) {
          // Try to map module imports to a known folder target name.
          // If no match, keep as a dependency name (e.g., React, Hermes, ExpoModulesJSI).
          const moduleName = imp.moduleName;
          const moduleNameLower = moduleName.toLowerCase();
          let candidate = moduleName;

          if (moduleNameLower.startsWith('expomodules')) {
            candidate = moduleName.substring('ExpoModules'.length);
          } else if (moduleNameLower.startsWith('expo')) {
            candidate = moduleName.substring('Expo'.length);
          }

          const matchesFolderTarget = targetNames.has(moduleName) || targetNames.has(candidate);
          if (matchesFolderTarget) {
            const depName = targetNames.has(moduleName) ? moduleName : candidate;
            if (depName !== name) {
              internalDeps.add(depName);
            }
          } else {
            if (isValidCrossProductDep(candidate)) {
              otherDeps.add(candidate);
            } else {
              otherDeps.add(moduleName);
            }
          }
        }
      }
    }

    const dependencies = Array.from(new Set([...internalDeps, ...otherDeps])).sort((a, b) =>
      a.localeCompare(b)
    );

    summaries.push({
      name,
      type,
      linkedFrameworks: Array.from(linkedFrameworks).sort((a, b) => a.localeCompare(b)),
      dependencies,
    });
  }

  return summaries.sort((a, b) => {
    if (a.name === 'Root') return -1;
    if (b.name === 'Root') return 1;
    return a.name.localeCompare(b.name);
  });
}

function findFolderTargetCycles(targets: FolderTargetSummary[]): string[][] {
  const targetSet = new Set(targets.map((t) => t.name));
  const graph = new Map<string, Set<string>>();

  for (const target of targets) {
    const deps = new Set<string>();
    for (const dep of target.dependencies) {
      if (targetSet.has(dep)) {
        deps.add(dep);
      }
    }
    graph.set(target.name, deps);
  }

  return detectCycles(graph);
}

function printFolderTargetsReport(result: AnalysisResult): void {
  const folderTargets = computeFolderTargets(
    result.files,
    result.dependencyGraph,
    result.sourceRoot
  );
  const cycles = findFolderTargetCycles(folderTargets);
  const cyclicTargets = new Set<string>();
  for (const cycle of cycles) {
    for (const name of cycle) {
      cyclicTargets.add(name);
    }
  }

  console.log(chalk.blue('\n📁 Folder-based targets (Root + top-level folders)'));
  if (cycles.length > 0) {
    console.log(chalk.yellow(`   Detected ${cycles.length} cyclic dependency cycle(s)`));
  } else {
    console.log(chalk.green('   No cyclic dependencies detected'));
  }

  for (const target of folderTargets) {
    console.log(chalk.white(`\n- ${target.name} (${target.type})`));
    console.log(
      chalk.gray(
        `  linkWithFrameworks: ${target.linkedFrameworks.length ? target.linkedFrameworks.join(', ') : '-'}`
      )
    );

    const depsText =
      target.dependencies.length === 0
        ? '-'
        : target.dependencies
            .map((dep) => (cyclicTargets.has(dep) ? chalk.red(dep) : dep))
            .join(', ');
    console.log(chalk.gray(`  dependencies: ${depsText}`));
  }
}

function getFolderKeyAtDepth(relativePath: string, depth: number): string {
  if (depth <= 0) return 'Root';
  const dir = path.dirname(relativePath);
  if (dir === '.' || dir === path.sep) return 'Root';
  const parts = dir.split(path.sep).filter(Boolean);
  if (parts.length === 0) return 'Root';
  return parts.slice(0, Math.min(depth, parts.length)).join('/');
}

function deriveVirtualTargetName(folderKey: string, language: VirtualTargetLanguage): string {
  const base = folderKey === 'Root' ? 'Root' : folderKey.replace(/\//g, '_');
  return `${base}_${language}`;
}

function computeVirtualTargets(
  files: Map<string, SourceFile>,
  dependencyGraph: Map<string, Set<string>>,
  maxDepth: number
): { targets: VirtualTargetSummary[]; cycles: string[][] } {
  // Track per-file depth override for iterative splitting.
  const fileDepthOverride = new Map<string, number>();

  function buildAtCurrentOverrides(): { targets: VirtualTargetSummary[]; cycles: string[][] } {
    const fileToTarget = new Map<string, string>();
    const targetToFiles = new Map<string, SourceFile[]>();

    // Step 1: assign files to (folderKey@depth, language)
    for (const file of files.values()) {
      // Skip language-less? (shouldn't happen)
      if (!file.language) continue;

      const depth = Math.min(fileDepthOverride.get(file.filePath) ?? 1, maxDepth);
      const folderKey = getFolderKeyAtDepth(file.relativePath, depth);

      // Group headers with objc by default.
      let language: VirtualTargetLanguage;
      if (file.language === 'swift') language = 'swift';
      else if (file.language === 'cpp') language = 'cpp';
      else language = 'objc';

      const targetName = deriveVirtualTargetName(folderKey, language);
      fileToTarget.set(file.filePath, targetName);
      if (!targetToFiles.has(targetName)) targetToFiles.set(targetName, []);
      targetToFiles.get(targetName)!.push(file);
    }

    // Ensure Root targets exist if there are any files at Root.
    // (No-op otherwise.)
    const targets: VirtualTargetSummary[] = [];

    // Step 2: compute dependencies/frameworks for each target
    for (const [targetName, targetFiles] of targetToFiles) {
      // Infer folderKey/depth/language back from the name by looking at one file.
      const sample = targetFiles[0];
      const depth = Math.min(fileDepthOverride.get(sample.filePath) ?? 1, maxDepth);
      const folderKey = getFolderKeyAtDepth(sample.relativePath, depth);
      const language: VirtualTargetLanguage = targetName.endsWith('_swift')
        ? 'swift'
        : targetName.endsWith('_cpp')
          ? 'cpp'
          : 'objc';

      const depTargets = new Set<string>();
      const externalDeps = new Set<string>();
      const linkedFrameworks = new Set<string>();

      for (const file of targetFiles) {
        const fileDeps = dependencyGraph.get(file.filePath);
        if (fileDeps) {
          for (const depPath of fileDeps) {
            const depTarget = fileToTarget.get(depPath);
            if (depTarget && depTarget !== targetName) {
              depTargets.add(depTarget);
            }
          }
        }

        for (const imp of file.imports) {
          if (imp.moduleName && imp.isExternal && KNOWN_SYSTEM_MODULES.has(imp.moduleName)) {
            linkedFrameworks.add(imp.moduleName);
          }
          if (imp.moduleName && !imp.isExternal) {
            // Keep as an external dep unless it resolves to an existing virtual target.
            const moduleName = imp.moduleName;
            const moduleNameLower = moduleName.toLowerCase();
            let derived: string | undefined;
            if (moduleNameLower.startsWith('expomodules')) {
              derived = moduleName.substring('ExpoModules'.length);
            } else if (moduleNameLower.startsWith('expo')) {
              derived = moduleName.substring('Expo'.length);
            }

            // Try map to virtual target names like Core_swift/Core_objc etc by checking suffixes.
            const candidates: string[] = [];
            for (const suffix of ['_swift', '_objc', '_cpp']) {
              candidates.push(`${moduleName}${suffix}`);
              if (derived) candidates.push(`${derived}${suffix}`);
            }

            const resolved = candidates.find((c) => targetToFiles.has(c));
            if (resolved && resolved !== targetName) {
              depTargets.add(resolved);
            } else {
              const depName = derived && isValidCrossProductDep(derived) ? derived : moduleName;
              externalDeps.add(depName);
            }
          }
        }
      }

      const dependencies = Array.from(new Set([...depTargets, ...externalDeps])).sort((a, b) =>
        a.localeCompare(b)
      );

      targets.push({
        name: targetName,
        folderKey,
        depth,
        language,
        linkedFrameworks: Array.from(linkedFrameworks).sort((a, b) => a.localeCompare(b)),
        dependencies,
      });
    }

    // Step 3: detect cycles among internal targets only
    const internalNames = new Set(targets.map((t) => t.name));
    const graph = new Map<string, Set<string>>();
    for (const t of targets) {
      const deps = new Set<string>();
      for (const d of t.dependencies) {
        if (internalNames.has(d)) deps.add(d);
      }
      graph.set(t.name, deps);
    }

    const cycles = detectCycles(graph);
    return {
      targets: targets.sort((a, b) => a.name.localeCompare(b.name)),
      cycles,
    };
  }

  // Initialize at depth=1 for all files
  for (const file of files.values()) {
    fileDepthOverride.set(file.filePath, 1);
  }

  let current = buildAtCurrentOverrides();
  let iteration = 0;

  while (current.cycles.length > 0 && iteration < maxDepth) {
    const cyclicTargets = new Set<string>();
    for (const c of current.cycles) {
      for (const n of c) cyclicTargets.add(n);
    }

    // For targets in cycles, increase depth for their files (split into deeper folder keys)
    let madeProgress = false;
    for (const file of files.values()) {
      const depth = Math.min(fileDepthOverride.get(file.filePath) ?? 1, maxDepth);
      const folderKey = getFolderKeyAtDepth(file.relativePath, depth);
      let language: VirtualTargetLanguage;
      if (file.language === 'swift') language = 'swift';
      else if (file.language === 'cpp') language = 'cpp';
      else language = 'objc';

      const targetName = deriveVirtualTargetName(folderKey, language);
      if (cyclicTargets.has(targetName) && depth < maxDepth) {
        fileDepthOverride.set(file.filePath, depth + 1);
        madeProgress = true;
      }
    }

    if (!madeProgress) {
      break;
    }

    current = buildAtCurrentOverrides();
    iteration++;
  }

  return current;
}

function computeVirtualTargetsByScc(
  files: Map<string, SourceFile>,
  dependencyGraph: Map<string, Set<string>>
): { targets: VirtualTargetSummary[]; cycles: string[][] } {
  // Build file-level graph restricted to known files.
  const fileGraph = new Map<string, Set<string>>();
  for (const filePath of files.keys()) {
    const deps = new Set<string>();
    const rawDeps = dependencyGraph.get(filePath);
    if (rawDeps) {
      for (const dep of rawDeps) {
        if (files.has(dep)) deps.add(dep);
      }
    }
    fileGraph.set(filePath, deps);
  }

  const sccs = findStronglyConnectedComponents(fileGraph);

  // Target assignment per file.
  const fileToTarget = new Map<string, string>();
  const targets: VirtualTargetSummary[] = [];

  // Temporary storage to compute deps later.
  const targetNameToFiles = new Map<string, SourceFile[]>();

  function addTarget(targetName: string, language: VirtualTargetLanguage, sccIndex: number): void {
    if (!targetNameToFiles.has(targetName)) {
      targetNameToFiles.set(targetName, []);
      targets.push({
        name: targetName,
        folderKey: `SCC${sccIndex}`,
        depth: 0,
        language,
        linkedFrameworks: [],
        dependencies: [],
      });
    }
  }

  function isObjcLike(f: SourceFile): boolean {
    return f.language === 'objc' || f.language === 'cpp' || f.language === 'header';
  }

  function swiftDependsOnObjcWithinScc(swiftFilePath: string, sccSet: Set<string>): boolean {
    const deps = dependencyGraph.get(swiftFilePath);
    if (!deps) return false;
    for (const dep of deps) {
      if (!sccSet.has(dep)) continue;
      const depFile = files.get(dep);
      if (depFile && isObjcLike(depFile)) return true;
    }
    return false;
  }

  function objcDependsOnSwiftWithinScc(objcFilePath: string, sccSet: Set<string>): boolean {
    const deps = dependencyGraph.get(objcFilePath);
    if (!deps) return false;
    for (const dep of deps) {
      if (!sccSet.has(dep)) continue;
      const depFile = files.get(dep);
      if (depFile && depFile.language === 'swift') return true;
    }
    return false;
  }

  // Step 1: for each SCC, split by language, and for mixed SCCs apply a small "base Swift" extraction.
  sccs.forEach((component, sccIndex) => {
    const sccSet = new Set(component);
    const componentFiles = component.map((p) => files.get(p)).filter(Boolean) as SourceFile[];

    const swiftFiles = componentFiles.filter((f) => f.language === 'swift');
    const objcFiles = componentFiles.filter((f) => isObjcLike(f));

    if (swiftFiles.length > 0 && objcFiles.length === 0) {
      const tName = `SCC${sccIndex}_swift`;
      addTarget(tName, 'swift', sccIndex);
      for (const f of swiftFiles) {
        fileToTarget.set(f.filePath, tName);
        targetNameToFiles.get(tName)!.push(f);
      }
      return;
    }

    if (objcFiles.length > 0 && swiftFiles.length === 0) {
      const tName = `SCC${sccIndex}_objc`;
      addTarget(tName, 'objc', sccIndex);
      for (const f of objcFiles) {
        fileToTarget.set(f.filePath, tName);
        targetNameToFiles.get(tName)!.push(f);
      }
      return;
    }

    // Mixed SCC: attempt Swift_base extraction for Swift files called by ObjC but not depending on ObjC.
    const swiftBase: SourceFile[] = [];
    const swiftMain: SourceFile[] = [];

    // Any Swift file that ObjC depends on (within SCC) and that itself doesn't depend on ObjC is a base candidate.
    const objcThatDependsOnSwift = objcFiles.filter((f) =>
      objcDependsOnSwiftWithinScc(f.filePath, sccSet)
    );
    const swiftUsedByObjc = new Set<string>();
    for (const objc of objcThatDependsOnSwift) {
      const deps = dependencyGraph.get(objc.filePath);
      if (!deps) continue;
      for (const dep of deps) {
        if (!sccSet.has(dep)) continue;
        const depFile = files.get(dep);
        if (depFile?.language === 'swift') swiftUsedByObjc.add(dep);
      }
    }

    for (const swiftFile of swiftFiles) {
      const usedByObjc = swiftUsedByObjc.has(swiftFile.filePath);
      const dependsOnObjc = swiftDependsOnObjcWithinScc(swiftFile.filePath, sccSet);

      if (usedByObjc && !dependsOnObjc) {
        swiftBase.push(swiftFile);
      } else {
        swiftMain.push(swiftFile);
      }
    }

    const objcTargetName = `SCC${sccIndex}_objc`;
    addTarget(objcTargetName, 'objc', sccIndex);
    for (const f of objcFiles) {
      fileToTarget.set(f.filePath, objcTargetName);
      targetNameToFiles.get(objcTargetName)!.push(f);
    }

    if (swiftBase.length > 0) {
      const baseName = `SCC${sccIndex}_swift_base`;
      addTarget(baseName, 'swift', sccIndex);
      for (const f of swiftBase) {
        fileToTarget.set(f.filePath, baseName);
        targetNameToFiles.get(baseName)!.push(f);
      }
    }

    if (swiftMain.length > 0) {
      const mainName = `SCC${sccIndex}_swift_main`;
      addTarget(mainName, 'swift', sccIndex);
      for (const f of swiftMain) {
        fileToTarget.set(f.filePath, mainName);
        targetNameToFiles.get(mainName)!.push(f);
      }
    }
  });

  // Step 2: compute per-target deps and frameworks.
  const targetNameToSummary = new Map<string, VirtualTargetSummary>();
  for (const t of targets) {
    targetNameToSummary.set(t.name, t);
  }
  const internalTargetNames = new Set(targets.map((t) => t.name));

  for (const [targetName, tFiles] of targetNameToFiles) {
    const depTargets = new Set<string>();
    const externalDeps = new Set<string>();
    const linkedFrameworks = new Set<string>();

    for (const file of tFiles) {
      const deps = dependencyGraph.get(file.filePath);
      if (deps) {
        for (const dep of deps) {
          const depTarget = fileToTarget.get(dep);
          if (depTarget && depTarget !== targetName) {
            depTargets.add(depTarget);
          }
        }
      }

      for (const imp of file.imports) {
        if (imp.moduleName && imp.isExternal && KNOWN_SYSTEM_MODULES.has(imp.moduleName)) {
          linkedFrameworks.add(imp.moduleName);
        }

        if (imp.moduleName && !imp.isExternal) {
          // Try to resolve module import to an internal target name first.
          const moduleName = imp.moduleName;
          const candidates: string[] = [];
          for (const suffix of ['_swift', '_swift_main', '_swift_base', '_objc', '_cpp']) {
            candidates.push(`${moduleName}${suffix}`);
          }
          const resolved = candidates.find((c) => internalTargetNames.has(c));
          if (resolved && resolved !== targetName) {
            depTargets.add(resolved);
          } else {
            externalDeps.add(moduleName);
          }
        }
      }
    }

    const summary = targetNameToSummary.get(targetName);
    if (summary) {
      summary.linkedFrameworks = Array.from(linkedFrameworks).sort((a, b) => a.localeCompare(b));
      summary.dependencies = Array.from(new Set([...depTargets, ...externalDeps])).sort((a, b) =>
        a.localeCompare(b)
      );
    }
  }

  // Step 3: detect cycles in internal-only target graph.
  const targetGraph = new Map<string, Set<string>>();
  for (const t of targets) {
    const deps = new Set<string>();
    for (const d of t.dependencies) {
      if (internalTargetNames.has(d)) deps.add(d);
    }
    targetGraph.set(t.name, deps);
  }
  const cycles = detectCycles(targetGraph);

  return {
    targets: targets.sort((a, b) => a.name.localeCompare(b.name)),
    cycles,
  };
}

/**
 * Determines which product a file belongs to based on its path and product definitions.
 * Returns the product name, or undefined if no specific product matches (catch-all will be used).
 */
function getFileProduct(
  filePath: string,
  productDefinitions: ProductDefinition[] | undefined
): string | undefined {
  if (!productDefinitions || productDefinitions.length === 0) {
    return undefined;
  }

  // Find specific products (non-catch-all)
  for (const prodDef of productDefinitions) {
    if (prodDef.pathPatterns.includes('*')) {
      continue; // Skip catch-all
    }

    const matches = prodDef.pathPatterns.some((pattern) => {
      // Check if the file path contains the pattern as a path component
      // e.g., pattern "JSI" should match "cpp/JSI/TypedArray.cpp" or "ios/JSI/EXStringUtils.cpp"
      const patternWithSlashes = '/' + pattern + '/';
      const patternAtStart = pattern + '/';
      const patternAtEnd = '/' + pattern;

      return (
        filePath.includes(patternWithSlashes) || // /JSI/ anywhere in path
        filePath.startsWith(patternAtStart) || // JSI/ at start
        filePath.endsWith(patternAtEnd) || // ends with /JSI (directory)
        filePath === pattern || // exact match
        // Also check for pattern as a directory component
        filePath.split('/').includes(pattern)
      );
    });

    if (matches) {
      return prodDef.name;
    }
  }

  // Return catch-all product name if exists, otherwise undefined
  const catchAll = productDefinitions.find((p) => p.pathPatterns.includes('*'));
  return catchAll?.name;
}

function computeSplitTargetsBySccVirtualTargets(
  files: Map<string, SourceFile>,
  dependencyGraph: Map<string, Set<string>>,
  productDefinitions?: ProductDefinition[]
): SplitTarget[] {
  // First, determine which product each file belongs to
  const fileToProduct = new Map<string, string | undefined>();
  for (const [filePath, file] of files.entries()) {
    const product = getFileProduct(file.relativePath, productDefinitions);
    fileToProduct.set(filePath, product);
  }

  // Build file-level graph restricted to known files AND same product.
  // Files in different products should not be grouped together in the same SCC.
  const fileGraph = new Map<string, Set<string>>();
  for (const filePath of files.keys()) {
    const fileProduct = fileToProduct.get(filePath);
    const deps = new Set<string>();
    const rawDeps = dependencyGraph.get(filePath);
    if (rawDeps) {
      for (const dep of rawDeps) {
        if (files.has(dep)) {
          // Only include dependency if it's in the same product (or both have no product)
          const depProduct = fileToProduct.get(dep);
          if (fileProduct === depProduct) {
            deps.add(dep);
          }
        }
      }
    }
    fileGraph.set(filePath, deps);
  }

  const sccs = findStronglyConnectedComponents(fileGraph);

  const fileToTarget = new Map<string, string>();
  const targetNameToFiles = new Map<string, SourceFile[]>();
  const targetNameToLanguage = new Map<string, SplitTarget['language']>();

  function isObjcLike(f: SourceFile): boolean {
    return f.language === 'objc' || f.language === 'cpp' || f.language === 'header';
  }

  function swiftDependsOnObjcWithinScc(swiftFilePath: string, sccSet: Set<string>): boolean {
    const deps = dependencyGraph.get(swiftFilePath);
    if (!deps) return false;
    for (const dep of deps) {
      if (!sccSet.has(dep)) continue;
      const depFile = files.get(dep);
      if (depFile && isObjcLike(depFile)) return true;
    }
    return false;
  }

  function objcDependsOnSwiftWithinScc(objcFilePath: string, sccSet: Set<string>): boolean {
    const deps = dependencyGraph.get(objcFilePath);
    if (!deps) return false;
    for (const dep of deps) {
      if (!sccSet.has(dep)) continue;
      const depFile = files.get(dep);
      if (depFile && depFile.language === 'swift') return true;
    }
    return false;
  }

  function addTarget(name: string, language: SplitTarget['language']): void {
    if (!targetNameToFiles.has(name)) {
      targetNameToFiles.set(name, []);
      targetNameToLanguage.set(name, language);
    }
  }

  // Step 1: assign files to SCC-derived targets.
  sccs.forEach((component, sccIndex) => {
    const sccSet = new Set(component);
    const componentFiles = component.map((p) => files.get(p)).filter(Boolean) as SourceFile[];

    const swiftFiles = componentFiles.filter((f) => f.language === 'swift');
    const objcLikeFiles = componentFiles.filter((f) => isObjcLike(f));

    if (swiftFiles.length > 0 && objcLikeFiles.length === 0) {
      const tName = `SCC${sccIndex}_swift`;
      addTarget(tName, 'swift');
      for (const f of swiftFiles) {
        fileToTarget.set(f.filePath, tName);
        targetNameToFiles.get(tName)!.push(f);
      }
      return;
    }

    if (objcLikeFiles.length > 0 && swiftFiles.length === 0) {
      // If this SCC is purely C/C++ (no ObjC), mark as cpp, otherwise objc.
      const hasObjc = objcLikeFiles.some((f) => f.language === 'objc');
      const tName = `SCC${sccIndex}_objc`;
      addTarget(tName, hasObjc ? 'objc' : 'cpp');
      for (const f of objcLikeFiles) {
        fileToTarget.set(f.filePath, tName);
        targetNameToFiles.get(tName)!.push(f);
      }
      return;
    }

    // Mixed SCC: attempt Swift_base extraction.
    const swiftBase: SourceFile[] = [];
    const swiftMain: SourceFile[] = [];

    const objcThatDependsOnSwift = objcLikeFiles.filter((f) =>
      objcDependsOnSwiftWithinScc(f.filePath, sccSet)
    );
    const swiftUsedByObjc = new Set<string>();
    for (const objcFile of objcThatDependsOnSwift) {
      const deps = dependencyGraph.get(objcFile.filePath);
      if (!deps) continue;
      for (const dep of deps) {
        if (!sccSet.has(dep)) continue;
        const depFile = files.get(dep);
        if (depFile?.language === 'swift') swiftUsedByObjc.add(dep);
      }
    }

    for (const swiftFile of swiftFiles) {
      const usedByObjc = swiftUsedByObjc.has(swiftFile.filePath);
      const dependsOnObjc = swiftDependsOnObjcWithinScc(swiftFile.filePath, sccSet);
      if (usedByObjc && !dependsOnObjc) {
        swiftBase.push(swiftFile);
      } else {
        swiftMain.push(swiftFile);
      }
    }

    // ObjC-like target for this SCC.
    const hasObjc = objcLikeFiles.some((f) => f.language === 'objc');
    const objcTargetName = `SCC${sccIndex}_objc`;
    addTarget(objcTargetName, hasObjc ? 'objc' : 'cpp');
    for (const f of objcLikeFiles) {
      fileToTarget.set(f.filePath, objcTargetName);
      targetNameToFiles.get(objcTargetName)!.push(f);
    }

    if (swiftBase.length > 0) {
      const baseName = `SCC${sccIndex}_swift_base`;
      addTarget(baseName, 'swift');
      for (const f of swiftBase) {
        fileToTarget.set(f.filePath, baseName);
        targetNameToFiles.get(baseName)!.push(f);
      }
    }

    if (swiftMain.length > 0) {
      const mainName = `SCC${sccIndex}_swift_main`;
      addTarget(mainName, 'swift');
      for (const f of swiftMain) {
        fileToTarget.set(f.filePath, mainName);
        targetNameToFiles.get(mainName)!.push(f);
      }
    }
  });

  // Step 2: compute dependencies and linked frameworks.
  const splitTargets: SplitTarget[] = [];
  const targetNames = Array.from(targetNameToFiles.keys());
  const validTargetNames = new Set(targetNames);

  for (const targetName of targetNames.sort((a, b) => a.localeCompare(b))) {
    const tFiles = targetNameToFiles.get(targetName) ?? [];
    const language = targetNameToLanguage.get(targetName) ?? 'objc';

    const depTargets = new Set<string>();
    const linkedFrameworks = new Set<string>();

    const sourceFiles: string[] = [];
    const headerFiles: string[] = [];

    for (const file of tFiles) {
      if (file.language === 'header') {
        headerFiles.push(file.relativePath);
      } else {
        sourceFiles.push(file.relativePath);
      }

      const deps = dependencyGraph.get(file.filePath);
      if (deps) {
        for (const dep of deps) {
          const depTarget = fileToTarget.get(dep);
          if (depTarget && depTarget !== targetName && validTargetNames.has(depTarget)) {
            depTargets.add(depTarget);
          }
        }
      }

      for (const imp of file.imports) {
        if (imp.moduleName && imp.isExternal && KNOWN_SYSTEM_MODULES.has(imp.moduleName)) {
          linkedFrameworks.add(imp.moduleName);
        }
      }
    }

    // Determine sourceRootName from files - if all files in this target share the same sourceRootName, use it
    const sourceRootNames = new Set(
      tFiles.map((f) => f.sourceRootName).filter((n): n is string => Boolean(n))
    );
    const sourceRootName = sourceRootNames.size === 1 ? Array.from(sourceRootNames)[0] : undefined;

    splitTargets.push({
      name: targetName,
      originalName: targetName,
      language,
      sourceFiles: sourceFiles.sort((a, b) => a.localeCompare(b)),
      headerFiles: headerFiles.sort((a, b) => a.localeCompare(b)),
      dependencies: Array.from(depTargets).sort((a, b) => a.localeCompare(b)),
      externalDependencies: [],
      linkedFrameworks: Array.from(linkedFrameworks).sort((a, b) => a.localeCompare(b)),
      wasSplit: true,
      sourceRootName,
    });
  }

  return splitTargets;
}

function printVirtualTargetsReport(
  result: AnalysisResult,
  mode: VirtualTargetsMode,
  maxDepth: number
): void {
  const { targets, cycles } =
    mode === 'scc'
      ? computeVirtualTargetsByScc(result.files, result.dependencyGraph)
      : computeVirtualTargets(result.files, result.dependencyGraph, maxDepth);
  const internalNames = new Set(targets.map((t) => t.name));

  // Build internal-only dependency graph for SCC computation.
  const graph = new Map<string, Set<string>>();
  for (const t of targets) {
    const deps = new Set<string>();
    for (const d of t.dependencies) {
      if (internalNames.has(d)) deps.add(d);
    }
    graph.set(t.name, deps);
  }

  // Strongly connected components (SCCs) give a stable definition of "in a cycle".
  const sccs = findStronglyConnectedComponents(graph);
  const targetToScc = new Map<string, number>();
  const cyclicScc = new Set<number>();
  sccs.forEach((component, idx) => {
    for (const name of component) {
      targetToScc.set(name, idx);
    }
    if (component.length > 1) {
      cyclicScc.add(idx);
    } else {
      // Self-loop counts as a cycle.
      const only = component[0];
      if (only && graph.get(only)?.has(only)) {
        cyclicScc.add(idx);
      }
    }
  });

  const title =
    mode === 'scc'
      ? '\n🧩 Virtual targets (SCC heuristic)'
      : `\n🧩 Virtual targets (iterative folder splitting, maxDepth=${maxDepth})`;
  console.log(chalk.blue(title));
  if (cycles.length > 0) {
    console.log(chalk.yellow(`   Remaining cycle(s): ${cycles.length}`));
  } else {
    console.log(chalk.green('   No cyclic dependencies detected'));
  }

  for (const t of targets) {
    console.log(
      chalk.white(`\n- ${t.name} [${t.language}] (folder: ${t.folderKey}, depth: ${t.depth})`)
    );
    console.log(
      chalk.gray(
        `  linkWithFrameworks: ${t.linkedFrameworks.length ? t.linkedFrameworks.join(', ') : '-'}`
      )
    );

    const depsText =
      t.dependencies.length === 0
        ? '-'
        : t.dependencies
            .map((dep) => {
              const depScc = targetToScc.get(dep);
              const tScc = targetToScc.get(t.name);

              // Only color internal deps red when they are in the same cyclic SCC as the current target.
              if (
                depScc !== undefined &&
                tScc !== undefined &&
                depScc === tScc &&
                cyclicScc.has(tScc)
              ) {
                return chalk.red(dep);
              }
              return dep;
            })
            .join(', ');
    console.log(chalk.gray(`  dependencies: ${depsText}`));
  }
}

/**
 * Information about headers that can be extracted to break a cycle
 */
interface BridgingTargetSuggestion {
  /** Name for the suggested bridging target */
  name: string;
  /** The cycle this bridging target would break */
  cycle: string[];
  /** Headers that should be moved to the bridging target */
  headers: string[];
  /** Why these headers were selected */
  reason: string;
  /** New dependencies for targets after extraction */
  newDependencies: Map<string, string[]>;
}

/**
 * Analyzes cycles and suggests bridging targets to break them.
 *
 * The algorithm:
 * 1. For each cycle (A → B → A), find what headers A imports from B
 * 2. Check if those headers can be "extracted" - i.e., they don't depend back on A
 * 3. If so, suggest moving those headers to a new "Base" target
 * 4. After extraction: A → Base, B → Base (and B can still → A if needed)
 */
function suggestBridgingTargets(
  cycles: string[][],
  splitTargets: SplitTarget[],
  files: Map<string, SourceFile>,
  headers: Map<string, string>,
  sourceRoot: string
): BridgingTargetSuggestion[] {
  const suggestions: BridgingTargetSuggestion[] = [];

  // Build a map of target name to target
  const targetMap = new Map<string, SplitTarget>();
  for (const target of splitTargets) {
    targetMap.set(target.name, target);
  }

  // Build a map of header path to the files in each target
  const headerToTarget = new Map<string, string>();
  for (const target of splitTargets) {
    for (const headerFile of target.headerFiles) {
      const fullPath = path.join(sourceRoot, headerFile);
      headerToTarget.set(fullPath, target.name);
      headerToTarget.set(headerFile, target.name);
    }
  }

  for (const cycle of cycles) {
    if (cycle.length < 2) continue;

    // For a cycle like [A, B], we have A → B and B → A
    // We need to find which direction can be "broken" by extracting headers

    const headerImportChain: Map<string, Set<string>> = new Map();

    // Analyze each pair in the cycle
    for (let i = 0; i < cycle.length; i++) {
      const fromTarget = cycle[i];
      const toTarget = cycle[(i + 1) % cycle.length];

      const fromTargetData = targetMap.get(fromTarget);
      const toTargetData = targetMap.get(toTarget);

      if (!fromTargetData || !toTargetData) continue;

      // Find which headers in toTarget are imported by fromTarget
      const importedHeaders: string[] = [];

      // Get all files in fromTarget (including headers)
      const fromFiles = [...fromTargetData.sourceFiles, ...fromTargetData.headerFiles];

      for (const sourceFile of fromFiles) {
        const fullPath = path.join(sourceRoot, sourceFile);
        const fileData = files.get(fullPath);
        if (!fileData) continue;

        for (const imp of fileData.imports) {
          if (imp.isExternal) continue;

          // Try to resolve this import to a header in toTarget
          let headerPath: string | undefined;
          if (imp.headerName) {
            headerPath = headers.get(imp.headerName) || headers.get(path.basename(imp.headerName));
          }

          if (headerPath) {
            const headerTargetName = headerToTarget.get(headerPath);
            if (headerTargetName === toTarget) {
              const relPath = path.relative(sourceRoot, headerPath);
              if (!importedHeaders.includes(relPath)) {
                importedHeaders.push(relPath);
              }
            }
          }
        }
      }

      headerImportChain.set(`${fromTarget} → ${toTarget}`, new Set(importedHeaders));
    }

    // Now find headers that can be extracted
    // A header can be extracted if it doesn't import anything from targets in the cycle
    // (except possibly from other extractable headers)

    const allImportedHeaders = new Set<string>();
    for (const headers of headerImportChain.values()) {
      for (const h of headers) {
        allImportedHeaders.add(h);
      }
    }

    const canExtract: string[] = [];
    const cannotExtract: Map<string, string[]> = new Map();

    for (const headerRelPath of allImportedHeaders) {
      const headerFullPath = path.join(sourceRoot, headerRelPath);
      const headerFile = files.get(headerFullPath);

      if (!headerFile) {
        // Header not parsed, assume it can be extracted
        canExtract.push(headerRelPath);
        continue;
      }

      // Check what this header imports
      const problematicImports: string[] = [];

      for (const imp of headerFile.imports) {
        if (imp.isExternal) continue;

        let importedHeaderPath: string | undefined;
        if (imp.headerName) {
          importedHeaderPath =
            headers.get(imp.headerName) || headers.get(path.basename(imp.headerName));
        }

        if (importedHeaderPath) {
          const importedTargetName = headerToTarget.get(importedHeaderPath);
          // If this header imports something from a target in the cycle
          // that's NOT in allImportedHeaders, it can't be easily extracted
          if (importedTargetName && cycle.includes(importedTargetName)) {
            const importedRelPath = path.relative(sourceRoot, importedHeaderPath);
            if (!allImportedHeaders.has(importedRelPath)) {
              problematicImports.push(`${imp.headerName} (from ${importedTargetName})`);
            }
          }
        }
      }

      if (problematicImports.length === 0) {
        canExtract.push(headerRelPath);
      } else {
        cannotExtract.set(headerRelPath, problematicImports);
      }
    }

    if (canExtract.length > 0) {
      // Determine which target's headers we're extracting from
      const targetCounts = new Map<string, number>();
      for (const h of canExtract) {
        const fullPath = path.join(sourceRoot, h);
        const targetName = headerToTarget.get(fullPath) || headerToTarget.get(h);
        if (targetName) {
          targetCounts.set(targetName, (targetCounts.get(targetName) || 0) + 1);
        }
      }

      // Find the target with most extractable headers
      let mainSourceTarget = '';
      let maxCount = 0;
      for (const [target, count] of targetCounts) {
        if (count > maxCount) {
          maxCount = count;
          mainSourceTarget = target;
        }
      }

      // Calculate new dependencies
      const newDeps = new Map<string, string[]>();
      const bridgingTargetName = `${mainSourceTarget.replace(/_objc$/, '')}_Base`;

      for (const targetName of cycle) {
        const target = targetMap.get(targetName);
        if (!target) continue;

        const currentDeps = [...target.dependencies];
        const newTargetDeps: string[] = [];

        for (const dep of currentDeps) {
          if (dep === mainSourceTarget) {
            // Replace dependency on mainSourceTarget with dependency on bridging target
            // if all the imports from mainSourceTarget are being extracted
            const importsFromDep = headerImportChain.get(`${targetName} → ${dep}`);
            if (importsFromDep && [...importsFromDep].every((h) => canExtract.includes(h))) {
              if (!newTargetDeps.includes(bridgingTargetName)) {
                newTargetDeps.push(bridgingTargetName);
              }
            } else {
              // Keep the original dependency AND add bridging target
              newTargetDeps.push(dep);
              if (!newTargetDeps.includes(bridgingTargetName)) {
                newTargetDeps.push(bridgingTargetName);
              }
            }
          } else {
            newTargetDeps.push(dep);
          }
        }

        newDeps.set(targetName, newTargetDeps);
      }

      suggestions.push({
        name: bridgingTargetName,
        cycle,
        headers: canExtract,
        reason: `Extract ${canExtract.length} header(s) from ${mainSourceTarget} that don't have cyclic dependencies`,
        newDependencies: newDeps,
      });
    }
  }

  return suggestions;
}

// ============================================================================
// Swift Usage Analysis
// ============================================================================

/**
 * Analyzes Swift usage in ObjC files to help determine the best SPM migration strategy
 */
function analyzeSwiftUsage(files: Map<string, SourceFile>, sourceRoot: string): SwiftUsageAnalysis {
  const filesImportingSwiftHeader: SwiftUsageInfo[] = [];
  const allSwiftTypes = new Set<string>();

  // Known Swift types in expo-modules-core (these start with EX)
  const knownSwiftPrefixes = ['EX', 'Expo'];

  for (const file of files.values()) {
    // Only analyze ObjC/ObjC++ files
    if (file.language !== 'objc') continue;

    // Check if file imports Swift.h
    const importsSwiftHeader = file.imports.some(
      (imp) => imp.raw.includes('/Swift.h') || imp.raw === 'Swift.h'
    );

    if (!importsSwiftHeader) continue;

    // Read file content to analyze Swift type usage
    const filePath = path.join(sourceRoot, file.relativePath);
    let content: string;
    try {
      content = fs.readFileSync(filePath, 'utf-8');
    } catch {
      console.warn(`Warning: Could not read file ${filePath}`);
      continue;
    }

    const lines = content.split('\n');
    const swiftTypesInFile = new Map<string, SwiftTypeUsage>();

    // Analyze each line for Swift type usage
    lines.forEach((line, lineIndex) => {
      const lineNumber = lineIndex + 1;

      // Pattern 1: Class instantiation [[ClassName alloc] init]
      const allocMatches = line.matchAll(/\[\[\s*([A-Z][A-Za-z0-9_]*)\s+alloc\]/g);
      for (const match of allocMatches) {
        const typeName = match[1];
        if (isLikelySwiftType(typeName, knownSwiftPrefixes)) {
          addSwiftTypeUsage(swiftTypesInFile, typeName, 'instantiation', lineNumber, allSwiftTypes);
        }
      }

      // Pattern 2: Type declarations and casts
      const typeRefMatches = line.matchAll(/([A-Z][A-Za-z0-9_]*)\s+\*/g);
      for (const match of typeRefMatches) {
        const typeName = match[1];
        if (isLikelySwiftType(typeName, knownSwiftPrefixes)) {
          // Determine if it's a cast or declaration
          const usageType = line.includes(`(${typeName}`) ? 'cast' : 'type-reference';
          addSwiftTypeUsage(swiftTypesInFile, typeName, usageType, lineNumber, allSwiftTypes);
        }
      }

      // Pattern 3: Method calls [object methodName:...]
      const methodCallMatches = line.matchAll(/\[\s*(\w+)\s+([a-zA-Z][a-zA-Z0-9_:]*)/g);
      for (const match of methodCallMatches) {
        const receiver = match[1];
        const method = match[2];

        // Check if receiver might be a Swift type (starts with capital letter)
        if (/^[A-Z]/.test(receiver) && isLikelySwiftType(receiver, knownSwiftPrefixes)) {
          const existing = swiftTypesInFile.get(receiver);
          if (existing) {
            if (!existing.methodsCalled.includes(method)) {
              existing.methodsCalled.push(method);
            }
            if (existing.usageType !== 'instantiation') {
              existing.usageType = 'method-call';
            }
          } else {
            addSwiftTypeUsage(
              swiftTypesInFile,
              receiver,
              'method-call',
              lineNumber,
              allSwiftTypes,
              [method]
            );
          }
        }
      }

      // Pattern 4: Property access object.propertyName (Swift style)
      const propertyMatches = line.matchAll(/(\w+)\.([a-z][a-zA-Z0-9_]*)/g);
      for (const match of propertyMatches) {
        const receiver = match[1];

        if (/^[A-Z]/.test(receiver) && isLikelySwiftType(receiver, knownSwiftPrefixes)) {
          const existing = swiftTypesInFile.get(receiver);
          if (existing) {
            if (existing.usageType !== 'instantiation' && existing.usageType !== 'method-call') {
              existing.usageType = 'property';
            }
          }
        }
      }
    });

    if (swiftTypesInFile.size > 0) {
      const totalUsages = Array.from(swiftTypesInFile.values()).reduce(
        (sum, usage) => sum + usage.lineNumbers.length,
        0
      );

      filesImportingSwiftHeader.push({
        filePath: file.filePath,
        relativePath: file.relativePath,
        importsSwiftHeader: true,
        swiftTypes: Array.from(swiftTypesInFile.values()),
        totalUsages,
      });
    } else {
      // File imports Swift.h but we didn't detect specific usage patterns
      // Still include it in the list
      filesImportingSwiftHeader.push({
        filePath: file.filePath,
        relativePath: file.relativePath,
        importsSwiftHeader: true,
        swiftTypes: [],
        totalUsages: 0,
      });
    }
  }

  // Generate recommendation based on analysis
  const recommendation = generateSwiftUsageRecommendation(filesImportingSwiftHeader, allSwiftTypes);

  return {
    filesImportingSwiftHeader,
    allSwiftTypes,
    totalFilesImportingSwift: filesImportingSwiftHeader.length,
    recommendation,
  };
}

/**
 * Checks if a type name is likely a Swift type based on naming conventions
 */
function isLikelySwiftType(typeName: string, knownPrefixes: string[]): boolean {
  // Filter out common ObjC types
  const commonObjCTypes = new Set([
    'NSString',
    'NSArray',
    'NSDictionary',
    'NSNumber',
    'NSError',
    'NSData',
    'NSURL',
    'NSObject',
    'UIView',
    'UIViewController',
    'RCTBridge',
    'RCTRootView',
    'RCTModuleData',
  ]);

  if (commonObjCTypes.has(typeName)) return false;

  // Check if it starts with any known Swift prefix
  return knownPrefixes.some((prefix) => typeName.startsWith(prefix));
}

/**
 * Adds Swift type usage to the tracking map
 */
function addSwiftTypeUsage(
  map: Map<string, SwiftTypeUsage>,
  typeName: string,
  usageType: SwiftTypeUsage['usageType'],
  lineNumber: number,
  allTypes: Set<string>,
  methodsCalled: string[] = []
): void {
  allTypes.add(typeName);

  if (map.has(typeName)) {
    const existing = map.get(typeName)!;
    if (!existing.lineNumbers.includes(lineNumber)) {
      existing.lineNumbers.push(lineNumber);
    }
    // Upgrade usage type if more specific
    if (usageType === 'instantiation') {
      existing.usageType = usageType;
    }
    existing.methodsCalled.push(...methodsCalled);
  } else {
    map.set(typeName, {
      typeName,
      usageType,
      lineNumbers: [lineNumber],
      methodsCalled: [...methodsCalled],
    });
  }
}

/**
 * Generates a recommendation for handling Swift/ObjC interop
 */
function generateSwiftUsageRecommendation(
  filesImportingSwift: SwiftUsageInfo[],
  allSwiftTypes: Set<string>
): SwiftUsageAnalysis['recommendation'] {
  const totalFiles = filesImportingSwift.length;
  const totalTypes = allSwiftTypes.size;

  // Calculate total usage complexity
  const totalUsages = filesImportingSwift.reduce((sum, file) => sum + file.totalUsages, 0);
  const avgUsagesPerFile = totalFiles > 0 ? totalUsages / totalFiles : 0;

  // Determine recommendation based on metrics
  if (totalFiles === 0) {
    return {
      approach: 'unified-target',
      reason: 'No ObjC files import Swift.h, can use unified target or any approach',
      effort: 'low',
      risk: 'low',
    };
  }

  if (totalFiles <= 3 && totalTypes <= 5 && avgUsagesPerFile <= 5) {
    return {
      approach: 'runtime-lookups',
      reason: `Only ${totalFiles} files import Swift.h with ${totalTypes} Swift types and low usage density. Runtime lookups are practical.`,
      effort: 'low',
      risk: 'low',
    };
  }

  if (totalFiles <= 10 && totalTypes <= 15) {
    return {
      approach: 'convert-to-swift',
      reason: `${totalFiles} ObjC files use ${totalTypes} Swift types. Converting to Swift is feasible and provides long-term benefits.`,
      effort: 'medium',
      risk: 'medium',
    };
  }

  if (totalFiles > 10 || totalTypes > 15) {
    return {
      approach: 'layered-architecture',
      reason: `High coupling: ${totalFiles} files use ${totalTypes} Swift types. Requires architectural refactoring to separate concerns.`,
      effort: 'high',
      risk: 'medium',
    };
  }

  // Fallback
  return {
    approach: 'unified-target',
    reason:
      'Complex interop detected. Consider unified target for SPM until refactoring is feasible.',
    effort: 'low',
    risk: 'low',
  };
}

/**
 * Finds Swift files that define types used by ObjC code.
 * Returns a map of Swift type name -> Swift file path that defines it.
 */
function findSwiftTypeDefinitions(
  files: Map<string, SourceFile>,
  swiftTypes: Set<string>,
  sourceRoot: string
): Map<string, string> {
  const typeToFile = new Map<string, string>();

  // Patterns to find type definitions in Swift files
  // @objc class ClassName, @objc(ObjCName) class ClassName, public class ClassName
  const classPatterns = [
    /@objc(?:\([^)]*\))?\s*(?:public\s+)?class\s+(\w+)/g,
    /(?:public\s+)?class\s+(\w+)\s*:/g,
    /@objc(?:\([^)]*\))?\s*(?:public\s+)?(?:final\s+)?class\s+(\w+)/g,
  ];

  // @objc protocol ProtocolName
  const protocolPatterns = [/@objc(?:\([^)]*\))?\s*(?:public\s+)?protocol\s+(\w+)/g];

  // @objc enum EnumName
  const enumPatterns = [/@objc(?:\([^)]*\))?\s*(?:public\s+)?enum\s+(\w+)/g];

  for (const file of files.values()) {
    if (file.language !== 'swift') continue;

    const filePath = path.join(sourceRoot, file.relativePath);
    let content: string;
    try {
      content = fs.readFileSync(filePath, 'utf-8');
    } catch {
      continue;
    }

    // Find all type definitions in this file
    const allPatterns = [...classPatterns, ...protocolPatterns, ...enumPatterns];

    for (const pattern of allPatterns) {
      // Reset regex state
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(content)) !== null) {
        const typeName = match[1];
        // Only track if this type is one we're looking for
        if (swiftTypes.has(typeName)) {
          typeToFile.set(typeName, file.relativePath);
        }
      }
    }
  }

  return typeToFile;
}

/**
 * Checks if a Swift file has dependencies on ObjC code (imports ObjC headers).
 * Returns true if the Swift file depends on ObjC.
 */
function swiftFileDependsOnObjC(
  swiftFile: SourceFile,
  splitTargets: SplitTarget[],
  files: Map<string, SourceFile>,
  headers: Map<string, string>,
  dependencyGraph: Map<string, Set<string>>
): boolean {
  // Check direct imports from the file
  for (const imp of swiftFile.imports) {
    if (imp.isExternal) continue;

    // If it imports an ObjC header directly
    if (imp.headerName) {
      const headerPath = headers.get(imp.headerName) || headers.get(path.basename(imp.headerName));
      if (headerPath) {
        // Check if this header is in an ObjC target
        const headerTarget = splitTargets.find((t) =>
          t.headerFiles.some(
            (h) =>
              h === path.relative(files.get(headerPath)?.filePath || '', headerPath) ||
              h.endsWith(imp.headerName!)
          )
        );
        if (headerTarget && headerTarget.language === 'objc') {
          return true;
        }
      }
    }
  }

  // Check dependency graph
  const fileDeps = dependencyGraph.get(swiftFile.filePath);
  if (fileDeps) {
    for (const depPath of fileDeps) {
      const depFile = files.get(depPath);
      if (depFile && (depFile.language === 'objc' || depFile.language === 'header')) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Suggests Swift base targets to break Swift/ObjC cyclic dependencies.
 *
 * The algorithm:
 * 1. Find all Swift types that are used by ObjC files (from Swift usage analysis)
 * 2. Find which Swift files define those types
 * 3. Check if those Swift files can be extracted (don't depend on ObjC)
 * 4. Suggest creating a Swift base target with those files
 */
function suggestSwiftBridgingTargets(
  swiftUsageAnalysis: SwiftUsageAnalysis,
  splitTargets: SplitTarget[],
  files: Map<string, SourceFile>,
  headers: Map<string, string>,
  dependencyGraph: Map<string, Set<string>>,
  sourceRoot: string
): SwiftBridgingSuggestion[] {
  const suggestions: SwiftBridgingSuggestion[] = [];

  // Skip if no Swift usage in ObjC
  if (swiftUsageAnalysis.totalFilesImportingSwift === 0) {
    return suggestions;
  }

  // Step 1: Find which Swift files define the types used by ObjC
  const typeToFile = findSwiftTypeDefinitions(files, swiftUsageAnalysis.allSwiftTypes, sourceRoot);

  if (typeToFile.size === 0) {
    console.log(chalk.gray('   Could not locate Swift type definitions'));
    return suggestions;
  }

  // Step 2: Group Swift files by their target
  const targetToExtractableFiles = new Map<
    string,
    {
      files: string[];
      types: string[];
      dependsOnObjC: Map<string, boolean>;
    }
  >();

  // Find which ObjC targets need each Swift type
  const typeToObjcTargets = new Map<string, Set<string>>();
  for (const fileInfo of swiftUsageAnalysis.filesImportingSwiftHeader) {
    // Find which target this ObjC file belongs to
    const objcFile = files.get(fileInfo.filePath);
    if (!objcFile) continue;

    const objcTarget = splitTargets.find((t) =>
      t.sourceFiles.some((f) => f === objcFile.relativePath)
    );
    if (!objcTarget) continue;

    for (const usage of fileInfo.swiftTypes) {
      if (!typeToObjcTargets.has(usage.typeName)) {
        typeToObjcTargets.set(usage.typeName, new Set());
      }
      typeToObjcTargets.get(usage.typeName)!.add(objcTarget.name);
    }
  }

  // Step 3: For each Swift type, check if its source file can be extracted
  for (const [typeName, swiftFilePath] of typeToFile) {
    const fullPath = path.join(sourceRoot, swiftFilePath);
    const swiftFile = files.get(fullPath);
    if (!swiftFile) continue;

    // Find which Swift target this file belongs to
    const swiftTarget = splitTargets.find(
      (t) => t.language === 'swift' && t.sourceFiles.some((f) => f === swiftFilePath)
    );
    if (!swiftTarget) continue;

    // Check if this Swift file depends on ObjC
    const dependsOnObjC = swiftFileDependsOnObjC(
      swiftFile,
      splitTargets,
      files,
      headers,
      dependencyGraph
    );

    // Initialize target entry if needed
    if (!targetToExtractableFiles.has(swiftTarget.name)) {
      targetToExtractableFiles.set(swiftTarget.name, {
        files: [],
        types: [],
        dependsOnObjC: new Map(),
      });
    }

    const targetEntry = targetToExtractableFiles.get(swiftTarget.name)!;
    if (!targetEntry.files.includes(swiftFilePath)) {
      targetEntry.files.push(swiftFilePath);
      targetEntry.dependsOnObjC.set(swiftFilePath, dependsOnObjC);
    }
    if (!targetEntry.types.includes(typeName)) {
      targetEntry.types.push(typeName);
    }
  }

  // Step 4: Generate suggestions for each Swift target that has extractable files
  for (const [swiftTargetName, entry] of targetToExtractableFiles) {
    // Filter to only files that don't depend on ObjC
    const extractableFiles = entry.files.filter((f) => !entry.dependsOnObjC.get(f));
    const nonExtractableFiles = entry.files.filter((f) => entry.dependsOnObjC.get(f));

    // Find which types are in extractable files
    const extractableTypes: string[] = [];
    for (const [typeName, filePath] of typeToFile) {
      if (extractableFiles.includes(filePath)) {
        extractableTypes.push(typeName);
      }
    }

    // Find which ObjC targets need these types
    const objcTargetsNeeding = new Set<string>();
    for (const typeName of extractableTypes) {
      const targets = typeToObjcTargets.get(typeName);
      if (targets) {
        for (const t of targets) {
          objcTargetsNeeding.add(t);
        }
      }
    }

    if (extractableFiles.length > 0 && extractableTypes.length > 0) {
      const baseTargetName = `${swiftTargetName.replace(/_swift$/, '')}_swift_base`;

      suggestions.push({
        name: baseTargetName,
        sourceTarget: swiftTargetName,
        objcTargets: Array.from(objcTargetsNeeding),
        swiftFiles: extractableFiles,
        exposedTypes: extractableTypes,
        reason: `Extract ${extractableFiles.length} Swift file(s) defining ${extractableTypes.length} type(s) used by ObjC. These files don't depend on ObjC, so they can form a base target.`,
      });
    }

    // Log info about non-extractable files
    if (nonExtractableFiles.length > 0) {
      console.log(
        chalk.yellow(
          `   ⚠️  ${nonExtractableFiles.length} Swift file(s) in ${swiftTargetName} depend on ObjC and cannot be extracted`
        )
      );
      for (const f of nonExtractableFiles) {
        console.log(chalk.gray(`      - ${f}`));
      }
    }
  }

  return suggestions;
}

// ============================================================================
// Main Analysis Functions
// ============================================================================

/** Default directories to exclude from analysis */
const DEFAULT_EXCLUDE_DIRS = ['**/Tests'];

/**
 * Analyzes a source directory and returns dependency information
 */
export async function analyzeSourceDirectory(options: AnalyzerOptions): Promise<AnalysisResult> {
  const {
    sourceRoot,
    excludeDirs = [],
    includePaths = [],
    verbose = false,
    useClang = false,
  } = options;

  // Combine user excludes with defaults
  const allExcludeDirs = [...new Set([...DEFAULT_EXCLUDE_DIRS, ...excludeDirs])];

  console.log(chalk.blue('\n📂 Analyzing source directory:'), chalk.gray(sourceRoot));

  // Step 1: Find all source files
  console.log(chalk.blue('\n🔍 Step 1: Finding source files...'));
  const { sources, headers } = await findSourceFiles(sourceRoot, allExcludeDirs);
  console.log(`   Found ${chalk.green(sources.length)} source files`);
  console.log(`   Found ${chalk.green(headers.length)} header files`);

  // Step 2: Build header map
  console.log(chalk.blue('\n📑 Step 2: Building header map...'));
  const headerMap = new Map<string, string>();
  for (const headerPath of headers) {
    const headerName = path.basename(headerPath);
    headerMap.set(headerName, headerPath);
    // Also map relative paths
    const relPath = path.relative(sourceRoot, headerPath);
    headerMap.set(relPath, headerPath);
  }
  console.log(`   Mapped ${chalk.green(headerMap.size)} headers`);

  // Step 3: Parse all files
  console.log(chalk.blue('\n📖 Step 3: Parsing imports...'));
  const files = new Map<string, SourceFile>();

  // Parse source files
  for (const filePath of sources) {
    const content = await fs.readFile(filePath, 'utf-8');
    const ext = path.extname(filePath).toLowerCase();
    const isSwift = ext === '.swift';

    const imports = isSwift ? parseSwiftImports(content) : parseObjCImports(content);

    const sourceFile: SourceFile = {
      filePath,
      relativePath: path.relative(sourceRoot, filePath),
      name: path.basename(filePath, ext),
      extension: ext,
      language: isSwift ? 'swift' : ext === '.cpp' ? 'cpp' : 'objc',
      imports,
      importedBy: [],
    };

    files.set(filePath, sourceFile);
  }

  // Parse header files too
  for (const filePath of headers) {
    const content = await fs.readFile(filePath, 'utf-8');
    const ext = path.extname(filePath).toLowerCase();
    const imports = parseObjCImports(content);

    const sourceFile: SourceFile = {
      filePath,
      relativePath: path.relative(sourceRoot, filePath),
      name: path.basename(filePath, ext),
      extension: ext,
      language: 'header',
      imports,
      importedBy: [],
    };

    files.set(filePath, sourceFile);
  }

  console.log(`   Parsed ${chalk.green(files.size)} files`);

  // Step 4: Build dependency graph
  // Note: process.platform is 'win32' on Windows, 'darwin' on macOS, 'linux' on Linux
  const useClangAnalysis = useClang && process.platform !== 'win32';
  if (useClangAnalysis) {
    console.log(chalk.blue('\n🔗 Step 4: Building dependency graph (using clang -MM)...'));
  } else {
    console.log(chalk.blue('\n🔗 Step 4: Building dependency graph (regex-based)...'));
  }

  const dependencyGraph = new Map<string, Set<string>>();
  const reverseDependencyGraph = new Map<string, Set<string>>();

  // Initialize graphs
  for (const filePath of files.keys()) {
    dependencyGraph.set(filePath, new Set());
    reverseDependencyGraph.set(filePath, new Set());
  }

  // Build default include paths from the source directory structure
  const defaultIncludePaths = [sourceRoot];
  // Add all directories containing headers
  for (const headerPath of headers) {
    const headerDir = path.dirname(headerPath);
    if (!defaultIncludePaths.includes(headerDir)) {
      defaultIncludePaths.push(headerDir);
    }
  }
  const allIncludePaths = [...defaultIncludePaths, ...includePaths];

  if (useClangAnalysis) {
    // Use clang -MM for accurate dependency resolution
    console.log(chalk.gray(`   Using ${allIncludePaths.length} include paths`));
    if (verbose) {
      for (const p of allIncludePaths.slice(0, 5)) {
        console.log(chalk.gray(`     -I ${p}`));
      }
      if (allIncludePaths.length > 5) {
        console.log(chalk.gray(`     ... and ${allIncludePaths.length - 5} more`));
      }
    }

    let processedCount = 0;
    const objcSources = Array.from(files.values()).filter(
      (f) => f.language === 'objc' || f.language === 'cpp'
    );

    for (const file of objcSources) {
      const clangDeps = getClangDependencies(file.filePath, allIncludePaths, verbose);
      processedCount++;

      for (const depPath of clangDeps) {
        // Normalize the path
        const normalizedDepPath = path.resolve(depPath);

        // Check if this dependency is in our file set
        if (files.has(normalizedDepPath)) {
          dependencyGraph.get(file.filePath)!.add(normalizedDepPath);
          reverseDependencyGraph.get(normalizedDepPath)!.add(file.filePath);
          files.get(normalizedDepPath)!.importedBy.push(file.filePath);
        } else if (headerMap.has(path.basename(depPath))) {
          // Try to find by basename
          const headerPath = headerMap.get(path.basename(depPath))!;
          dependencyGraph.get(file.filePath)!.add(headerPath);
          reverseDependencyGraph.get(headerPath)!.add(file.filePath);
          files.get(headerPath)!.importedBy.push(file.filePath);
        }
      }

      if (verbose && processedCount % 20 === 0) {
        console.log(chalk.gray(`   Processed ${processedCount}/${objcSources.length} files...`));
      }
    }

    console.log(chalk.gray(`   Analyzed ${processedCount} ObjC/C++ files with clang`));
  }

  // Always use regex-based resolution for Swift files and as fallback
  for (const [filePath, file] of files) {
    // Skip ObjC files if we already processed them with clang
    if (useClangAnalysis && (file.language === 'objc' || file.language === 'cpp')) {
      continue;
    }

    for (const imp of file.imports) {
      if (imp.isExternal) continue;

      // Try to resolve the import to a file
      let resolvedPath: string | undefined;

      if (imp.headerName) {
        // Try direct header name
        resolvedPath = headerMap.get(imp.headerName);

        // Try with module prefix path
        if (!resolvedPath && imp.moduleName) {
          const withModule = `${imp.moduleName}/${imp.headerName}`;
          resolvedPath = headerMap.get(withModule);
        }

        // Try finding by basename
        if (!resolvedPath) {
          const basename = path.basename(imp.headerName);
          resolvedPath = headerMap.get(basename);
        }
      }

      if (resolvedPath && files.has(resolvedPath)) {
        dependencyGraph.get(filePath)!.add(resolvedPath);
        reverseDependencyGraph.get(resolvedPath)!.add(filePath);
        files.get(resolvedPath)!.importedBy.push(filePath);
      }
    }
  }

  // Count edges
  let edgeCount = 0;
  for (const deps of dependencyGraph.values()) {
    edgeCount += deps.size;
  }
  console.log(`   Built graph with ${chalk.green(edgeCount)} edges`);

  // Step 5: Detect cycles
  console.log(chalk.blue('\n🔄 Step 5: Detecting cycles...'));
  const cycles = detectCycles(dependencyGraph);
  if (cycles.length > 0) {
    console.log(chalk.yellow(`   Found ${cycles.length} potential cycles`));
  } else {
    console.log(chalk.green('   No cycles detected'));
  }

  // Step 6: Suggest targets
  console.log(chalk.blue('\n🎯 Step 6: Suggesting target groupings...'));
  const suggestedTargets = suggestTargets(files, sourceRoot);
  console.log(`   Suggested ${chalk.green(suggestedTargets.length)} targets`);

  // Step 7: Split mixed-language targets
  console.log(chalk.blue('\n🔀 Step 7: Splitting mixed-language targets...'));
  const splitTargets = splitTargetsAndAnalyzeDependencies(
    suggestedTargets,
    files,
    headerMap,
    dependencyGraph,
    sourceRoot
  );
  const mixedCount = splitTargets.filter((t) => t.wasSplit).length;
  console.log(`   Created ${chalk.green(splitTargets.length)} split targets`);
  if (mixedCount > 0) {
    console.log(`   (${chalk.yellow(mixedCount / 2)} mixed-language targets were split)`);
  }

  // Step 8: Detect cycles in split targets and suggest bridging targets
  console.log(chalk.blue('\n🔄 Step 8: Analyzing target cycles...'));
  const targetCycles = detectSplitTargetCycles(splitTargets);
  let bridgingSuggestions: BridgingSuggestion[] = [];

  if (targetCycles.length > 0) {
    console.log(chalk.yellow(`   Found ${targetCycles.length} cyclic dependencies`));
    const suggestions = suggestBridgingTargets(
      targetCycles,
      splitTargets,
      files,
      headerMap,
      sourceRoot
    );
    bridgingSuggestions = suggestions.map((s) => ({
      name: s.name,
      cycle: s.cycle,
      headers: s.headers,
      reason: s.reason,
    }));
    if (bridgingSuggestions.length > 0) {
      console.log(
        `   Generated ${chalk.green(bridgingSuggestions.length)} bridging target suggestion(s)`
      );
    }
  } else {
    console.log(chalk.green('   No cyclic dependencies'));
  }

  // Step 9: Analyze Swift usage in ObjC files
  console.log(chalk.blue('\n🔍 Step 9: Analyzing Swift usage in ObjC files...'));
  const swiftUsageAnalysis = analyzeSwiftUsage(files, sourceRoot);
  if (swiftUsageAnalysis.totalFilesImportingSwift > 0) {
    console.log(
      chalk.yellow(
        `   Found ${swiftUsageAnalysis.totalFilesImportingSwift} ObjC files importing Swift.h`
      )
    );
    console.log(`   Total Swift types used: ${chalk.cyan(swiftUsageAnalysis.allSwiftTypes.size)}`);
    console.log(
      `   Recommended approach: ${chalk.green(swiftUsageAnalysis.recommendation.approach)} (${swiftUsageAnalysis.recommendation.effort} effort, ${swiftUsageAnalysis.recommendation.risk} risk)`
    );
  } else {
    console.log(chalk.green('   No ObjC files import Swift.h'));
  }

  // Step 10: Suggest Swift bridging targets for Swift/ObjC cycles
  console.log(
    chalk.blue('\n🔀 Step 10: Analyzing Swift/ObjC interop for base target extraction...')
  );
  let swiftBridgingSuggestions: SwiftBridgingSuggestion[] = [];

  if (swiftUsageAnalysis.totalFilesImportingSwift > 0) {
    swiftBridgingSuggestions = suggestSwiftBridgingTargets(
      swiftUsageAnalysis,
      splitTargets,
      files,
      headerMap,
      dependencyGraph,
      sourceRoot
    );

    if (swiftBridgingSuggestions.length > 0) {
      console.log(
        chalk.green(
          `   Generated ${swiftBridgingSuggestions.length} Swift base target suggestion(s)`
        )
      );
      for (const suggestion of swiftBridgingSuggestions) {
        console.log(chalk.cyan(`   📦 ${suggestion.name}`));
        console.log(
          chalk.gray(
            `      ${suggestion.swiftFiles.length} Swift file(s), ${suggestion.exposedTypes.length} type(s)`
          )
        );
      }
    } else {
      console.log(
        chalk.yellow('   No extractable Swift base targets found (Swift files depend on ObjC)')
      );
    }
  } else {
    console.log(chalk.green('   No Swift/ObjC interop detected'));
  }

  return {
    files,
    headers: headerMap,
    dependencyGraph,
    reverseDependencyGraph,
    cycles,
    suggestedTargets,
    splitTargets,
    bridgingSuggestions,
    swiftBridgingSuggestions,
    swiftUsageAnalysis,
    sourceRoot,
  };
}

// ============================================================================
// Reporting Functions
// ============================================================================

/**
 * Prints a summary of the analysis results
 */
export function printAnalysisSummary(result: AnalysisResult): void {
  console.log(chalk.blue('\n' + '='.repeat(60)));
  console.log(chalk.blue.bold('📊 Analysis Summary'));
  console.log(chalk.blue('='.repeat(60)));

  // File statistics
  let swiftCount = 0;
  let objcCount = 0;
  let cppCount = 0;
  let headerCount = 0;

  for (const file of result.files.values()) {
    switch (file.language) {
      case 'swift':
        swiftCount++;
        break;
      case 'objc':
        objcCount++;
        break;
      case 'cpp':
        cppCount++;
        break;
      case 'header':
        headerCount++;
        break;
    }
  }

  console.log(chalk.white('\n📁 File Breakdown:'));
  console.log(`   Swift files:       ${chalk.cyan(swiftCount)}`);
  console.log(`   Objective-C files: ${chalk.cyan(objcCount)}`);
  console.log(`   C++ files:         ${chalk.cyan(cppCount)}`);
  console.log(`   Header files:      ${chalk.cyan(headerCount)}`);

  // Target suggestions
  console.log(chalk.white('\n🎯 Suggested Targets:'));
  for (const target of result.suggestedTargets) {
    const langs = Array.from(target.languages).join(', ');
    console.log(`\n   ${chalk.yellow(target.name)} (${langs})`);
    console.log(`      Files: ${target.files.length}`);
    if (target.dependencies.length > 0) {
      console.log(`      Depends on: ${target.dependencies.join(', ')}`);
    }
  }

  // Split targets (SPM-compatible)
  console.log(chalk.white('\n🔀 Split Targets (SPM-compatible):'));
  for (const target of result.splitTargets) {
    const splitIndicator = target.wasSplit ? chalk.magenta(' [split]') : '';
    const langColor = target.language === 'swift' ? chalk.cyan : chalk.yellow;
    console.log(`\n   ${langColor(target.name)}${splitIndicator}`);
    console.log(`      Language: ${target.language}`);
    console.log(`      Source files: ${target.sourceFiles.length}`);
    if (target.headerFiles.length > 0) {
      console.log(`      Header files: ${target.headerFiles.length}`);
    }
    if (target.dependencies.length > 0) {
      console.log(`      ${chalk.white('Dependencies:')} ${target.dependencies.join(', ')}`);
    }
    if (target.externalDependencies.length > 0) {
      console.log(
        `      ${chalk.gray('External deps:')} ${target.externalDependencies.join(', ')}`
      );
    }
    if (target.linkedFrameworks.length > 0) {
      console.log(
        `      ${chalk.blue('Linked frameworks:')} ${target.linkedFrameworks.join(', ')}`
      );
    }
  }

  // Check for potential circular dependencies between split targets
  const circularDeps: string[] = [];
  for (const target of result.splitTargets) {
    for (const dep of target.dependencies) {
      const depTarget = result.splitTargets.find((t) => t.name === dep);
      if (depTarget && depTarget.dependencies.includes(target.name)) {
        const pair = [target.name, dep].sort().join(' <-> ');
        if (!circularDeps.includes(pair)) {
          circularDeps.push(pair);
        }
      }
    }
  }

  if (circularDeps.length > 0) {
    console.log(chalk.red('\n⚠️  Circular Dependencies Between Split Targets:'));
    for (const pair of circularDeps) {
      console.log(`   ${chalk.red('•')} ${pair}`);
    }
  }

  // Show bridging suggestions if we have cycles
  if (result.bridgingSuggestions && result.bridgingSuggestions.length > 0) {
    console.log(chalk.green('\n💡 Suggested Bridging Targets to Break Cycles:'));
    for (const suggestion of result.bridgingSuggestions) {
      console.log(chalk.cyan(`\n   📦 ${suggestion.name}`));
      console.log(chalk.gray(`      Breaks cycle: ${suggestion.cycle.join(' → ')}`));
      console.log(chalk.gray(`      Reason: ${suggestion.reason}`));
      console.log(chalk.white('      Headers to extract:'));
      for (const header of suggestion.headers) {
        console.log(chalk.white(`         • ${header}`));
      }
    }
  }

  // Show Swift bridging suggestions for Swift/ObjC interop
  if (result.swiftBridgingSuggestions && result.swiftBridgingSuggestions.length > 0) {
    console.log(chalk.green('\n💡 Suggested Swift Base Targets for ObjC Interop:'));
    for (const suggestion of result.swiftBridgingSuggestions) {
      console.log(chalk.cyan(`\n   📦 ${suggestion.name}`));
      console.log(chalk.gray(`      From: ${suggestion.sourceTarget}`));
      console.log(
        chalk.gray(`      ObjC targets needing this: ${suggestion.objcTargets.join(', ')}`)
      );
      console.log(chalk.gray(`      Reason: ${suggestion.reason}`));
      console.log(chalk.white('      Swift files to extract:'));
      for (const file of suggestion.swiftFiles.slice(0, 5)) {
        console.log(chalk.white(`         • ${file}`));
      }
      if (suggestion.swiftFiles.length > 5) {
        console.log(chalk.gray(`         ... and ${suggestion.swiftFiles.length - 5} more`));
      }
      console.log(chalk.white('      Exposes types:'));
      for (const typeName of suggestion.exposedTypes.slice(0, 5)) {
        console.log(chalk.white(`         • ${typeName}`));
      }
      if (suggestion.exposedTypes.length > 5) {
        console.log(chalk.gray(`         ... and ${suggestion.exposedTypes.length - 5} more`));
      }
    }
  }

  // Cycles
  if (result.cycles.length > 0) {
    console.log(chalk.red('\n⚠️  Detected Cycles:'));
    for (const cycle of result.cycles.slice(0, 10)) {
      // Show first 10
      const shortCycle = cycle.map((f) => path.basename(f)).join(' → ');
      console.log(`   ${chalk.red('•')} ${shortCycle}`);
    }
    if (result.cycles.length > 10) {
      console.log(chalk.gray(`   ... and ${result.cycles.length - 10} more`));
    }
  }

  console.log(chalk.blue('\n' + '='.repeat(60) + '\n'));
}

/**
 * Prints detailed Swift usage analysis
 */
export function printSwiftUsageAnalysis(analysis: SwiftUsageAnalysis): void {
  console.log(chalk.blue('\n' + '='.repeat(60)));
  console.log(chalk.blue.bold('🔍 Swift Usage Analysis'));
  console.log(chalk.blue('='.repeat(60)));

  if (analysis.totalFilesImportingSwift === 0) {
    console.log(chalk.green('\n✓ No ObjC files import Swift.h'));
    console.log(chalk.gray('  This is ideal for SPM target splitting.\n'));
    return;
  }

  // Summary
  console.log(chalk.white('\n📊 Summary:'));
  console.log(`   Files importing Swift.h: ${chalk.yellow(analysis.totalFilesImportingSwift)}`);
  console.log(`   Unique Swift types used:  ${chalk.cyan(analysis.allSwiftTypes.size)}`);

  const totalUsages = analysis.filesImportingSwiftHeader.reduce(
    (sum, file) => sum + file.totalUsages,
    0
  );
  console.log(`   Total Swift references:   ${chalk.cyan(totalUsages)}`);

  // List all Swift types found
  if (analysis.allSwiftTypes.size > 0) {
    console.log(chalk.white('\n🎯 Swift Types Referenced:'));
    const sortedTypes = Array.from(analysis.allSwiftTypes).sort();
    sortedTypes.forEach((type) => {
      console.log(`   ${chalk.cyan('•')} ${type}`);
    });
  }

  // Detailed file analysis
  console.log(chalk.white('\n📄 Files Importing Swift.h:'));
  for (const fileInfo of analysis.filesImportingSwiftHeader) {
    console.log(chalk.yellow(`\n   ${fileInfo.relativePath}`));

    if (fileInfo.swiftTypes.length === 0) {
      console.log(chalk.gray('      No specific Swift type usage detected'));
      continue;
    }

    console.log(`      Total usages: ${chalk.cyan(fileInfo.totalUsages)}`);

    // Group by usage type
    const byUsageType = new Map<string, SwiftTypeUsage[]>();
    for (const usage of fileInfo.swiftTypes) {
      if (!byUsageType.has(usage.usageType)) {
        byUsageType.set(usage.usageType, []);
      }
      byUsageType.get(usage.usageType)!.push(usage);
    }

    // Print grouped by usage type
    for (const [usageType, usages] of byUsageType) {
      const icon = getUsageTypeIcon(usageType);
      console.log(chalk.white(`      ${icon} ${usageType}:`));
      for (const usage of usages) {
        const methods =
          usage.methodsCalled.length > 0
            ? chalk.gray(` (calls: ${usage.methodsCalled.join(', ')})`)
            : '';
        const lines = chalk.gray(`[lines: ${usage.lineNumbers.join(', ')}]`);
        console.log(`         • ${chalk.cyan(usage.typeName)}${methods} ${lines}`);
      }
    }
  }

  // Recommendation
  console.log(chalk.white('\n💡 Recommendation:'));
  const { approach, reason, effort, risk } = analysis.recommendation;

  const effortColor =
    effort === 'low' ? chalk.green : effort === 'medium' ? chalk.yellow : chalk.red;
  const riskColor = risk === 'low' ? chalk.green : risk === 'medium' ? chalk.yellow : chalk.red;

  console.log(chalk.green(`\n   Approach: ${chalk.bold(approach)}`));
  console.log(chalk.white(`   Reason:   ${reason}`));
  console.log(`   Effort:   ${effortColor(effort)}`);
  console.log(`   Risk:     ${riskColor(risk)}`);

  // Strategy-specific guidance
  console.log(chalk.white('\n📋 Next Steps:'));
  switch (approach) {
    case 'runtime-lookups':
      console.log(chalk.white('   1. Replace Swift.h imports with runtime class lookups'));
      console.log(chalk.white('   2. Use NSClassFromString() for type references'));
      console.log(chalk.white('   3. Define ObjC protocols for Swift types'));
      console.log(chalk.white('   4. Use performSelector: for method calls'));
      console.log(chalk.gray('   Example: Class cls = NSClassFromString(@"EXAppContext");'));
      break;

    case 'convert-to-swift':
      console.log(chalk.white('   1. Check if .mm files have C++ dependencies'));
      console.log(chalk.white('   2. Rewrite identified ObjC files in Swift'));
      console.log(chalk.white('   3. Update call sites to use Swift types'));
      console.log(chalk.white('   4. Test thoroughly for behavioral changes'));
      break;

    case 'layered-architecture':
      console.log(chalk.white('   1. Identify ObjC code that can move to Base layer'));
      console.log(chalk.white('   2. Create architecture layers:'));
      console.log(chalk.white('      - Base_objc (no Swift dependencies)'));
      console.log(chalk.white('      - Core_swift (depends on Base_objc)'));
      console.log(chalk.white('      - Top_objc (minimal ObjC that needs Swift)'));
      console.log(chalk.white('   3. Refactor dependencies to follow layer rules'));
      break;

    case 'unified-target':
      console.log(chalk.white('   1. Use single unified target for SPM'));
      console.log(chalk.white('   2. Configure spm.config.json with all files'));
      console.log(chalk.white('   3. Consider refactoring later for better modularity'));
      break;
  }

  console.log(chalk.blue('\n' + '='.repeat(60) + '\n'));
}

/**
 * Gets an icon for a usage type
 */
function getUsageTypeIcon(usageType: string): string {
  switch (usageType) {
    case 'instantiation':
      return '🏗️ ';
    case 'property':
      return '📦';
    case 'method-call':
      return '🔧';
    case 'type-reference':
      return '🔗';
    case 'cast':
      return '🔀';
    default:
      return '•';
  }
}

/**
 * Prints detailed dependency information for a specific file
 */
export function printFileDependencies(result: AnalysisResult, filePath: string): void {
  const file = result.files.get(filePath);
  if (!file) {
    console.log(chalk.red(`File not found: ${filePath}`));
    return;
  }

  console.log(chalk.blue(`\n📄 ${file.relativePath}`));
  console.log(`   Language: ${file.language}`);

  console.log(chalk.white('\n   Imports:'));
  for (const imp of file.imports) {
    const prefix = imp.isExternal ? chalk.gray('(external)') : '';
    console.log(`      ${imp.type}: ${imp.raw} ${prefix}`);
  }

  const deps = result.dependencyGraph.get(filePath);
  if (deps && deps.size > 0) {
    console.log(chalk.white('\n   Depends on:'));
    for (const dep of deps) {
      const relPath = path.relative(path.dirname(filePath), dep);
      console.log(`      → ${relPath}`);
    }
  }

  const reverseDeps = result.reverseDependencyGraph.get(filePath);
  if (reverseDeps && reverseDeps.size > 0) {
    console.log(chalk.white('\n   Used by:'));
    for (const dep of reverseDeps) {
      const relPath = path.relative(path.dirname(filePath), dep);
      console.log(`      ← ${relPath}`);
    }
  }
}

/**
 * Exports the dependency graph in DOT format for visualization
 */
export function exportDotGraph(result: AnalysisResult, outputPath: string): void {
  const lines: string[] = ['digraph dependencies {', '  rankdir=LR;', '  node [shape=box];'];

  // Create node IDs
  const nodeIds = new Map<string, string>();
  let nodeCounter = 0;
  for (const filePath of result.files.keys()) {
    const id = `n${nodeCounter++}`;
    nodeIds.set(filePath, id);
    const label = path.basename(filePath);
    lines.push(`  ${id} [label="${label}"];`);
  }

  // Add edges
  for (const [from, deps] of result.dependencyGraph) {
    const fromId = nodeIds.get(from);
    for (const to of deps) {
      const toId = nodeIds.get(to);
      if (fromId && toId) {
        lines.push(`  ${fromId} -> ${toId};`);
      }
    }
  }

  lines.push('}');

  fs.writeFileSync(outputPath, lines.join('\n'));
  console.log(chalk.green(`\n✅ DOT graph exported to: ${outputPath}`));
}

/**
 * Exports analysis results to JSON
 */
export async function exportAnalysisJson(
  result: AnalysisResult,
  outputPath: string
): Promise<void> {
  const exportData = {
    files: Array.from(result.files.values()).map((f) => ({
      path: f.relativePath,
      name: f.name,
      language: f.language,
      imports: f.imports,
      importedByCount: f.importedBy.length,
    })),
    cycles: result.cycles.map((c) =>
      c.map((f) => {
        const file = result.files.get(f);
        return file?.relativePath || f;
      })
    ),
    suggestedTargets: result.suggestedTargets.map((t) => ({
      name: t.name,
      fileCount: t.files.length,
      files: t.files.map((f) => f.relativePath),
      dependencies: t.dependencies,
      languages: Array.from(t.languages),
    })),
    splitTargets: result.splitTargets.map((t) => ({
      name: t.name,
      originalName: t.originalName,
      language: t.language,
      wasSplit: t.wasSplit,
      sourceFiles: t.sourceFiles,
      headerFiles: t.headerFiles,
      dependencies: t.dependencies,
      externalDependencies: t.externalDependencies,
    })),
    statistics: {
      totalFiles: result.files.size,
      totalHeaders: result.headers.size,
      totalCycles: result.cycles.length,
      suggestedTargetCount: result.suggestedTargets.length,
      splitTargetCount: result.splitTargets.length,
      mixedTargetsCount: result.splitTargets.filter((t) => t.wasSplit).length / 2,
    },
  };

  await fs.writeJson(outputPath, exportData, { spaces: 2 });
  console.log(chalk.green(`\n✅ Analysis exported to: ${outputPath}`));
}

/**
 * SPM Config Types (matching spm.config.schema.json)
 * Note: Targets are now at root level, products reference targets by name
 */
interface SpmConfigTarget {
  type: 'objc' | 'swift' | 'cpp' | 'framework';
  name: string;
  path: string;
  pattern?: string;
  headerPattern?: string;
  dependencies?: string[];
  exclude?: string[];
  includeDirectories?: string[];
  useIncludesFrom?: string[];
  linkedFrameworks?: string[];
  plugins?: string[];
}

interface SpmConfigProduct {
  name: string;
  /** List of target names (references targets by name from the root targets array) */
  targets: string[];
}

interface SpmConfig {
  $schema: string;
  platforms: string[];
  /** List of external Swift Package dependencies (moved from product level) */
  externalDependencies?: string[];
  /** Flat list of all targets with their dependencies */
  targets: SpmConfigTarget[];
  /** Products reference targets by name */
  products: SpmConfigProduct[];
}

/**
 * Exports analysis results as spm.config.json compatible format
 * If autoBridge is true, automatically creates bridging targets to break cycles
 * Otherwise throws an error if cyclic dependencies are detected
 */
export async function exportSpmConfig(
  result: AnalysisResult,
  outputPath: string,
  sourceRoot: string,
  externalDeps?: string[],
  autoBridge: boolean = false,
  consolidateSwift: boolean = false,
  splitTargetsOverride?: SplitTarget[],
  productDefinitions?: ProductDefinition[],
  mergeSwift: boolean = false,
  excludeFromPrebuild?: string[],
  mergeHeaderTargets: boolean = false,
  mergeObjc: boolean = false
): Promise<void> {
  // Check for cyclic dependencies in split targets
  const initialSplitTargets = splitTargetsOverride ?? result.splitTargets;
  const cycles = detectSplitTargetCycles(initialSplitTargets);

  // Determine the path prefix (the directory name being analyzed, e.g., "ios")
  const pathPrefix = path.basename(sourceRoot);

  // Use provided external deps, or empty array
  const productExternalDeps = externalDeps && externalDeps.length > 0 ? externalDeps : [];

  // If we have cycles and autoBridge is enabled, create bridging targets
  let splitTargetsToUse = initialSplitTargets;
  const bridgingTargets: SplitTarget[] = [];

  if (cycles.length > 0) {
    if (autoBridge && result.bridgingSuggestions && result.bridgingSuggestions.length > 0) {
      console.log(
        chalk.yellow('\n⚠️  Cyclic dependencies detected - auto-generating bridging targets...\n')
      );

      for (const suggestion of result.bridgingSuggestions) {
        console.log(chalk.cyan(`   Creating bridging target: ${suggestion.name}`));
        console.log(chalk.gray(`   Headers: ${suggestion.headers.join(', ')}`));

        // Create the bridging target
        const bridgingTarget: SplitTarget = {
          name: suggestion.name,
          originalName: suggestion.name,
          language: 'objc',
          sourceFiles: [], // Bridging targets are header-only
          headerFiles: suggestion.headers,
          dependencies: [...productExternalDeps],
          externalDependencies: [],
          linkedFrameworks: [],
          wasSplit: false,
        };
        bridgingTargets.push(bridgingTarget);

        // Update the original targets to depend on bridging target instead
        splitTargetsToUse = splitTargetsToUse.map((target) => {
          if (suggestion.cycle.includes(target.name)) {
            const newDeps = target.dependencies.filter((dep) => {
              // Keep dep if it's not the source of extracted headers
              // This is simplified - in reality we'd check more carefully
              return !suggestion.cycle.includes(dep) || dep === target.name;
            });

            // Add bridging target as dependency
            if (!newDeps.includes(suggestion.name)) {
              newDeps.push(suggestion.name);
            }

            return { ...target, dependencies: newDeps };
          }
          return target;
        });
      }

      // Add bridging targets to the list
      splitTargetsToUse = [...bridgingTargets, ...splitTargetsToUse];

      console.log(chalk.green(`\n   Created ${bridgingTargets.length} bridging target(s)\n`));
    } else {
      // No auto-bridge, fail with error
      console.log(chalk.red('\n❌ ERROR: Cyclic dependencies detected in targets!\n'));
      console.log(chalk.red('The following cycles were found:'));
      for (const cycle of cycles) {
        const cycleStr = [...cycle, cycle[0]].join(' → ');
        console.log(chalk.red(`   • ${cycleStr}`));
      }

      if (result.bridgingSuggestions && result.bridgingSuggestions.length > 0) {
        console.log(chalk.green('\n💡 Suggested fix - create bridging targets:'));
        for (const suggestion of result.bridgingSuggestions) {
          console.log(chalk.cyan(`\n   📦 ${suggestion.name}`));
          console.log(chalk.white(`      Headers to extract:`));
          for (const header of suggestion.headers) {
            console.log(chalk.white(`         • ${header}`));
          }
        }
        console.log(
          chalk.yellow('\n   Run with --auto-bridge to automatically create these targets')
        );
      }

      console.log(chalk.yellow('\nOr manually fix by:'));
      console.log(chalk.yellow('   1. Refactoring the code to remove cyclic imports'));
      console.log(chalk.yellow('   2. Creating a bridging target with shared headers'));
      console.log();
      throw new Error(
        `Cyclic dependencies detected: ${cycles.map((c) => c.join(' → ')).join('; ')}`
      );
    }
  }

  // Handle Swift bridging targets for Swift/ObjC interop
  const swiftBridgingTargets: SplitTarget[] = [];
  if (autoBridge && result.swiftBridgingSuggestions && result.swiftBridgingSuggestions.length > 0) {
    console.log(chalk.yellow('\n🔀 Creating Swift base targets for ObjC interop...\n'));

    for (const suggestion of result.swiftBridgingSuggestions) {
      console.log(chalk.cyan(`   Creating Swift base target: ${suggestion.name}`));
      console.log(
        chalk.gray(
          `   Swift files: ${suggestion.swiftFiles.length}, Types: ${suggestion.exposedTypes.join(', ')}`
        )
      );

      // Create the Swift base target
      const swiftBaseTarget: SplitTarget = {
        name: suggestion.name,
        originalName: suggestion.sourceTarget,
        language: 'swift',
        sourceFiles: suggestion.swiftFiles,
        headerFiles: [],
        dependencies: [...productExternalDeps], // Swift base targets typically only have external deps
        externalDependencies: [],
        linkedFrameworks: [],
        wasSplit: true,
      };
      swiftBridgingTargets.push(swiftBaseTarget);

      // Update the source Swift target to exclude extracted files and depend on base
      splitTargetsToUse = splitTargetsToUse.map((target) => {
        if (target.name === suggestion.sourceTarget) {
          // Remove extracted files from source target
          const remainingFiles = target.sourceFiles.filter(
            (f) => !suggestion.swiftFiles.includes(f)
          );
          // Add dependency on the base target
          const newDeps = [...target.dependencies];
          if (!newDeps.includes(suggestion.name)) {
            newDeps.push(suggestion.name);
          }
          return {
            ...target,
            sourceFiles: remainingFiles,
            dependencies: newDeps,
          };
        }

        // Update ObjC targets that use these Swift types to depend on the base target
        if (suggestion.objcTargets.includes(target.name)) {
          const newDeps = [...target.dependencies];
          if (!newDeps.includes(suggestion.name)) {
            newDeps.push(suggestion.name);
          }
          // Remove dependency on the source Swift target if it exists
          // (they now depend on the base target instead)
          return {
            ...target,
            dependencies: newDeps,
          };
        }

        return target;
      });
    }

    // Add Swift bridging targets to the list (at the beginning so they're processed first)
    splitTargetsToUse = [...swiftBridgingTargets, ...splitTargetsToUse];

    console.log(chalk.green(`\n   Created ${swiftBridgingTargets.length} Swift base target(s)\n`));
  } else if (result.swiftBridgingSuggestions && result.swiftBridgingSuggestions.length > 0) {
    // Report suggestions but don't apply them
    console.log(chalk.blue('\n💡 Swift base target suggestions available:'));
    for (const suggestion of result.swiftBridgingSuggestions) {
      console.log(chalk.cyan(`   📦 ${suggestion.name}`));
      console.log(
        chalk.gray(`      Extract ${suggestion.swiftFiles.length} Swift file(s) with types:`)
      );
      for (const typeName of suggestion.exposedTypes.slice(0, 5)) {
        console.log(chalk.gray(`         • ${typeName}`));
      }
      if (suggestion.exposedTypes.length > 5) {
        console.log(chalk.gray(`         ... and ${suggestion.exposedTypes.length - 5} more`));
      }
    }
    console.log(chalk.yellow('   Run with --auto-bridge to automatically create these targets'));
  }

  // Handle Swift consolidation - merge all non-base Swift into a single target
  // This creates a layered architecture:
  //   Swift_base (pure Swift, no ObjC deps) <- ObjC targets <- Swift_main (can use ObjC)
  if (consolidateSwift) {
    console.log(chalk.yellow('\n🔄 Consolidating Swift targets into layered architecture...\n'));

    // Identify Swift base targets (ones that are used by ObjC, already created above)
    const swiftBaseTargetNames = new Set(swiftBridgingTargets.map((t) => t.name));

    // Collect all Swift files from non-base Swift targets
    const swiftMainFiles: string[] = [];
    const swiftTargetsToRemove: string[] = [];

    for (const target of splitTargetsToUse) {
      if (target.language === 'swift' && !swiftBaseTargetNames.has(target.name)) {
        swiftMainFiles.push(...target.sourceFiles);
        swiftTargetsToRemove.push(target.name);
        console.log(chalk.gray(`   Merging ${target.name}: ${target.sourceFiles.length} file(s)`));
      }
    }

    if (swiftMainFiles.length > 0) {
      // Get all ObjC target names (for Swift_main to depend on)
      const objcTargetNames = splitTargetsToUse
        .filter((t) => t.language === 'objc' || t.language === 'cpp')
        .map((t) => t.name);

      // Create the consolidated Swift_main target
      const swiftMainTarget: SplitTarget = {
        name: 'Swift_main',
        originalName: 'Swift_main',
        language: 'swift',
        sourceFiles: swiftMainFiles,
        headerFiles: [],
        dependencies: [...objcTargetNames, ...productExternalDeps],
        externalDependencies: [],
        linkedFrameworks: [],
        wasSplit: false,
      };

      // Remove individual Swift targets and add Swift_main
      splitTargetsToUse = splitTargetsToUse.filter((t) => !swiftTargetsToRemove.includes(t.name));
      splitTargetsToUse.push(swiftMainTarget);

      console.log(
        chalk.green(
          `\n   Created Swift_main with ${swiftMainFiles.length} file(s), depending on ${objcTargetNames.length} ObjC target(s)\n`
        )
      );

      // Update ObjC targets to depend on Swift_base targets (if any)
      if (swiftBaseTargetNames.size > 0) {
        splitTargetsToUse = splitTargetsToUse.map((target) => {
          if (target.language === 'objc' || target.language === 'cpp') {
            const newDeps = [...target.dependencies];
            for (const baseName of swiftBaseTargetNames) {
              if (!newDeps.includes(baseName)) {
                newDeps.push(baseName);
              }
            }
            return { ...target, dependencies: newDeps };
          }
          return target;
        });
      }
    }
  }

  // Handle simple Swift merging - merge ALL Swift files into a single target
  // This is simpler than consolidateSwift and useful for modules with heavy ObjC interop
  // where Swift files use ObjC types through bridging
  if (mergeSwift && !consolidateSwift) {
    console.log(chalk.yellow('\n🔄 Merging all Swift targets into a single target...\n'));

    // Collect all Swift files, linked frameworks, and dependencies from all Swift targets
    const allSwiftFiles: string[] = [];
    const allLinkedFrameworks = new Set<string>();
    const allDependencies = new Set<string>(productExternalDeps);
    const swiftTargetsToRemove: string[] = [];

    for (const target of splitTargetsToUse) {
      if (target.language === 'swift') {
        allSwiftFiles.push(...target.sourceFiles);
        for (const fw of target.linkedFrameworks) {
          allLinkedFrameworks.add(fw);
        }
        // Collect dependencies (skip other Swift targets, they're being merged)
        for (const dep of target.dependencies) {
          allDependencies.add(dep);
        }
        swiftTargetsToRemove.push(target.name);
        console.log(chalk.gray(`   Merging ${target.name}: ${target.sourceFiles.length} file(s)`));
      }
    }

    // Remove Swift target names from dependencies (they're all being merged)
    for (const swiftTarget of swiftTargetsToRemove) {
      allDependencies.delete(swiftTarget);
    }

    // Add only SCCM_* ObjC/C++ targets as dependencies (these are the merged targets with source files)
    // We don't add SCC{N}_* targets because they are header-only and their headers are already
    // included transitively through the SCCM_* targets. Adding them all would create a massive
    // command line that causes the Swift driver to hang.
    const objcTargetNames = splitTargetsToUse
      .filter((t) => (t.language === 'objc' || t.language === 'cpp') && /^SCCM_/.test(t.name))
      .map((t) => t.name);
    for (const objcTarget of objcTargetNames) {
      allDependencies.add(objcTarget);
    }

    if (allSwiftFiles.length > 0) {
      // Create the merged Swift target with all ObjC dependencies
      const mergedSwiftTarget: SplitTarget = {
        name: 'SCCM_swift',
        originalName: 'SCCM_swift',
        language: 'swift',
        sourceFiles: allSwiftFiles,
        headerFiles: [],
        dependencies: Array.from(allDependencies),
        externalDependencies: [],
        linkedFrameworks: Array.from(allLinkedFrameworks),
        wasSplit: false,
      };

      // Remove individual Swift targets and add merged target
      splitTargetsToUse = splitTargetsToUse.filter((t) => !swiftTargetsToRemove.includes(t.name));
      splitTargetsToUse.push(mergedSwiftTarget);

      // Update any targets that depended on the old Swift targets to depend on SCCM_swift
      splitTargetsToUse = splitTargetsToUse.map((target) => {
        if (target.name === 'SCCM_swift') return target;
        const newDeps = target.dependencies
          .filter((dep) => !swiftTargetsToRemove.includes(dep))
          .map((dep) => (swiftTargetsToRemove.includes(dep) ? 'SCCM_swift' : dep));
        // Add SCCM_swift if any of the old deps were Swift targets
        if (
          target.dependencies.some((dep) => swiftTargetsToRemove.includes(dep)) &&
          !newDeps.includes('SCCM_swift')
        ) {
          newDeps.push('SCCM_swift');
        }
        return { ...target, dependencies: [...new Set(newDeps)] };
      });

      console.log(
        chalk.green(
          `\n   Created SCCM_swift with ${allSwiftFiles.length} file(s), ${allLinkedFrameworks.size} framework(s), and ${allDependencies.size} dependencies\n`
        )
      );
    }
  }

  // Handle ObjC merging - merge ALL ObjC files into a single SCCM_objc target
  // This is similar to --merge-swift and helps avoid cross-module header issues
  // where headers use #import <ProductName/Header.h> syntax
  if (mergeObjc) {
    console.log(chalk.yellow('\n🔄 Merging all ObjC targets into a single target...\n'));

    // Collect all ObjC files, headers, linked frameworks, and dependencies from all ObjC targets
    const allObjcSourceFiles: string[] = [];
    const allObjcHeaderFiles: string[] = [];
    const allObjcLinkedFrameworks = new Set<string>();
    const allObjcDependencies = new Set<string>(productExternalDeps);
    const objcTargetsToRemove: string[] = [];

    for (const target of splitTargetsToUse) {
      // Include ObjC targets and also header-only "cpp" targets that have .h files
      // (header-only targets get language='cpp' because they have no source files)
      const isObjcTarget = target.language === 'objc';
      const isHeaderOnlyObjcTarget =
        target.language === 'cpp' &&
        target.sourceFiles.length === 0 &&
        target.headerFiles.length > 0 &&
        target.headerFiles.every((h) => h.endsWith('.h'));

      if (isObjcTarget || isHeaderOnlyObjcTarget) {
        allObjcSourceFiles.push(...target.sourceFiles);
        allObjcHeaderFiles.push(...target.headerFiles);
        for (const fw of target.linkedFrameworks) {
          allObjcLinkedFrameworks.add(fw);
        }
        // Collect dependencies (skip other ObjC targets, they're being merged)
        for (const dep of target.dependencies) {
          allObjcDependencies.add(dep);
        }
        objcTargetsToRemove.push(target.name);
        console.log(
          chalk.gray(
            `   Merging ${target.name}: ${target.sourceFiles.length} file(s), ${target.headerFiles.length} header(s)`
          )
        );
      }
    }

    // Remove ObjC target names from dependencies (they're all being merged)
    for (const objcTarget of objcTargetsToRemove) {
      allObjcDependencies.delete(objcTarget);
    }

    // Add C++ targets as dependencies (they're separate)
    const cppTargetNames = splitTargetsToUse.filter((t) => t.language === 'cpp').map((t) => t.name);
    for (const cppTarget of cppTargetNames) {
      allObjcDependencies.add(cppTarget);
    }

    if (allObjcSourceFiles.length > 0 || allObjcHeaderFiles.length > 0) {
      // Create the merged ObjC target
      const mergedObjcTarget: SplitTarget = {
        name: 'SCCM_objc',
        originalName: 'SCCM_objc',
        language: 'objc',
        sourceFiles: allObjcSourceFiles,
        headerFiles: allObjcHeaderFiles,
        dependencies: Array.from(allObjcDependencies),
        externalDependencies: [],
        linkedFrameworks: Array.from(allObjcLinkedFrameworks),
        wasSplit: false,
      };

      // Remove individual ObjC targets and add merged target
      splitTargetsToUse = splitTargetsToUse.filter((t) => !objcTargetsToRemove.includes(t.name));
      splitTargetsToUse.push(mergedObjcTarget);

      // Update any targets that depended on the old ObjC targets to depend on SCCM_objc
      splitTargetsToUse = splitTargetsToUse.map((target) => {
        if (target.name === 'SCCM_objc') return target;
        const newDeps = target.dependencies
          .filter((dep) => !objcTargetsToRemove.includes(dep))
          .map((dep) => (objcTargetsToRemove.includes(dep) ? 'SCCM_objc' : dep));
        // Add SCCM_objc if any of the old deps were ObjC targets
        if (
          target.dependencies.some((dep) => objcTargetsToRemove.includes(dep)) &&
          !newDeps.includes('SCCM_objc')
        ) {
          newDeps.push('SCCM_objc');
        }
        return { ...target, dependencies: [...new Set(newDeps)] };
      });

      console.log(
        chalk.green(
          `\n   Created SCCM_objc with ${allObjcSourceFiles.length} source file(s), ${allObjcHeaderFiles.length} header(s), ${allObjcLinkedFrameworks.size} framework(s), and ${allObjcDependencies.size} dependencies\n`
        )
      );
    }
  }

  // Handle header-only target merging - fold headers from header-only SCC{N}_objc targets
  // INTO their dependent SCCM_* targets. This keeps headers with targets that have the correct
  // dependencies, avoiding cross-module include issues.
  // This significantly reduces the number of targets SPM has to process.
  if (mergeHeaderTargets) {
    console.log(
      chalk.yellow('\n🔄 Folding header-only targets into their dependent SCCM targets...\n')
    );

    // Find all header-only targets (SCC{N}_objc targets with only headers, no source files)
    const headerOnlyTargets: SplitTarget[] = [];
    const headerOnlyTargetNames = new Set<string>();

    for (const target of splitTargetsToUse) {
      // Match SCC{N}_objc targets that only have headers
      if (
        /^SCC\d+_objc$/.test(target.name) &&
        target.sourceFiles.length === 0 &&
        target.headerFiles.length > 0
      ) {
        headerOnlyTargets.push(target);
        headerOnlyTargetNames.add(target.name);
      }
    }

    if (headerOnlyTargets.length > 0) {
      // For each SCCM_* target that depends on header-only targets,
      // fold those headers into the SCCM target and remove the dependency
      let foldedCount = 0;

      splitTargetsToUse = splitTargetsToUse.map((target) => {
        // Skip header-only targets (they'll be removed)
        if (headerOnlyTargetNames.has(target.name)) return target;

        // Find header-only dependencies
        const headerOnlyDeps = target.dependencies.filter((dep) => headerOnlyTargetNames.has(dep));
        if (headerOnlyDeps.length === 0) return target;

        // Collect headers from all header-only dependencies
        const additionalHeaders: string[] = [];
        const additionalDeps = new Set<string>();

        for (const depName of headerOnlyDeps) {
          const headerOnlyTarget = headerOnlyTargets.find((t) => t.name === depName);
          if (headerOnlyTarget) {
            additionalHeaders.push(...headerOnlyTarget.headerFiles);
            // Also add the header-only target's dependencies (except other header-only targets)
            for (const transitiveDep of headerOnlyTarget.dependencies) {
              if (!headerOnlyTargetNames.has(transitiveDep)) {
                additionalDeps.add(transitiveDep);
              }
            }
          }
        }

        // Remove header-only deps and add transitive deps
        const newDeps = target.dependencies.filter((dep) => !headerOnlyTargetNames.has(dep));
        for (const dep of additionalDeps) {
          if (!newDeps.includes(dep)) {
            newDeps.push(dep);
          }
        }

        console.log(
          chalk.gray(
            `   Folding ${additionalHeaders.length} header(s) from ${headerOnlyDeps.length} target(s) into ${target.name}`
          )
        );
        foldedCount += headerOnlyDeps.length;

        return {
          ...target,
          headerFiles: [...target.headerFiles, ...additionalHeaders],
          dependencies: newDeps,
        };
      });

      // Remove the header-only targets
      splitTargetsToUse = splitTargetsToUse.filter((t) => !headerOnlyTargetNames.has(t.name));

      console.log(
        chalk.green(
          `\n   Removed ${headerOnlyTargets.length} header-only targets by folding into SCCM targets\n`
        )
      );
    }
  }

  // Build the targets array, filtering out invalid targets
  const targets: SpmConfigTarget[] = splitTargetsToUse
    .filter((splitTarget) => {
      // Skip targets with invalid names (like "." or empty)
      if (!splitTarget.name || splitTarget.name === '.' || splitTarget.name.trim() === '') {
        return false;
      }
      // Skip targets with no files (except bridging targets which are header-only or Swift base targets)
      const isBridgingTarget = bridgingTargets.some((bt) => bt.name === splitTarget.name);
      const isSwiftBridgingTarget = swiftBridgingTargets.some((bt) => bt.name === splitTarget.name);
      if (
        !isBridgingTarget &&
        !isSwiftBridgingTarget &&
        splitTarget.sourceFiles.length === 0 &&
        splitTarget.headerFiles.length === 0
      ) {
        return false;
      }
      return true;
    })
    .map((splitTarget) => {
      // Check if this is a bridging target (ObjC headers) or Swift base target
      const isBridgingTarget = bridgingTargets.some((bt) => bt.name === splitTarget.name);
      const isSwiftBridgingTarget = swiftBridgingTargets.some((bt) => bt.name === splitTarget.name);

      // Determine the target type
      const type =
        splitTarget.language === 'swift'
          ? 'swift'
          : splitTarget.language === 'cpp'
            ? 'cpp'
            : 'objc';

      // For bridging targets, create special pattern-based config
      if (isBridgingTarget && splitTarget.headerFiles.length > 0) {
        // Find the common base path for headers
        const commonPath = findCommonPath(splitTarget.headerFiles);
        // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
        const effectivePathPrefix = splitTarget.sourceRootName || pathPrefix;
        const targetPath = path.join(effectivePathPrefix, commonPath || '.');

        // Create glob patterns for the specific headers
        // Group headers by their relative path from common base
        const headerBasenames = splitTarget.headerFiles.map((h) => {
          const relFromCommon = commonPath ? path.relative(commonPath, h) : h;
          return relFromCommon;
        });

        // Create a pattern that matches only these specific headers
        // Use brace expansion if multiple files: {file1,file2,file3}.h
        const headerNames = headerBasenames.map((h) => path.basename(h, '.h'));
        const headerPattern =
          headerNames.length === 1 ? `**/${headerNames[0]}.h` : `**/{${headerNames.join(',')}}.h`;

        // Filter dependencies
        const validTargetNames = new Set(
          splitTargetsToUse
            .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
            .map((t) => t.name)
        );
        const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
        // Include cross-product dependencies (e.g., JSI from ExpoModulesJSI)
        // Filter out system modules and invalid dependency names
        const crossProductDeps = splitTarget.externalDependencies.filter(
          (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
        );
        const allDeps = [...internalDeps, ...crossProductDeps, ...productExternalDeps];

        const target: SpmConfigTarget = {
          type: 'objc',
          name: splitTarget.name,
          path: targetPath,
          headerPattern,
          // Bridging targets are header-only, so no source pattern needed
          pattern: '!*.m', // Exclude all source files - only headers
        };

        if (allDeps.length > 0) {
          target.dependencies = allDeps;
        }

        if (splitTarget.linkedFrameworks.length > 0) {
          target.linkedFrameworks = splitTarget.linkedFrameworks;
        }

        target.includeDirectories = ['.'];

        return target;
      }

      // For Swift base targets, create pattern-based config for specific Swift files
      if (isSwiftBridgingTarget && splitTarget.sourceFiles.length > 0) {
        // Find the common base path for Swift files
        const commonPath = findCommonPath(splitTarget.sourceFiles);
        // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
        const effectivePathPrefix = splitTarget.sourceRootName || pathPrefix;
        const targetPath = path.join(effectivePathPrefix, commonPath || '.');

        // Create glob patterns for the specific Swift files
        const swiftFileBasenames = splitTarget.sourceFiles.map((f) => {
          const relFromCommon = commonPath ? path.relative(commonPath, f) : f;
          return relFromCommon;
        });

        // Create a pattern that matches only these specific Swift files
        const swiftNames = swiftFileBasenames.map((f) => path.basename(f, '.swift'));
        const swiftPattern =
          swiftNames.length === 1
            ? `**/${swiftNames[0]}.swift`
            : `**/{${swiftNames.join(',')}}.swift`;

        // Filter dependencies
        const validTargetNames = new Set(
          splitTargetsToUse
            .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
            .map((t) => t.name)
        );
        const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
        // Include cross-product dependencies (e.g., JSI from ExpoModulesJSI)
        // Filter out system modules and invalid dependency names
        const crossProductDeps = splitTarget.externalDependencies.filter(
          (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
        );
        const allDeps = [...internalDeps, ...crossProductDeps, ...productExternalDeps];

        const target: SpmConfigTarget = {
          type: 'swift',
          name: splitTarget.name,
          path: targetPath,
          pattern: swiftPattern,
        };

        if (allDeps.length > 0) {
          target.dependencies = allDeps;
        }

        if (splitTarget.linkedFrameworks.length > 0) {
          target.linkedFrameworks = splitTarget.linkedFrameworks;
        }

        return target;
      }

      // For consolidated Swift_main target, include files from multiple directories
      const isSwiftMainTarget = splitTarget.name === 'Swift_main' && consolidateSwift;
      if (isSwiftMainTarget && splitTarget.sourceFiles.length > 0) {
        // Filter dependencies
        const validTargetNames = new Set(
          splitTargetsToUse
            .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
            .map((t) => t.name)
        );
        const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
        // Include cross-product dependencies (e.g., JSI from ExpoModulesJSI)
        // Filter out system modules and invalid dependency names
        const crossProductDeps = splitTarget.externalDependencies.filter(
          (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
        );
        const allDeps = [...internalDeps, ...crossProductDeps, ...productExternalDeps];

        // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
        const effectivePathPrefix = splitTarget.sourceRootName || pathPrefix;

        // Swift_main can span multiple directories; use an explicit glob pattern from the file list.
        const target: SpmConfigTarget = {
          type: 'swift',
          name: splitTarget.name,
          path: effectivePathPrefix, // e.g. "ios"
        };

        const pattern = toGlobBraceList(splitTarget.sourceFiles);
        if (pattern) {
          target.pattern = pattern;
        }

        if (allDeps.length > 0) {
          target.dependencies = allDeps;
        }

        if (splitTarget.linkedFrameworks.length > 0) {
          target.linkedFrameworks = splitTarget.linkedFrameworks;
        }

        return target;
      }

      // Regular target handling
      const allFiles = [...splitTarget.sourceFiles, ...splitTarget.headerFiles];
      const commonPath = findCommonPath(allFiles);

      // SCC-derived targets commonly span multiple directories.
      // Emit an explicit glob pattern from the file list (relative to sourceRoot)
      // to keep the generated config actionable.
      const looksLikeSccDerivedTarget =
        /^SCC\d+_/.test(splitTarget.name) || /^SCCM_/.test(splitTarget.name);
      if (looksLikeSccDerivedTarget) {
        // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
        const targetPath = splitTarget.sourceRootName || pathPrefix;

        const allDeps = (() => {
          const validTargetNames = new Set(
            splitTargetsToUse
              .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
              .map((t) => t.name)
          );
          const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
          const crossProductDeps = splitTarget.externalDependencies.filter(
            (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
          );
          return [...internalDeps, ...crossProductDeps, ...productExternalDeps];
        })();

        const target: SpmConfigTarget = {
          type,
          name: splitTarget.name,
          path: targetPath,
        };

        // Filter out excluded files BEFORE creating the pattern
        let sourceFilesForPattern = splitTarget.sourceFiles;
        if (excludeFromPrebuild && excludeFromPrebuild.length > 0) {
          const filesToExclude = splitTarget.sourceFiles.filter((file) =>
            excludeFromPrebuild.some((pattern) => {
              // Strip leading **/ from glob patterns for simple matching
              const cleanPattern = pattern.replace(/^\*\*\//, '');
              return file.includes(cleanPattern) || file.endsWith(cleanPattern);
            })
          );
          if (filesToExclude.length > 0) {
            sourceFilesForPattern = splitTarget.sourceFiles.filter(
              (file) => !filesToExclude.includes(file)
            );
            target.exclude = filesToExclude;
          }
        }

        const pattern = toGlobBraceList(sourceFilesForPattern);
        if (pattern) {
          target.pattern = pattern;
        } else if ((type === 'objc' || type === 'cpp') && splitTarget.headerFiles.length > 0) {
          // Prevent default source globbing from pulling in unrelated sources for header-only targets.
          // This matches the existing convention used for bridging/header-only targets.
          target.pattern = '!*.m';
        } else if (sourceFilesForPattern.length === 0 && splitTarget.sourceFiles.length > 0) {
          // All source files were excluded from prebuild - set empty pattern to prevent default globbing
          target.pattern = '!*';
        }

        const headerPattern = toGlobBraceList(splitTarget.headerFiles);
        if (headerPattern) {
          target.headerPattern = headerPattern;
        }

        if (allDeps.length > 0) {
          target.dependencies = allDeps;
        }

        if (splitTarget.linkedFrameworks.length > 0) {
          target.linkedFrameworks = splitTarget.linkedFrameworks;
        }

        if (type === 'objc' || type === 'cpp') {
          target.includeDirectories = ['.'];
        }

        return target;
      }

      // Use sourceRootName if set (for targets from additional source dirs), otherwise use pathPrefix
      const effectivePathPrefix = splitTarget.sourceRootName || pathPrefix;

      // Add the path prefix (e.g., "ios/") to the path
      const targetPath = path.join(
        effectivePathPrefix,
        commonPath || splitTarget.name.replace(/_swift$|_objc$|_Base$/, '')
      );

      // Filter dependencies to only include other valid targets
      const validTargetNames = new Set(
        splitTargetsToUse
          .filter((t) => t.name && t.name !== '.' && t.name.trim() !== '')
          .map((t) => t.name)
      );
      const internalDeps = splitTarget.dependencies.filter((dep) => validTargetNames.has(dep));
      // Include cross-product dependencies (e.g., JSI from ExpoModulesJSI)
      // Filter out system modules and invalid dependency names
      const crossProductDeps = splitTarget.externalDependencies.filter(
        (dep) => !productExternalDeps.includes(dep) && isValidCrossProductDep(dep)
      );

      // Combine internal dependencies with cross-product and external dependencies
      const allDeps = [...internalDeps, ...crossProductDeps, ...productExternalDeps];

      const target: SpmConfigTarget = {
        type,
        name: splitTarget.name,
        path: targetPath,
      };

      // Check if this target needs to exclude headers that were moved to a bridging target
      const excludedHeaders: string[] = [];
      for (const bridging of bridgingTargets) {
        for (const bridgingHeader of bridging.headerFiles) {
          // Check if this header was originally in this target's directory
          const headerDir = path.dirname(bridgingHeader);
          const targetDir = commonPath || splitTarget.name.replace(/_swift$|_objc$/, '');
          if (headerDir.startsWith(targetDir) || targetDir.startsWith(headerDir)) {
            // This bridging header might be in this target's path, add exclude
            const relPath = commonPath ? path.relative(commonPath, bridgingHeader) : bridgingHeader;
            if (!excludedHeaders.includes(relPath) && !relPath.startsWith('..')) {
              excludedHeaders.push(relPath);
            }
          }
        }
      }

      // Check if this target needs to exclude Swift files that were moved to a Swift base target
      const excludedSwiftFiles: string[] = [];
      for (const swiftBase of swiftBridgingTargets) {
        for (const swiftFile of swiftBase.sourceFiles) {
          // Check if this Swift file was originally in this target's directory
          const fileDir = path.dirname(swiftFile);
          const targetDir = commonPath || splitTarget.name.replace(/_swift$|_objc$/, '');
          if (fileDir.startsWith(targetDir) || targetDir.startsWith(fileDir) || fileDir === '.') {
            // This Swift file might be in this target's path, add exclude
            const relPath = commonPath ? path.relative(commonPath, swiftFile) : swiftFile;
            if (!excludedSwiftFiles.includes(relPath) && !relPath.startsWith('..')) {
              excludedSwiftFiles.push(relPath);
            }
          }
        }
      }

      const allExcludes = [...excludedHeaders, ...excludedSwiftFiles];
      if (allExcludes.length > 0) {
        target.exclude = allExcludes;
      }

      // Only add dependencies if there are any
      if (allDeps.length > 0) {
        target.dependencies = allDeps;
      }

      // Only add linkedFrameworks if there are any
      if (splitTarget.linkedFrameworks.length > 0) {
        target.linkedFrameworks = splitTarget.linkedFrameworks;
      }

      // For ObjC targets, add include directories
      if (type === 'objc' || type === 'cpp') {
        target.includeDirectories = ['.'];
      }

      return target;
    });

  // Determine a meaningful product name
  // Try to get the package name from the parent directory of ios/
  const parentDir = path.dirname(sourceRoot);
  const packageJsonPath = path.join(parentDir, 'package.json');
  let defaultProductName = path.basename(parentDir);

  try {
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = fs.readJsonSync(packageJsonPath);
      if (packageJson.name) {
        // Convert package name to PascalCase product name
        defaultProductName = packageJson.name
          .replace(/^@[^/]+\//, '') // Remove scope
          .split(/[-_]/)
          .map((part: string) => part.charAt(0).toUpperCase() + part.slice(1))
          .join('');
      }
    }
  } catch {
    // Ignore errors, use default name
  }

  // Group targets into products based on path patterns
  const products = assignTargetsToProducts(
    targets,
    splitTargetsToUse,
    productDefinitions,
    defaultProductName,
    pathPrefix
  );

  // Resolve cross-product header dependencies
  // After products are assigned, we can now resolve angle-bracket imports like <ProductName/Header.h>
  // to the correct target and add missing dependencies
  resolveCrossProductDependencies(targets, splitTargetsToUse, products, result.files);

  // Create the SPM config with targets at root level
  // Products now reference targets by name
  const spmConfig: SpmConfig = {
    $schema: '../../tools/src/prebuilds/schemas/spm.config.schema.json',
    platforms: ['iOS(.v15)'],
    externalDependencies: productExternalDeps.length > 0 ? productExternalDeps : undefined,
    targets,
    products,
  };

  await fs.writeJson(outputPath, spmConfig, { spaces: 4 });
  console.log(chalk.green(`\n✅ SPM config exported to: ${outputPath}`));
}

/**
 * Resolves cross-product header dependencies by analyzing angle-bracket imports.
 *
 * When a file imports `<ProductName/Header.h>`, we need to find which target provides
 * that header (based on product assignment) and add it as a dependency.
 *
 * @param targets - The generated SPM config targets (will be mutated to add dependencies)
 * @param splitTargets - The original split targets with source file information
 * @param products - The product assignments (which targets belong to which product)
 * @param files - The analyzed source files with their imports
 */
function resolveCrossProductDependencies(
  targets: SpmConfigTarget[],
  splitTargets: SplitTarget[],
  products: { name: string; targets: string[] }[],
  files: Map<string, SourceFile>
): void {
  // Build a map of ProductName/HeaderName -> target name
  // For each product, collect all headers from its targets
  const productHeaderToTarget = new Map<string, string>();

  for (const product of products) {
    for (const targetName of product.targets) {
      const splitTarget = splitTargets.find((t) => t.name === targetName);
      if (!splitTarget) continue;

      for (const headerFile of splitTarget.headerFiles) {
        // The header will be available as <ProductName/HeaderBaseName.h>
        const headerBaseName = path.basename(headerFile);
        const key = `${product.name}/${headerBaseName}`;
        productHeaderToTarget.set(key, targetName);
      }
    }
  }

  // Build a map of target name -> SpmConfigTarget for easy lookup
  const targetMap = new Map<string, SpmConfigTarget>();
  for (const target of targets) {
    targetMap.set(target.name, target);
  }

  // Build a map of target name -> product name
  const targetToProduct = new Map<string, string>();
  for (const product of products) {
    for (const targetName of product.targets) {
      targetToProduct.set(targetName, product.name);
    }
  }

  // Build a map from file path to target name
  const fileToTarget = new Map<string, string>();
  for (const splitTarget of splitTargets) {
    for (const sourceFile of splitTarget.sourceFiles) {
      // We need to match by file name since we may not have the full path
      fileToTarget.set(sourceFile, splitTarget.name);
    }
  }

  // For each source file, check its imports and resolve cross-product dependencies
  for (const [filePath, sourceFile] of files.entries()) {
    // Find which target this file belongs to
    let owningTargetName: string | undefined;
    for (const splitTarget of splitTargets) {
      if (
        splitTarget.sourceFiles.some(
          (sf) => filePath.endsWith(sf) || sf.endsWith(path.basename(filePath))
        )
      ) {
        owningTargetName = splitTarget.name;
        break;
      }
    }

    if (!owningTargetName) continue;

    const owningTarget = targetMap.get(owningTargetName);
    if (!owningTarget) continue;

    // Check each angle-bracket import
    for (const imp of sourceFile.imports) {
      if (imp.type !== 'angle-bracket' || !imp.moduleName || !imp.headerName) {
        continue;
      }

      // Try to resolve <ModuleName/HeaderName.h> to a target
      const importKey = `${imp.moduleName}/${imp.headerName}`;
      const providingTarget = productHeaderToTarget.get(importKey);

      if (providingTarget && providingTarget !== owningTargetName) {
        // Add dependency if not already present
        if (!owningTarget.dependencies) {
          owningTarget.dependencies = [];
        }

        if (!owningTarget.dependencies.includes(providingTarget)) {
          owningTarget.dependencies.push(providingTarget);
        }
      }
    }
  }

  // Sort dependencies for consistent output
  for (const target of targets) {
    if (target.dependencies) {
      target.dependencies.sort((a, b) => a.localeCompare(b));
    }
  }
}

/**
 * Assigns targets to products based on path patterns.
 *
 * @param targets - The generated SPM config targets
 * @param splitTargets - The original split targets (contains source file paths)
 * @param productDefinitions - Optional product definitions with path patterns
 * @param defaultProductName - Default product name if no definitions provided
 * @param pathPrefix - The path prefix (e.g., "ios") used in target paths
 * @returns Array of product definitions with their target names
 */
function assignTargetsToProducts(
  targets: SpmConfigTarget[],
  splitTargets: SplitTarget[],
  productDefinitions: ProductDefinition[] | undefined,
  defaultProductName: string,
  pathPrefix: string
): { name: string; targets: string[] }[] {
  // If no product definitions provided, create a single product with all targets
  if (!productDefinitions || productDefinitions.length === 0) {
    return [
      {
        name: defaultProductName,
        targets: targets.map((t) => t.name),
      },
    ];
  }

  // Build a map from target name to its source file paths
  const targetToFilePaths = new Map<string, string[]>();
  for (const splitTarget of splitTargets) {
    const allFiles = [...splitTarget.sourceFiles, ...splitTarget.headerFiles];
    targetToFilePaths.set(splitTarget.name, allFiles);
  }

  // Also add target paths from the generated config (for targets that might have been created differently)
  for (const target of targets) {
    if (!targetToFilePaths.has(target.name) && target.path) {
      // Use the target's path as a hint
      targetToFilePaths.set(target.name, [target.path]);
    }
  }

  // Find catch-all product (one with "*" pattern) and specific products
  let catchAllProduct: ProductDefinition | undefined;
  const specificProducts: ProductDefinition[] = [];

  for (const prodDef of productDefinitions) {
    if (prodDef.pathPatterns.includes('*')) {
      catchAllProduct = prodDef;
    } else {
      specificProducts.push(prodDef);
    }
  }

  // Initialize product target lists
  const productTargets = new Map<string, Set<string>>();
  for (const prodDef of productDefinitions) {
    productTargets.set(prodDef.name, new Set());
  }

  // Assign each target to a product based on path matching
  const assignedTargets = new Set<string>();

  for (const target of targets) {
    const targetFilePaths = targetToFilePaths.get(target.name) || [target.path || ''];

    // Check each specific product to see if this target matches
    for (const prodDef of specificProducts) {
      const matches = targetFilePaths.some((filePath) => {
        // Use the same matching logic as getFileProduct for consistency
        return prodDef.pathPatterns.some((pattern) => {
          // Check if the file path contains the pattern as a path component
          const patternWithSlashes = '/' + pattern + '/';
          const patternAtStart = pattern + '/';
          const patternAtEnd = '/' + pattern;

          return (
            filePath.includes(patternWithSlashes) || // /JSI/ anywhere in path
            filePath.startsWith(patternAtStart) || // JSI/ at start
            filePath.endsWith(patternAtEnd) || // ends with /JSI (directory)
            filePath === pattern || // exact match
            // Also check for pattern as a directory component
            filePath.split('/').includes(pattern) ||
            // Also check the target's path property directly
            (target.path && target.path.split('/').includes(pattern))
          );
        });
      });

      if (matches) {
        productTargets.get(prodDef.name)?.add(target.name);
        assignedTargets.add(target.name);
        break; // First matching product wins
      }
    }
  }

  // Assign remaining targets to catch-all product
  const unassignedTargets = targets.filter((t) => !assignedTargets.has(t.name)).map((t) => t.name);

  if (unassignedTargets.length > 0) {
    if (catchAllProduct) {
      const catchAllSet = productTargets.get(catchAllProduct.name)!;
      for (const targetName of unassignedTargets) {
        catchAllSet.add(targetName);
      }
    } else {
      // Create default product for unassigned targets
      productTargets.set(defaultProductName, new Set(unassignedTargets));
    }
  }

  // Build the result, preserving the order from productDefinitions
  const result: { name: string; targets: string[] }[] = [];

  // First add specific products (in order defined)
  for (const prodDef of specificProducts) {
    const targetSet = productTargets.get(prodDef.name);
    if (targetSet && targetSet.size > 0) {
      result.push({
        name: prodDef.name,
        targets: Array.from(targetSet),
      });
    }
  }

  // Then add catch-all product
  if (catchAllProduct) {
    const targetSet = productTargets.get(catchAllProduct.name);
    if (targetSet && targetSet.size > 0) {
      result.push({
        name: catchAllProduct.name,
        targets: Array.from(targetSet),
      });
    }
  }

  // Finally add any default product if it was created
  if (!catchAllProduct && productTargets.has(defaultProductName)) {
    const targetSet = productTargets.get(defaultProductName);
    if (targetSet && targetSet.size > 0) {
      result.push({
        name: defaultProductName,
        targets: Array.from(targetSet),
      });
    }
  }

  // Log product assignment summary
  console.log(chalk.cyan('\n📦 Product assignment:'));
  for (const prod of result) {
    console.log(chalk.white(`   ${prod.name}: ${prod.targets.length} target(s)`));
  }

  return result;
}

/**
 * Finds the common base path for a list of file paths
 */
function findCommonPath(filePaths: string[]): string {
  if (filePaths.length === 0) return '.';
  if (filePaths.length === 1) return path.dirname(filePaths[0]);

  const dirs = filePaths.map((f) => path.dirname(f).split(path.sep));
  const commonParts: string[] = [];

  for (let i = 0; i < dirs[0].length; i++) {
    const part = dirs[0][i];
    if (dirs.every((d) => d[i] === part)) {
      commonParts.push(part);
    } else {
      break;
    }
  }

  return commonParts.length > 0 ? commonParts.join(path.sep) : '.';
}

// ============================================================================
// CLI Entry Point
// ============================================================================

/**
 * Main analysis function that can be called from the command line
 */
export async function runAnalysis(
  sourceRoot: string,
  options: {
    excludeDirs?: string[];
    includePaths?: string[];
    additionalSourceDirs?: string[];
    outputJson?: string;
    outputDot?: string;
    outputSpmConfig?: string;
    externalDeps?: string[];
    productDefinitions?: ProductDefinition[];
    folderTargets?: boolean;
    virtualTargets?: boolean;
    virtualTargetsScc?: boolean;
    virtualTargetsSccMergeSingletons?: boolean;
    virtualTargetsMaxDepth?: number;
    autoBridge?: boolean;
    consolidateSwift?: boolean;
    mergeSwift?: boolean;
    mergeObjc?: boolean;
    mergeHeaderTargets?: boolean;
    excludeFromPrebuild?: string[];
    verbose?: boolean;
    useClang?: boolean;
  } = {}
): Promise<AnalysisResult> {
  // Analyze the primary source directory
  const result = await analyzeSourceDirectory({
    sourceRoot,
    excludeDirs: options.excludeDirs,
    includePaths: options.includePaths,
    verbose: options.verbose,
    useClang: options.useClang,
  });

  // Analyze additional source directories and merge results
  if (options.additionalSourceDirs && options.additionalSourceDirs.length > 0) {
    for (const additionalDir of options.additionalSourceDirs) {
      console.log(chalk.cyan(`\n📂 Analyzing additional source directory: ${additionalDir}`));

      const additionalResult = await analyzeSourceDirectory({
        sourceRoot: additionalDir,
        excludeDirs: options.excludeDirs,
        includePaths: options.includePaths,
        verbose: options.verbose,
        useClang: options.useClang,
      });

      // Tag split targets from additional sources with their source root name
      const additionalSourceRootName = path.basename(additionalDir);
      for (const splitTarget of additionalResult.splitTargets) {
        splitTarget.sourceRootName = additionalSourceRootName;
      }

      // Merge files (Map) - tag with sourceRootName for SCC analysis
      for (const [filePath, sourceFile] of additionalResult.files.entries()) {
        sourceFile.sourceRootName = additionalSourceRootName;
        result.files.set(filePath, sourceFile);
      }

      // Merge headers (Map)
      for (const [headerName, headerPath] of additionalResult.headers.entries()) {
        result.headers.set(headerName, headerPath);
      }

      // Merge dependency graph
      for (const [file, deps] of additionalResult.dependencyGraph.entries()) {
        result.dependencyGraph.set(file, deps);
      }

      // Merge reverse dependency graph
      for (const [file, deps] of additionalResult.reverseDependencyGraph.entries()) {
        const existing = result.reverseDependencyGraph.get(file);
        if (existing) {
          for (const dep of deps) {
            existing.add(dep);
          }
        } else {
          result.reverseDependencyGraph.set(file, deps);
        }
      }

      // Merge split targets
      result.splitTargets.push(...additionalResult.splitTargets);

      // Merge other analysis data
      if (additionalResult.bridgingSuggestions) {
        result.bridgingSuggestions = [
          ...(result.bridgingSuggestions || []),
          ...additionalResult.bridgingSuggestions,
        ];
      }

      if (additionalResult.swiftBridgingSuggestions) {
        result.swiftBridgingSuggestions = [
          ...(result.swiftBridgingSuggestions || []),
          ...additionalResult.swiftBridgingSuggestions,
        ];
      }
    }

    console.log(
      chalk.green(
        `\n✅ Merged analysis from ${options.additionalSourceDirs.length + 1} source directories`
      )
    );
    console.log(chalk.gray(`   Total files: ${result.files.size}`));
    console.log(chalk.gray(`   Total targets: ${result.splitTargets.length}`));
  }

  if (options.folderTargets) {
    printFolderTargetsReport(result);
    return result;
  }

  if (options.virtualTargets) {
    const maxDepth =
      typeof options.virtualTargetsMaxDepth === 'number' &&
      Number.isFinite(options.virtualTargetsMaxDepth)
        ? options.virtualTargetsMaxDepth
        : 4;

    const mode: VirtualTargetsMode = options.virtualTargetsScc ? 'scc' : 'folder-split';
    printVirtualTargetsReport(result, mode, Math.max(1, maxDepth));

    // Historically this mode was "print then exit".
    // If the caller also requested exports, continue to allow emitting config/graphs.
    if (!options.outputSpmConfig && !options.outputJson && !options.outputDot) {
      return result;
    }
  }

  printAnalysisSummary(result);

  // Print Swift usage analysis
  printSwiftUsageAnalysis(result.swiftUsageAnalysis);

  if (options.outputJson) {
    await exportAnalysisJson(result, options.outputJson);
  }

  if (options.outputDot) {
    exportDotGraph(result, options.outputDot);
  }

  if (options.outputSpmConfig) {
    const mergeSingletons = options.virtualTargetsSccMergeSingletons !== false;
    let splitTargetsOverride: SplitTarget[] | undefined;
    if (options.virtualTargetsScc) {
      const raw = computeSplitTargetsBySccVirtualTargets(
        result.files,
        result.dependencyGraph,
        options.productDefinitions
      );
      splitTargetsOverride = mergeSingletons
        ? mergeSingletonSccSplitTargets(raw, options.productDefinitions)
        : raw;
    }

    await exportSpmConfig(
      result,
      options.outputSpmConfig,
      sourceRoot,
      options.externalDeps,
      options.autoBridge,
      options.consolidateSwift,
      splitTargetsOverride,
      options.productDefinitions,
      options.mergeSwift,
      options.excludeFromPrebuild,
      options.mergeHeaderTargets,
      options.mergeObjc
    );
  }

  return result;
}

// Export for use in other modules
export default {
  analyzeSourceDirectory,
  printAnalysisSummary,
  printSwiftUsageAnalysis,
  printFileDependencies,
  exportDotGraph,
  exportAnalysisJson,
  exportSpmConfig,
  runAnalysis,
};
