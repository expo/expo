FrameworkTarget(
    name: "React",
    path: ".dependencies/React-Core-prebuilt/React.xcframework",
    includeDirectories: ["Headers", "React_Core"],
    headerMapPath: ".dependencies/React-Core-prebuilt/React-Headers.hmap",
    vfsOverlayPath: ".dependencies/React-Core-prebuilt/React-VFS.yaml"
)
