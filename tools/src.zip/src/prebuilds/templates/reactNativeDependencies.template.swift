FrameworkTarget(
    name: "ReactNativeDependencies",
    path: ".dependencies/ReactNativeDependencies/ReactNativeDependencies.xcframework",
    includeDirectories: ["Headers"])
